-- Axın Database İnisializasiyası

-- UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";   -- Full-text search üçün

-- ─── Performans İndeksləri ───────────────────────────────────────
-- (TypeORM entity-lərdən əlavə əl ilə əlavə edilənlər)

-- Username axtarışı üçün trigram indeksi (LIKE sorğuları)
-- CREATE INDEX CONCURRENTLY idx_users_username_trgm 
--   ON users USING gin(username gin_trgm_ops);

-- Post content axtarışı
-- CREATE INDEX CONCURRENTLY idx_posts_content_trgm
--   ON posts USING gin(content gin_trgm_ops);

-- ─── Read Replica üçün Publication (gələcəkdə) ─────────────────
-- CREATE PUBLICATION axin_pub FOR ALL TABLES;

SELECT 'Axın DB hazırdır! 🚀' AS status;
