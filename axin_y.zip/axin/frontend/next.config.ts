import type { NextConfig } from 'next';

const config: NextConfig = {
  productionBrowserSourceMaps: false,
  images: { unoptimized: true },
  reactStrictMode: false,

  webpack: (cfg, { dev, isServer }) => {
    if (dev && !isServer) {
      cfg.cache = false;
    }
    return cfg;
  },
};

export default config;
