import type { Metadata, Viewport } from 'next';
import './globals.css';
import { UnreadProvider } from './unread-provider';
import { AuthProvider } from './auth-provider';
import NavBar from './navbar';

export const metadata: Metadata = {
  title: 'Axın',
  description: 'Azərbaycan sosial şəbəkəsi',
  manifest: '/manifest.json',
  appleWebApp: { capable: true, statusBarStyle: 'default', title: 'Axın' },
};

export const viewport: Viewport = {
  themeColor: '#6366f1',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="az">
      <head>
        <link rel="apple-touch-icon" href="/icon-192.png" />
        <meta name="mobile-web-app-capable" content="yes" />
      </head>
      <body style={{ margin: 0, background: '#f8fafc' }}>
        <AuthProvider>
          <UnreadProvider>
            {children}
            <NavBar />
          </UnreadProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
