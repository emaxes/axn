'use client';
import { getToken, apiFetch } from '../../../lib/auth';
import { useState, useEffect, useRef } from 'react';
import { useRouter, useParams } from 'next/navigation';

const API = 'http://localhost:3001/api/v1';
const PAL: [string, string][] = [
  ['#6366f1','#a5b4fc'],['#ec4899','#fbcfe8'],
  ['#10b981','#a7f3d0'],['#f59e0b','#fde68a'],
  ['#3b82f6','#bfdbfe'],['#8b5cf6','#ddd6fe'],
];
const grad = (name = 'A') => {
  const [a, b] = PAL[name.charCodeAt(0) % PAL.length];
  return `linear-gradient(135deg, ${a}, ${b})`;
};

function Avatar({ name, url, size }: { name: string; url?: string; size: number }) {
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', overflow: 'hidden', background: grad(name), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size * 0.38, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
      {url ? <img src={url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : name?.[0]?.toUpperCase()}
    </div>
  );
}

function UserRow({ user, onNavigate }: { user: any; onNavigate: (p: string) => void }) {
  return (
    <div onClick={() => onNavigate(`/profile/${user.username}`)}
      style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: '1px solid #f1f5f9', cursor: 'pointer' }}>
      <Avatar name={user.username} url={user.avatarUrl} size={46} />
      <div>
        <div style={{ fontWeight: 700, fontSize: 14, color: '#0f172a' }}>{user.displayName || user.username}</div>
        <div style={{ fontSize: 13, color: '#94a3b8' }}>@{user.username}</div>
      </div>
    </div>
  );
}

// Post detail modal — Instagram kimi vertical scroll

// ── Axın Reels Viewer — profil grid-dən açılır ─────────────────
function ReelsViewer({ posts, startPost, me, onClose, onDelete }: {
  posts: any[]; startPost: any; me: any;
  onClose: () => void; onDelete: (id: string) => void;
}) {
  const isVid = (u: string) => /\.(mp4|mov|webm)/i.test(u||'');
  const startIdx = Math.max(0, posts.findIndex((p:any) => p.id === startPost.id));
  const [ci, setCi] = useState(startIdx);
  const [liked, setLiked] = useState<Record<string,boolean>>({});
  const [counts, setCounts] = useState<Record<string,number>>({});
  const [saved, setSaved] = useState<Record<string,boolean>>({});
  const [muted, setMuted] = useState(false);
  const [playing, setPlaying] = useState(true);
  const [commentPost, setCommentPost] = useState<any>(null);
  const stripRef = useRef<HTMLDivElement>(null);
  const ciRef = useRef(startIdx);
  const startY = useRef(0);
  const startTime = useRef(0);
  const dragging = useRef(false);
  const onSeek = useRef(false);
  const lastTap = useRef<number>(0);
  const vidRefs = useRef<Record<string, HTMLVideoElement|null>>({});

  const PAL: [string,string][] = [['#6366f1','#8b5cf6'],['#ec4899','#f43f5e'],['#10b981','#06b6d4'],['#f59e0b','#ef4444']];
  const gradBg = (n='A') => { const [a,b]=PAL[n.charCodeAt(0)%PAL.length]; return `linear-gradient(160deg,${a},${b},#0f172a)`; };
  const fmt = (s: number) => `${~~(s/60)}:${String(~~(s%60)).padStart(2,'0')}`;
  const fmtN = (n: number) => n>=1000000?(n/1000000).toFixed(1)+'M':n>=1000?(n/1000).toFixed(1)+'K':String(n||0);

  // Muted dəyişəndə bütün vidləri yenilə
  useEffect(() => {
    Object.values(vidRefs.current).forEach(v => { if(v) v.muted = muted; });
  }, [muted]);

  // Navbar gizlət
  useEffect(() => {
    document.body.setAttribute('data-post-open','1');
    document.body.style.overflow='hidden';
    const nav = document.querySelector('nav') as HTMLElement|null;
    if(nav) nav.style.setProperty('display','none','important');
    return () => {
      document.body.removeAttribute('data-post-open');
      document.body.style.overflow='';
      const nav2 = document.querySelector('nav') as HTMLElement|null;
      if(nav2) nav2.style.removeProperty('display');
    };
  }, []);

  // Real slide hündürlüyü (address bar daxil)
  function getVH() {
    return stripRef.current?.firstElementChild?.clientHeight || window.innerHeight;
  }

  // Strip-i mövqeyə qoy
  function setStrip(y: number, animate: boolean) {
    if (!stripRef.current) return;
    stripRef.current.style.transition = animate ? 'transform .35s cubic-bezier(.25,.46,.45,.94)' : 'none';
    stripRef.current.style.transform = `translateY(${y}px)`;
  }

  // ci dəyişəndə strip-i sürüş
  useEffect(() => {
    ciRef.current = ci;
    const VH = getVH();
    setStrip(-ci * VH, true);
    // Aktiv video-nu oyna, qalanlarını dayandır
    Object.entries(vidRefs.current).forEach(([id, v]) => {
      if (!v) return;
      const postId = posts[ci]?.id;
      if (String(postId) === id) {
        v.play().catch(()=>{});
        setPlaying(true);
      } else {
        v.pause();
        v.currentTime = 0;
      }
    });
  }, [ci]);

  // İlk render: strip-i başlanğıc mövqeyə qoy
  useEffect(() => {
    // Bir frame sonra DOM render olduqdan sonra ölç
    requestAnimationFrame(() => {
      const VH = getVH();
      setStrip(-startIdx * VH, false);
    });
  }, []);

  // Native touch swipe
  useEffect(() => {
    const strip = stripRef.current;
    if (!strip) return;
    const VH = window.innerHeight;

    function start(e: TouchEvent) {
      if ((e.target as HTMLElement).closest('[data-seek]')) { onSeek.current = true; return; }
      onSeek.current = false;
      dragging.current = true;
      startY.current = e.touches[0].clientY;
      startTime.current = Date.now();
      strip.style.transition = 'none';
    }

    function move(e: TouchEvent) {
      if (!dragging.current || onSeek.current) return;
      e.preventDefault();
      const dy = e.touches[0].clientY - startY.current;
      const ci = ciRef.current;
      const VH = strip.firstElementChild?.clientHeight || window.innerHeight;
      const atTop = ci === 0 && dy > 0;
      const atBot = ci >= posts.length - 1 && dy < 0;
      strip.style.transform = `translateY(${-ci * VH + (atTop || atBot ? dy * 0.12 : dy)}px)`;
    }

    function end(e: TouchEvent) {
      if (!dragging.current || onSeek.current) return;
      dragging.current = false;
      const dy = e.changedTouches[0].clientY - startY.current;
      const dt = Date.now() - startTime.current;
      const vel = Math.abs(dy) / Math.max(dt, 1);
      const ci = ciRef.current;
      const VH = strip.firstElementChild?.clientHeight || window.innerHeight;
      if ((dy < -VH * 0.18 || (vel > 0.35 && dy < -30)) && ci < posts.length - 1) {
        setCi(i => i + 1);
      } else if ((dy > VH * 0.18 || (vel > 0.35 && dy > 30)) && ci > 0) {
        setCi(i => i - 1);
      } else {
        setStrip(-ci * VH, true);
      }
    }

    strip.addEventListener('touchstart', start, { passive: true });
    strip.addEventListener('touchmove', move, { passive: false });
    strip.addEventListener('touchend', end, { passive: true });
    return () => {
      strip.removeEventListener('touchstart', start);
      strip.removeEventListener('touchmove', move);
      strip.removeEventListener('touchend', end);
    };
  }, [posts.length]);

  async function toggleLike(postId: string, isLiked: boolean, lc: number) {
    setLiked(m=>({...m,[postId]:!isLiked}));
    setCounts(m=>({...m,[postId]:isLiked?lc-1:lc+1}));
        await apiFetch(`${API}/posts/${postId}/like`,{method:'POST'});
  }

  async function toggleSave(postId: string, isSaved: boolean) {
    setSaved(m=>({...m,[postId]:!isSaved}));
        apiFetch(`${API}/posts/${postId}/bookmark`,{method:'POST'}).catch(()=>{});
  }

  return (
    <div style={{position:'fixed',inset:0,zIndex:1100,background:'#000',overflow:'hidden'}}
      onClick={e=>{
        if ((e.target as HTMLElement).closest('[data-seek]') ||
            (e.target as HTMLElement).closest('[data-actions]')) return;
        const now = Date.now();
        if (now - lastTap.current < 320) {
          // Double tap — like + heart
          const p = posts[ci];
          if (p) {
            const isLiked = liked[p.id] ?? (p.isLiked||false);
            const lc = counts[p.id] ?? (p.likeCount||0);
            if (!isLiked) { toggleLike(p.id, false, lc); }
            // Heart animasiyası
            const heart = document.createElement('div');
            heart.style.cssText = `position:fixed;left:${e.clientX-70}px;top:${e.clientY-70}px;pointer-events:none;z-index:9999;animation:htPop 0.75s cubic-bezier(.17,.67,.35,1.2) forwards`;
            heart.innerHTML = `<svg width="140" height="140" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <filter id="hglow" x="-50%" y="-50%" width="200%" height="200%">
                  <feGaussianBlur stdDeviation="1.5" result="blur"/>
                  <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
                </filter>
              </defs>
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"
                fill="url(#hgrad)" filter="url(#hglow)" stroke="rgba(255,255,255,0.15)" stroke-width="0.3"/>
              <defs>
                <linearGradient id="hgrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#ff6b9d"/>
                  <stop offset="100%" stop-color="#f43f5e"/>
                </linearGradient>
              </defs>
            </svg>`;
            document.body.appendChild(heart);
            setTimeout(() => heart.remove(), 950);
          }
        } else {
          // Single tap — sadəcə lastTap yenilə, play/pause yox
        }
        lastTap.current = now;
      }}>

      {/* Bütün postlar vertical strip-də */}
      <div ref={stripRef} style={{willChange:'transform'}}>
        {posts.map((p, idx) => {
          const mediaUrl = (p.mediaUrls||[])[0]||'';
          const isV = isVid(mediaUrl);
          const isActive = idx === ci;
          const isLiked = liked[p.id] ?? (p.isLiked||false);
          const lc = counts[p.id] ?? (p.likeCount||0);
          const isSaved = saved[p.id] ?? (p.isBookmarked||false);
          const isOwn = p.user?.username === me?.username;

          return (
            <div key={p.id} style={{width:'100%',height:'100dvh',position:'relative',overflow:'hidden',background:'#000'}}>

              {/* Media */}
              {mediaUrl && isV ? (
                <video ref={el=>{
                    vidRefs.current[String(p.id)]=el;
                    if(el) el.muted=muted;
                  }}
                  src={mediaUrl} loop playsInline
                  onTimeUpdate={()=>{}}
                  style={{width:'100%',height:'100%',objectFit:'cover'}}/>
              ) : mediaUrl ? (
                <img src={mediaUrl} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
              ) : (
                <div style={{width:'100%',height:'100%',background:gradBg(p.user?.username),display:'flex',alignItems:'center',justifyContent:'center',padding:32}}>
                  <p style={{color:'#fff',fontSize:20,fontWeight:700,lineHeight:1.7,textAlign:'center',textShadow:'0 2px 16px rgba(0,0,0,0.5)'}}>{p.content}</p>
                </div>
              )}

              {/* Gradient */}
              <div style={{position:'absolute',inset:0,background:'linear-gradient(to bottom,rgba(0,0,0,0.4) 0%,transparent 25%,transparent 48%,rgba(0,0,0,0.85) 100%)',pointerEvents:'none'}}/>

              {/* Geri düyməsi — yalnız aktiv postda */}
              {isActive && (
                <div style={{position:'absolute',top:0,left:0,right:0,zIndex:20,padding:'14px 16px',background:'linear-gradient(to bottom,rgba(0,0,0,0.5),transparent)',pointerEvents:'none'}}>
                  <button onClick={onClose} style={{background:'rgba(0,0,0,0.3)',border:'none',cursor:'pointer',padding:8,borderRadius:'50%',backdropFilter:'blur(6px)',display:'flex',pointerEvents:'all'}}>
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
                  </button>
                </div>
              )}

              {/* Sağ panel */}
              <div style={{position:'absolute',right:12,bottom:120,zIndex:20,display:'flex',flexDirection:'column',alignItems:'center',gap:20}}
                data-actions="1" onClick={e=>e.stopPropagation()}>

                <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
                  <button onClick={e=>{e.stopPropagation();toggleLike(p.id,isLiked,lc);}} style={{background:isLiked?'rgba(244,63,94,0.18)':'rgba(255,255,255,0.12)',backdropFilter:'blur(6px)',border:'none',cursor:'pointer',borderRadius:'50%',width:50,height:50,display:'flex',alignItems:'center',justifyContent:'center',transition:'transform 0.2s',transform:'scale(1)'}}>
                    <svg width="26" height="26" viewBox="0 0 24 24" fill={isLiked?'#f43f5e':'none'} stroke={isLiked?'#f43f5e':'#fff'} strokeWidth="1.8"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" strokeLinecap="round"/></svg>
                  </button>
                  <span style={{color:'#fff',fontSize:12,fontWeight:700,textShadow:'0 1px 4px rgba(0,0,0,0.6)'}}>{fmtN(lc)}</span>
                </div>

                <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
                  <button onClick={()=>setCommentPost(p)} style={{background:'rgba(255,255,255,0.12)',backdropFilter:'blur(6px)',border:'none',cursor:'pointer',borderRadius:'50%',width:50,height:50,display:'flex',alignItems:'center',justifyContent:'center'}}>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                  </button>
                  <span style={{color:'#fff',fontSize:12,fontWeight:700,textShadow:'0 1px 4px rgba(0,0,0,0.6)'}}>{fmtN(p.replyCount||0)}</span>
                </div>

                <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
                  <button onClick={()=>toggleSave(p.id,isSaved)} style={{background:isSaved?'rgba(99,102,241,0.2)':'rgba(255,255,255,0.12)',backdropFilter:'blur(6px)',border:'none',cursor:'pointer',borderRadius:'50%',width:50,height:50,display:'flex',alignItems:'center',justifyContent:'center',transition:'all 0.2s'}}>
                    <svg width="22" height="22" viewBox="0 0 24 24" fill={isSaved?'#6366f1':'none'} stroke={isSaved?'#6366f1':'#fff'} strokeWidth="1.8" strokeLinecap="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
                  </button>
                  <span style={{color:'#fff',fontSize:12,fontWeight:700,textShadow:'0 1px 4px rgba(0,0,0,0.6)'}}>{fmtN(p.bookmarkCount||0)}</span>
                </div>

                <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
                  <button onClick={async()=>{const url=`${window.location.origin}/post/${p.id}`;if((navigator as any).share){try{await (navigator as any).share({title:'Axın',url});}catch{}}else{await navigator.clipboard.writeText(url);}}} style={{background:'rgba(255,255,255,0.12)',backdropFilter:'blur(6px)',border:'none',cursor:'pointer',borderRadius:'50%',width:50,height:50,display:'flex',alignItems:'center',justifyContent:'center'}}>
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                  </button>
                  <span style={{color:'#fff',fontSize:12,fontWeight:700,textShadow:'0 1px 4px rgba(0,0,0,0.6)'}}>{fmtN(p.shareCount||0)}</span>
                </div>

                {/* Səs + Play/Pause */}
                {isV && isActive && (
                  <>
                    {/* Play/Pause */}
                    <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
                      <button onClick={e=>{e.stopPropagation();const v=vidRefs.current[String(p.id)];if(!v)return;if(playing){v.pause();setPlaying(false);}else{v.play().catch(()=>{});setPlaying(true);}}} style={{background:'rgba(255,255,255,0.12)',backdropFilter:'blur(6px)',border:'none',cursor:'pointer',borderRadius:'50%',width:50,height:50,display:'flex',alignItems:'center',justifyContent:'center'}}>
                        {playing
                          ? <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>
                          : <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff"><polygon points="5 3 19 12 5 21"/></svg>
                        }
                      </button>
                    </div>
                    {/* Səs */}
                    <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
                      <button onClick={e=>{e.stopPropagation();setMuted(m=>!m);}} style={{background:muted?'rgba(244,63,94,0.15)':'rgba(255,255,255,0.12)',backdropFilter:'blur(6px)',border:'none',cursor:'pointer',borderRadius:'50%',width:50,height:50,display:'flex',alignItems:'center',justifyContent:'center'}}>
                        {muted
                          ? <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>
                          : <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
                        }
                      </button>
                    </div>
                  </>
                )}
              </div>

              {/* Sol alt: user + caption */}
              <div style={{position:'absolute',bottom:isV?46:18,left:0,right:80,padding:'0 16px',zIndex:20}}
                onClick={e=>e.stopPropagation()}>
                <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:6}}>
                  <div style={{width:36,height:36,borderRadius:'50%',overflow:'hidden',border:'2px solid rgba(255,255,255,0.7)',flexShrink:0,background:'linear-gradient(135deg,#6366f1,#8b5cf6)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,fontWeight:800,color:'#fff'}}>
                    {p.user?.avatarUrl?<img src={p.user.avatarUrl} style={{width:'100%',height:'100%',objectFit:'cover'}}/>:p.user?.username?.[0]?.toUpperCase()}
                  </div>
                  <span style={{color:'#fff',fontWeight:800,fontSize:14,textShadow:'0 1px 6px rgba(0,0,0,0.5)'}}>@{p.user?.username}</span>
                </div>
                {p.content && (
                  <p style={{color:'rgba(255,255,255,0.88)',fontSize:13,lineHeight:1.55,margin:0,textShadow:'0 1px 6px rgba(0,0,0,0.5)',display:'-webkit-box',WebkitLineClamp:2,WebkitBoxOrient:'vertical',overflow:'hidden'} as any}>{p.content}</p>
                )}
              </div>

              {/* Seek bar */}
              {isV && isActive && (
                <SeekBarInline vidRef={{current: vidRefs.current[String(p.id)]||null}} fmt={fmt}/>
              )}
            </div>
          );
        })}
      </div>

      {/* Şərh paneli */}
      {commentPost && (
        <CommentPanelModal post={commentPost} me={me} onClose={()=>setCommentPost(null)}/>
      )}
    </div>
  );
}

function SeekBarInline({ vidRef, fmt }: { vidRef: React.MutableRefObject<HTMLVideoElement|null>; fmt: (s:number)=>string }) {
  const seekRef = useRef<HTMLDivElement>(null);
  const fillRef = useRef<HTMLDivElement>(null);
  const thumbRef = useRef<HTMLDivElement>(null);
  const timeRef = useRef<HTMLSpanElement>(null);
  const isScrubbing = useRef(false);
  const [dur, setDur] = useState(0);
  const durRef = useRef(0);

  useEffect(() => {
    const v = vidRef.current; if (!v) return;
    const onTime = () => {
      if (isScrubbing.current) return;
      const pct = v.currentTime / (v.duration||1) * 100;
      updateUI(pct, v.currentTime);
    };
    const onMeta = () => { setDur(v.duration); durRef.current = v.duration; };
    v.addEventListener('timeupdate', onTime);
    v.addEventListener('loadedmetadata', onMeta);
    if (v.duration) { setDur(v.duration); durRef.current = v.duration; }
    return () => { v.removeEventListener('timeupdate',onTime); v.removeEventListener('loadedmetadata',onMeta); };
  }, [vidRef.current]);

  function updateUI(pct: number, time: number) {
    if (fillRef.current) fillRef.current.style.width = `${pct}%`;
    if (thumbRef.current) {
      thumbRef.current.style.left = `clamp(0px,calc(${pct}% - 8px),calc(100% - 16px))`;
    }
    if (timeRef.current) timeRef.current.textContent = fmt(time);
  }

  function seekTo(cx: number) {
    const el = seekRef.current; const v = vidRef.current;
    if (!el || !v || !v.duration) return;
    const {left,width} = el.getBoundingClientRect();
    const pct = Math.max(0, Math.min(1, (cx-left)/width));
    v.currentTime = pct * v.duration;
    updateUI(pct*100, v.currentTime);
  }

  useEffect(() => {
    const el = seekRef.current; if (!el) return;

    function onStart(e: TouchEvent) {
      e.stopPropagation();
      isScrubbing.current = true;
      if (fillRef.current) fillRef.current.style.transition = 'none';
      if (thumbRef.current) { thumbRef.current.style.width='16px'; thumbRef.current.style.height='16px'; thumbRef.current.style.boxShadow='0 0 0 4px rgba(255,255,255,.25)'; }
      seekTo(e.touches[0].clientX);
    }
    function onMove(e: TouchEvent) {
      if (!isScrubbing.current) return;
      e.preventDefault(); e.stopPropagation();
      seekTo(e.touches[0].clientX);
    }
    function onEnd(e: TouchEvent) {
      e.stopPropagation();
      isScrubbing.current = false;
      if (fillRef.current) fillRef.current.style.transition = 'width .1s linear';
      if (thumbRef.current) { thumbRef.current.style.width='10px'; thumbRef.current.style.height='10px'; thumbRef.current.style.boxShadow='0 1px 4px rgba(0,0,0,.4)'; }
    }

    el.addEventListener('touchstart', onStart, {passive:true});
    el.addEventListener('touchmove',  onMove,  {passive:false});
    el.addEventListener('touchend',   onEnd,   {passive:true});
    return () => {
      el.removeEventListener('touchstart', onStart);
      el.removeEventListener('touchmove',  onMove);
      el.removeEventListener('touchend',   onEnd);
    };
  }, []);

  return (
    <div style={{position:'absolute',bottom:0,left:0,right:0,zIndex:25,paddingBottom:6}}
      onClick={e=>e.stopPropagation()}>
      <div style={{display:'flex',justifyContent:'space-between',padding:'0 12px 2px'}}>
        <span ref={timeRef} style={{color:'rgba(255,255,255,.45)',fontSize:9,fontVariantNumeric:'tabular-nums'}}>0:00</span>
        <span style={{color:'rgba(255,255,255,.3)',fontSize:9,fontVariantNumeric:'tabular-nums'}}>{fmt(dur||0)}</span>
      </div>
      <div ref={seekRef} data-seek="1"
        style={{width:'100%',height:32,display:'flex',alignItems:'center',position:'relative',touchAction:'none',cursor:'pointer'}}>
        <div style={{position:'absolute',left:0,right:0,height:2,borderRadius:99,background:'rgba(255,255,255,.2)'}}>
          <div ref={fillRef} style={{position:'absolute',left:0,width:'0%',height:'100%',background:'#fff',borderRadius:99,transition:'width .1s linear'}}/>
        </div>
        <div ref={thumbRef} style={{position:'absolute',left:0,top:'50%',transform:'translateY(-50%)',width:10,height:10,borderRadius:'50%',background:'#fff',boxShadow:'0 1px 4px rgba(0,0,0,.4)',transition:'width .15s,height .15s',pointerEvents:'none'}}/>
      </div>
    </div>
  );
}


function PostDetailModal({ posts, initialPost, me, meUsername, onClose, onDelete }: {
  posts: any[]; initialPost: any; me: any; meUsername: string|null;
  onClose: () => void; onDelete: (id: string) => void;
}) {
  
  const isVid = (url: string) => /\.(mp4|mov|webm)$/i.test(url);
  const [ci, setCi] = useState(() => Math.max(0, posts.findIndex(p => p.id === initialPost.id)));
  const [likedMap, setLikedMap] = useState<Record<string,boolean>>({});
  const [countMap, setCountMap] = useState<Record<string,number>>({});
  const [mi, setMi] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dur, setDur] = useState(0);
  const [muted, setMuted] = useState(false);
  const [scrubbing, setScrubbing] = useState(false);
  const scrubRef = useRef<HTMLDivElement>(null);
  const [commentOpen, setCommentOpen] = useState(false);
  const vidRef = useRef<HTMLVideoElement>(null);
  const ty = useRef(0);
  const tx = useRef(0);

  const post = posts[ci] || initialPost;
  const liked = likedMap[post.id] ?? (post.isLiked || false);
  const lc = countMap[post.id] ?? (post.likeCount || 0);
  const media = post.mediaUrls || [];
  const cur = media[mi] || '';
  const isV = cur && isVid(cur);
  const isOwn = post.user?.username === meUsername;

  useEffect(() => { document.body.style.overflow = 'hidden'; document.body.setAttribute('data-post-open', '1'); return () => { document.body.style.overflow = ''; document.body.removeAttribute('data-post-open'); }; }, []);
  useEffect(() => { setMi(0); setProgress(0); setPlaying(false); if (vidRef.current) { vidRef.current.pause(); vidRef.current.currentTime = 0; } }, [ci]);

  async function toggleLike() {
        const res = await apiFetch(`${API}/posts/${post.id}/like`, { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      setLikedMap(m => ({ ...m, [post.id]: data.data.liked }));
      setCountMap(m => ({ ...m, [post.id]: data.data.liked ? lc + 1 : Math.max(0, lc - 1) }));
    }
  }

  const fmt = (s: number) => `${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,'0')}`;

  return (
    <div style={{ position:'fixed', inset:0, zIndex:1100, background:'#000', fontFamily:"-apple-system,'Segoe UI',sans-serif", touchAction:'none' }}
      onTouchStart={e => { ty.current = e.touches[0].clientY; tx.current = e.touches[0].clientX; }}
      onTouchEnd={e => {
        const dy = e.changedTouches[0].clientY - ty.current;
        const dx = e.changedTouches[0].clientX - tx.current;
        if (Math.abs(dy) > Math.abs(dx) && Math.abs(dy) > 60) {
          if (dy < 0 && ci < posts.length-1) setCi(i => i+1);
          else if (dy > 0 && ci > 0) setCi(i => i-1);
        } else if (!isV && Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 50) {
          if (dx < 0 && mi < media.length-1) setMi(i => i+1);
          else if (dx > 0 && mi > 0) setMi(i => i-1);
        }
      }}>

      {/* Header */}
      <div style={{ position:'absolute', top:0, left:0, right:0, zIndex:10, display:'flex', alignItems:'center', justifyContent:'space-between', padding:'14px 16px', background:'linear-gradient(to bottom,rgba(0,0,0,0.75),transparent)' }}>
        <button onClick={onClose} style={{ background:'none', border:'none', cursor:'pointer' }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <Avatar name={post.user?.username||'A'} url={post.user?.avatarUrl} size={32} />
          <span style={{ fontSize:14, fontWeight:700, color:'#fff' }}>{post.user?.username}</span>
        </div>
        <div style={{ position:'relative' }}>
          <button
            id="post-menu-btn"
            onClick={() => {
              const m = document.getElementById('post-ctx-menu');
              if (m) m.style.display = m.style.display === 'none' ? 'block' : 'none';
            }}
            style={{ background:'rgba(255,255,255,0.12)', border:'none', cursor:'pointer', borderRadius:'50%', width:34, height:34, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>
          </button>
          <div id="post-ctx-menu" style={{ display:'none', position:'absolute', top:40, right:0, background:'#1e293b', borderRadius:12, overflow:'hidden', minWidth:140, boxShadow:'0 8px 32px rgba(0,0,0,0.5)', zIndex:20 }}>
            {isOwn && (
              <button onClick={() => { onDelete(post.id); const m=document.getElementById('post-ctx-menu'); if(m) m.style.display='none'; }}
                style={{ display:'flex', alignItems:'center', gap:10, width:'100%', padding:'13px 16px', background:'none', border:'none', cursor:'pointer', color:'#ef4444', fontSize:14, fontWeight:700, fontFamily:'inherit' }}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                Sil
              </button>
            )}
            <button onClick={async () => { const url=`${window.location.origin}/post/${post.id}`; if((navigator as any).share){try{await (navigator as any).share({title:'Axın',url});}catch{}}else{await navigator.clipboard.writeText(url);} const m=document.getElementById('post-ctx-menu'); if(m) m.style.display='none'; }}
              style={{ display:'flex', alignItems:'center', gap:10, width:'100%', padding:'13px 16px', background:'none', border:'none', cursor:'pointer', color:'#e2e8f0', fontSize:14, fontWeight:600, fontFamily:'inherit', borderTop: isOwn ? '1px solid rgba(255,255,255,0.08)' : 'none' }}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
              Paylaş
            </button>
          </div>
        </div>
      </div>

      {/* Sayğac */}
      <div style={{ position:'absolute', top:16, left:'50%', transform:'translateX(-50%)', zIndex:11, background:'rgba(0,0,0,0.5)', borderRadius:99, padding:'3px 10px' }}>
        <span style={{ color:'#fff', fontSize:12 }}>{ci+1} / {posts.length}</span>
      </div>

      {/* Media — tam ekran */}
      <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', overflow:'hidden' }}>
        {media.length === 0 ? (
          <div style={{ padding:32, background:grad(post.user?.username||'A'), borderRadius:20, maxWidth:'85%', margin:'0 20px' }}>
            <p style={{ color:'#fff', fontSize:17, fontWeight:600, lineHeight:1.7, textAlign:'center' }}>{post.content}</p>
          </div>
        ) : isV ? (
          <div style={{ width:'100%', height:'100%', position:'relative' }}
            onClick={() => { if (!vidRef.current) return; if (playing) { vidRef.current.pause(); setPlaying(false); } else { vidRef.current.play(); setPlaying(true); } }}>
            <video ref={vidRef} src={cur} muted={muted} playsInline loop
              onTimeUpdate={() => { if (vidRef.current) setProgress(vidRef.current.currentTime/(vidRef.current.duration||1)*100); }}
              onLoadedMetadata={e => setDur((e.target as HTMLVideoElement).duration)}
              style={{ position:'absolute', inset:0, width:'100%', height:'100%', objectFit:'cover' }} />
            {!playing && (
              <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', pointerEvents:'none' }}>
                <div style={{ width:64, height:64, borderRadius:'50%', background:'rgba(0,0,0,0.45)', backdropFilter:'blur(6px)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                </div>
              </div>
            )}
          </div>
        ) : (
          <img src={cur} style={{ maxWidth:'100%', maxHeight:'100%', objectFit:'contain' }} />
        )}

        {/* Keçid oxları */}
        {ci > 0 && (
          <button onClick={e => { e.stopPropagation(); setCi(i=>i-1); }}
            style={{ position:'absolute', top:'50%', left:12, transform:'translateY(-50%)', background:'rgba(0,0,0,0.45)', border:'none', borderRadius:'50%', width:36, height:36, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"><polyline points="18 15 12 9 6 15"/></svg>
          </button>
        )}
        {ci < posts.length-1 && (
          <button onClick={e => { e.stopPropagation(); setCi(i=>i+1); }}
            style={{ position:'absolute', bottom:20, left:'50%', transform:'translateX(-50%)', background:'rgba(0,0,0,0.45)', border:'none', borderRadius:'50%', width:36, height:36, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"><polyline points="6 9 12 15 18 9"/></svg>
          </button>
        )}

        {/* Media nöqtələri */}
        {media.length > 1 && (
          <div style={{ position:'absolute', bottom:12, left:0, right:0, display:'flex', justifyContent:'center', gap:5 }}>
            {media.map((_:any,i:number) => (
              <div key={i} onClick={() => setMi(i)} style={{ width:i===mi?16:6, height:6, borderRadius:99, background:i===mi?'#fff':'rgba(255,255,255,0.4)', cursor:'pointer', transition:'all 0.2s' }} />
            ))}
          </div>
        )}
      </div>



      {/* Alt — scrubber + action bar — videonun üstündə overlay */}
      <div style={{ position:'absolute', bottom:0, left:0, right:0, zIndex:15, background:'linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.4) 70%, transparent 100%)', paddingBottom:'calc(12px + env(safe-area-inset-bottom))' }}>

        {/* ── Video Scrubber ── */}
        {isV && (
          <div style={{ padding:'10px 16px 4px' }}>
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
              <span style={{ color:'rgba(255,255,255,0.7)', fontSize:11, fontVariantNumeric:'tabular-nums', minWidth:34 }}>{fmt((progress/100)*(dur||0))}</span>

              {/* Seek bar */}
              <div
                ref={scrubRef}
                style={{ flex:1, height:28, display:'flex', alignItems:'center', cursor:'pointer', position:'relative' }}
                onPointerDown={e => {
                  setScrubbing(true);
                  (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
                  if (!vidRef.current || !scrubRef.current) return;
                  const r = scrubRef.current.getBoundingClientRect();
                  const pct = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
                  vidRef.current.currentTime = pct * vidRef.current.duration;
                  setProgress(pct * 100);
                }}
                onPointerMove={e => {
                  if (!scrubbing || !vidRef.current || !scrubRef.current) return;
                  const r = scrubRef.current.getBoundingClientRect();
                  const pct = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
                  vidRef.current.currentTime = pct * vidRef.current.duration;
                  setProgress(pct * 100);
                }}
                onPointerUp={() => setScrubbing(false)}
              >
                {/* Track */}
                <div style={{ position:'absolute', left:0, right:0, height:3, borderRadius:99, background:'rgba(255,255,255,0.2)' }}>
                  {/* Buffered illüziyası */}
                  <div style={{ position:'absolute', left:0, width:`${Math.min(progress+12,100)}%`, height:'100%', borderRadius:99, background:'rgba(255,255,255,0.15)' }} />
                  {/* Progress */}
                  <div style={{ position:'absolute', left:0, width:`${progress}%`, height:'100%', borderRadius:99, background:'#6366f1', transition: scrubbing ? 'none' : 'width 0.1s linear' }} />
                </div>
                {/* Thumb */}
                <div style={{
                  position:'absolute',
                  left:`calc(${progress}% - ${scrubbing ? 10 : 7}px)`,
                  width: scrubbing ? 20 : 14,
                  height: scrubbing ? 20 : 14,
                  borderRadius:'50%',
                  background:'#fff',
                  boxShadow:'0 0 6px rgba(99,102,241,0.8)',
                  transition: scrubbing ? 'none' : 'all 0.1s linear',
                  top:'50%',
                  transform:'translateY(-50%)',
                }} />
              </div>

              <span style={{ color:'rgba(255,255,255,0.7)', fontSize:11, fontVariantNumeric:'tabular-nums', minWidth:34, textAlign:'right' }}>{fmt(dur||0)}</span>

              {/* Səs */}
              <button onClick={() => { setMuted(m=>!m); if(vidRef.current) vidRef.current.muted=!muted; }}
                style={{ background:'none', border:'none', cursor:'pointer', color:'rgba(255,255,255,0.75)', padding:0, flexShrink:0 }}>
                {muted
                  ? <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>
                  : <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
                }
              </button>
            </div>
          </div>
        )}

        {/* Aksiyalar */}
        <div style={{ display:'flex', alignItems:'center', gap:18, marginBottom:8, padding:'0 14px' }}>
          {/* Bəyən */}
          <button onClick={toggleLike}
            style={{ background:'none', border:'none', cursor:'pointer', display:'flex', flexDirection:'column', alignItems:'center', gap:2, color:liked?'#f43f5e':'#fff', fontFamily:'inherit', padding:0 }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill={liked?'#f43f5e':'none'} stroke={liked?'#f43f5e':'#fff'} strokeWidth="2" strokeLinecap="round" style={{ transition:'transform 0.15s' }}>
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
            <span style={{ fontSize:11, fontWeight:700 }}>{lc}</span>
          </button>

          {/* Şərh */}
          <button onClick={() => setCommentOpen(true)}
            style={{ background:'none', border:'none', cursor:'pointer', display:'flex', flexDirection:'column', alignItems:'center', gap:2, color:'#fff', fontFamily:'inherit', padding:0 }}>
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <span style={{ fontSize:11, fontWeight:700 }}>{post.replyCount||0}</span>
          </button>

          {/* Paylaş */}
          <button onClick={async () => {
            const url = `${window.location.origin}/post/${post.id}`;
            if ((navigator as any).share) {
              try { await (navigator as any).share({ title: 'Axın', url }); } catch {}
            } else {
              await navigator.clipboard.writeText(url);
              alert('Link kopyalandı!');
            }
          }}
            style={{ background:'none', border:'none', cursor:'pointer', display:'flex', flexDirection:'column', alignItems:'center', gap:2, color:'#fff', fontFamily:'inherit', padding:0 }}>
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
            <span style={{ fontSize:11, fontWeight:700 }}>Paylaş</span>
          </button>

          {/* Sağda yer */}
          {post.location && (
            <div style={{ marginLeft:'auto', display:'flex', alignItems:'center', gap:4, color:'#10b981', fontSize:12, fontWeight:600 }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              {post.location}
            </div>
          )}
        </div>

        {/* Mətn */}
        {post.content && (
          <p style={{ color:'#fff', fontSize:13, lineHeight:1.55, margin:'0 14px 4px', opacity:0.9 }}>
            <span style={{ fontWeight:700, marginRight:5 }}>{post.user?.username}</span>
            {post.content}
          </p>
        )}
      </div>

      {/* Şərh paneli */}
      {commentOpen && (
        <CommentPanelModal post={post} me={me} onClose={() => setCommentOpen(false)} />
      )}
    </div>
  );
}



// ── Şərh Panel Modal ──
function CommentPanelModal({ post, me, onClose }: { post: any; me: any; onClose: () => void }) {
  
  const [replies, setReplies] = useState<any[]>([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);

  useEffect(() => {
    fetch(`${API}/posts/${post.id}/replies`)
      .then(r => r.json())
      .then(d => { if (d.success) setReplies(d.data?.replies || []); })
      .finally(() => setFetching(false));
  }, []);

  async function send() {
    if (!text.trim() || loading) return;
    setLoading(true);
        const res = await apiFetch(`${API}/posts`, { method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` },
      body: JSON.stringify({ content: text.trim(), parentId: post.id }),
    });
    const data = await res.json();
    if (data.success) {
      setReplies(prev => [...prev, { ...data.data, user: me, createdAt: new Date().toISOString() }]);
      setText('');
    }
    setLoading(false);
  }

  function timeAgo(iso: string) {
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 60) return `${~~s}s`;
    if (s < 3600) return `${~~(s/60)}dəq`;
    if (s < 86400) return `${~~(s/3600)}saat`;
    return new Date(iso).toLocaleDateString('az-AZ', { day:'numeric', month:'short' });
  }

  return (
    <div style={{ position:'fixed', inset:0, zIndex:600, display:'flex', flexDirection:'column', justifyContent:'flex-end' }}>
      <div onClick={onClose} style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.5)' }} />
      <div style={{ position:'relative', background:'#fff', borderRadius:'16px 16px 0 0', height:'70vh', display:'flex', flexDirection:'column', animation:'slideUpC 0.28s ease-out' }}>
        <style>{`@keyframes slideUpC{from{transform:translateY(100%)}to{transform:translateY(0)}}`}</style>
        <div style={{ paddingTop:10, display:'flex', justifyContent:'center', flexShrink:0 }}>
          <div style={{ width:40, height:4, borderRadius:99, background:'#e2e8f0' }} />
        </div>
        <div style={{ padding:'8px 20px 12px', display:'flex', alignItems:'center', justifyContent:'space-between', borderBottom:'1px solid #f1f5f9', flexShrink:0 }}>
          <div style={{ width:32 }} />
          <span style={{ fontSize:15, fontWeight:800, color:'#0f172a' }}>{replies.length} şərh</span>
          <button onClick={onClose} style={{ background:'#f1f5f9', border:'none', borderRadius:'50%', width:32, height:32, cursor:'pointer', color:'#94a3b8', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
        <div style={{ flex:1, overflowY:'auto' }}>
          {fetching ? <div style={{ padding:30, textAlign:'center', color:'#94a3b8', fontSize:14 }}>Yüklənir...</div>
            : replies.length === 0 ? <div style={{ textAlign:'center', padding:'40px 20px', color:'#94a3b8' }}><div style={{ fontSize:36, marginBottom:8 }}>💬</div><div style={{ fontSize:14 }}>İlk şərhi sən yaz!</div></div>
            : replies.map((r, i) => (
              <div key={r.id || i} style={{ padding:'12px 16px', display:'flex', gap:10, borderBottom:'1px solid #f8fafc' }}>
                <Avatar name={r.user?.username || 'A'} url={r.user?.avatarUrl} size={36} />
                <div style={{ flex:1 }}>
                  <div style={{ marginBottom:3 }}>
                    <span style={{ fontWeight:700, fontSize:13, color:'#0f172a', marginRight:6 }}>{r.user?.username}</span>
                    <span style={{ fontSize:12, color:'#94a3b8' }}>{timeAgo(r.createdAt)}</span>
                  </div>
                  <div style={{ fontSize:14, color:'#0f172a', lineHeight:1.5 }}>{r.content}</div>
                </div>
              </div>
            ))}
        </div>
        <div style={{ padding:'10px 16px', paddingBottom:'calc(12px + env(safe-area-inset-bottom))', borderTop:'1px solid #f1f5f9', display:'flex', alignItems:'center', gap:10, flexShrink:0 }}>
          <Avatar name={me?.username || 'A'} url={me?.avatarUrl} size={36} />
          <div style={{ flex:1, background:'#f1f5f9', borderRadius:24, padding:'9px 16px', display:'flex', alignItems:'center', gap:8 }}>
            <input value={text} onChange={e => setText(e.target.value)} placeholder="Şərh əlavə edin..." maxLength={500}
              onKeyDown={e => { if (e.key === 'Enter') send(); }}
              style={{ flex:1, background:'transparent', border:'none', outline:'none', fontSize:14, color:'#0f172a', fontFamily:'inherit' }} />
          </div>
          <button onClick={send} disabled={!text.trim() || loading}
            style={{ background:text.trim()?'#6366f1':'#e2e8f0', border:'none', borderRadius:'50%', width:36, height:36, cursor:text.trim()?'pointer':'default', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={text.trim()?'#fff':'#94a3b8'} strokeWidth="2.5" strokeLinecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Profile() {
  const router = useRouter();
  const { username } = useParams() as { username: string };
  const [profile, setProfile] = useState<any>(null);
  const [me, setMe] = useState<any>(null);
  const [following, setFollowing] = useState(false);
  const [followStatus, setFollowStatus] = useState<string|null>(null);
  const [isMutual, setIsMutual] = useState(false);
  const [followsYou, setFollowsYou] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [blockConfirm, setBlockConfirm] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);
  const [copied, setCopied] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);
  const [tab, setTab] = useState<Tab>('posts');
  const [posts, setPosts] = useState<any[]>([]);
  const [likes, setLikes] = useState<any[]>([]);
  const [followers, setFollowers] = useState<any[]>([]);
  const [followingList, setFollowingList] = useState<any[]>([]);
  const [loaded, setLoaded] = useState<Record<string, boolean>>({});
  const [selectedPost, setSelectedPost] = useState<any>(null);
  const [avatarModal, setAvatarModal] = useState(false);
  const [bookmarks, setBookmarks] = useState<any[]>([]);

  useEffect(() => {
        if (!getToken()) { router.push('/'); return; }
    apiFetch(`${API}/auth/me`)
      .then(r => r.json()).then(d => { if (d.success) setMe(d.data); })
      .catch(() => {}); // auth-provider handles session, not profile page
    // Profili JWT ilə fetch et — isFollowing, followStatus, isMutual qaytarır
    apiFetch(`${API}/users/${username}`)
      .then(async r => {
        if (r.status === 403) {
          // Blocked — show restricted view, do NOT redirect or clear auth
          setProfile({ username, isRestricted: true } as any);
          return;
        }
        const d = await r.json();
        if (d.success) {
          setProfile(d.data);
          setFollowing(d.data.isFollowing ?? false);
          setFollowStatus(d.data.followStatus ?? null);
          setIsMutual(d.data.isMutual ?? false);
          setFollowsYou(d.data.followsYou ?? d.data.isFollowedBy ?? false);
          setIsBlocked(d.data.isBlocked ?? false);
        }
      })
      .catch(() => {}); // network error — silent, keep session intact
    apiFetch(`${API}/users/${username}/posts`)
      .then(r => r.json()).then(d => {
        if (d.success) { setPosts(d.data || []); setLoaded(l => ({ ...l, posts: true })); }
      }).catch(() => {});
  }, [username]);

  useEffect(() => {
    if (loaded[tab]) return;
    if (tab === 'likes') {
      apiFetch(`${API}/users/${username}/likes`)
        .then(r => r.json()).then(d => { if (d.success) { setLikes(d.data || []); setLoaded(l => ({ ...l, likes: true })); } });
    } else if (tab === 'bookmarks') {
      apiFetch(`${API}/posts/bookmarks`)
        .then(r => r.json()).then(d => { if (d.success) { setBookmarks(d.data || []); setLoaded(l => ({ ...l, bookmarks: true })); } });
    } else if (tab === 'followers') {
      apiFetch(`${API}/users/${username}/followers`)
        .then(r => r.json()).then(d => { if (d.success) { setFollowers(d.data?.items || d.data || []); setLoaded(l => ({ ...l, followers: true })); } });
    } else if (tab === 'following') {
      apiFetch(`${API}/users/${username}/following`)
        .then(r => r.json()).then(d => { if (d.success) { setFollowingList(d.data?.items || d.data || []); setLoaded(l => ({ ...l, following: true })); } });
    }
  }, [tab]);

  async function toggleFollow() {
    if (followLoading) return;
    setFollowLoading(true);
        // Optimistic update
    const wasFollowing = following;
    const wasStatus = followStatus;
    setFollowing(!wasFollowing);
    setFollowStatus(!wasFollowing ? 'accepted' : null);
    setProfile((p: any) => ({ ...p, followerCount: !wasFollowing ? p.followerCount + 1 : p.followerCount - 1 }));
    try {
      const res = await apiFetch(`${API}/users/${username}/follow`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        const nowFollowing = data.data.following ?? false;
        setFollowing(nowFollowing);
        setFollowStatus(data.data.status ?? null);
        setIsMutual(nowFollowing && followsYou);
      } else {
        // Geri qaytar
        setFollowing(wasFollowing);
        setFollowStatus(wasStatus);
        setProfile((p: any) => ({ ...p, followerCount: wasFollowing ? p.followerCount + 1 : p.followerCount - 1 }));
      }
    } catch {
      setFollowing(wasFollowing);
      setFollowStatus(wasStatus);
    }
    setFollowLoading(false);
  }
  async function toggleBlock() {
    setBlockConfirm(false);
    setMenuOpen(false);
    try {
      const res = await apiFetch(`${API}/users/${username}/block`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        if (data.data?.blocked) {
          setIsBlocked(true);
          setFollowing(false);
          setFollowStatus(null);
          router.push('/feed');
        } else {
          setIsBlocked(false);
        }
      }
    } catch {}
  }

  async function doShare() {
    const url = `${window.location.origin}/profile/${username}`;
    if ((navigator as any).share) {
      try { await (navigator as any).share({ title: `@${username} — Axın`, url }); } catch {}
    } else {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  async function copyLink() {
    const url = `${window.location.origin}/profile/${username}`;
    await navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    setMenuOpen(false);
  }



  // ── Blocked / Restricted profile ─────────────────────────
  if ((profile as any)?.isRestricted) {
    const blockedByViewer = (profile as any).blockedByViewer;
    return (
      <div style={{ minHeight:'100vh', background:'#f8fafc', fontFamily:"inherit" }}>
        {/* Minimal header */}
        <div style={{ position:'sticky', top:0, zIndex:50, background:'rgba(248,250,252,0.97)', backdropFilter:'blur(14px)', borderBottom:'1px solid #f1f5f9', padding:'13px 16px', display:'flex', alignItems:'center', gap:12 }}>
          <button onClick={() => router.back()} style={{ background:'none', border:'none', cursor:'pointer', padding:4, display:'flex' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#0f172a" strokeWidth="2.2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <span style={{ fontWeight:800, fontSize:16, color:'#0f172a' }}>@{username}</span>
        </div>

        {/* Restricted state */}
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'80px 32px', gap:16, textAlign:'center' }}>
          <div style={{ width:80, height:80, borderRadius:'50%', background:'#f1f5f9', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="1.6" strokeLinecap="round">
              <circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>
            </svg>
          </div>
          <div>
            <div style={{ fontWeight:800, fontSize:18, color:'#0f172a', marginBottom:8 }}>
              Bu hesab mövcud deyil
            </div>
            <div style={{ fontSize:14, color:'#64748b', lineHeight:1.6, maxWidth:280 }}>
              {blockedByViewer
                ? 'Siz bu istifadəçini blokladınız. Bloku açmaq üçün geri qayıdın.'
                : 'Bu istifadəçi sizə girişi məhdudlaşdırıb.'
              }
            </div>
          </div>

          {blockedByViewer && (
            <button
              onClick={async () => {
                await apiFetch(`${API}/users/${username}/block`, { method: 'POST' });
                window.location.reload();
              }}
              style={{ marginTop:8, background:'#f1f5f9', border:'1px solid #e2e8f0', borderRadius:10, padding:'10px 24px', fontSize:14, fontWeight:700, cursor:'pointer', color:'#0f172a', fontFamily:'inherit' }}>
              Bloku aç
            </button>
          )}
          <button onClick={() => router.back()}
            style={{ background:'#0f172a', color:'#fff', border:'none', borderRadius:10, padding:'10px 24px', fontSize:14, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>
            Geri
          </button>
        </div>
      </div>
    );
  }

  if (!profile) return (
    <div style={{ minHeight: '100vh', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8' }}>
      Yüklənir...
    </div>
  );

  const isMe = me?.username === username;
  const gridData = tab === 'posts' ? posts : tab === 'likes' ? likes : tab === 'bookmarks' ? bookmarks : null;
  const isVideo = (url: string) => /\.(mp4|mov|webm)$/i.test(url);

  return (
    <div style={{ minHeight: '100vh', background: '#fff', fontFamily: "-apple-system,'Segoe UI',system-ui,sans-serif" }}>
      <style>{`* { box-sizing:border-box; margin:0; padding:0; } body{background:#fff;} button{font-family:inherit;}`}</style>

      {/* Header */}
      <header style={{ position: 'sticky', top: 0, zIndex: 50, background: 'rgba(255,255,255,0.95)', backdropFilter: 'blur(12px)', padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #f1f5f9' }}>
        <button onClick={() => router.back()} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', color: '#0f172a' }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div style={{ width: 20 }} />
        <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#0f172a', padding: 4 }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></svg>
        </button>
      </header>

      <div style={{ padding: 0, margin: 0, overflowX: 'hidden' }}>

        {/* Profil info */}
        <div style={{ padding: '20px 20px 0' }}>

          {/* Avatar sol + Ad/Bio sağ */}
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, marginBottom: 16 }}>
            {/* Sol: Avatar — klikdə böyük açılır */}
            <div onClick={() => profile.avatarUrl && setAvatarModal(true)}
              style={{ width: 80, height: 80, borderRadius: '50%', overflow: 'hidden', background: grad(profile.username), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30, fontWeight: 700, color: '#fff', flexShrink: 0, cursor: profile.avatarUrl ? 'pointer' : 'default' }}>
              {profile.avatarUrl
                ? <img src={profile.avatarUrl} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : profile.username?.[0]?.toUpperCase()
              }
            </div>

            {/* Sağ: Ad + Bio + Düymə */}
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                <span style={{ fontSize: 18, fontWeight: 800, color: '#0f172a' }}>{profile.displayName || profile.username}</span>
                {profile.isVerified && (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="#3b82f6"><path d="M9 12l2 2 4-4m6 2a9 9 0 1 1-18 0 9 9 0 0 1 18 0z"/></svg>
                )}
              </div>
              <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 6 }}>@{profile.username}</div>
              {profile.bio && (
                <div style={{ fontSize: 13, lineHeight: 1.5, color: '#64748b', marginBottom: 10, whiteSpace: 'pre-wrap' as any }}>{profile.bio}</div>
              )}
              {isMe ? (
                <button onClick={() => router.push('/settings')}
                  style={{ background: '#f1f5f9', border: '1px solid #e2e8f0', borderRadius: 10, padding: '7px 18px', fontSize: 13, fontWeight: 700, cursor: 'pointer', color: '#0f172a', fontFamily: 'inherit' }}>
                  Redaktə et
                </button>
              ) : (
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <button onClick={toggleFollow} disabled={followLoading}
                    style={{ background: isMutual ? '#f0fdf4' : following ? '#f1f5f9' : followStatus==='pending' ? 'transparent' : '#0f172a', border: followStatus==='pending' ? '1.5px solid #6366f1' : isMutual ? '1.5px solid #22c55e' : 'none', borderRadius: 10, padding: '8px 16px', fontSize: 13, fontWeight: 700, cursor: 'pointer', color: isMutual ? '#16a34a' : following ? '#0f172a' : followStatus==='pending' ? '#6366f1' : '#fff', fontFamily: 'inherit', transition:'all .2s' }}>
                    {isMutual ? '✓ Qarşılıqlı' : followStatus==='pending' ? 'Gözləyir...' : following ? 'İzləyirsən' : followsYou ? 'Geri izlə' : 'İzlə'}
                  </button>
                  <button onClick={() => !isBlocked && router.push(`/messages/${profile.id}`)}
                    disabled={isBlocked}
                    style={{ background: '#f1f5f9', border: '1px solid #e2e8f0', borderRadius: 10, padding: '8px 16px', fontSize: 13, fontWeight: 700, cursor: isBlocked ? 'not-allowed' : 'pointer', color: isBlocked ? '#94a3b8' : '#0f172a', fontFamily: 'inherit', opacity: isBlocked ? 0.5 : 1 }}>
                    Mesaj
                  </button>
                  {/* ⋮ Menu */}
                  <div style={{ position: 'relative' }}>
                    <button onClick={() => setMenuOpen(m => !m)}
                      style={{ background: '#f1f5f9', border: '1px solid #e2e8f0', borderRadius: 10, width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="#475569">
                        <circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/>
                      </svg>
                    </button>
                    {menuOpen && (
                      <>
                        {/* Backdrop */}
                        <div style={{ position: 'fixed', inset: 0, zIndex: 998 }} onClick={() => setMenuOpen(false)}/>
                        {/* Dropdown */}
                        <div style={{ position: 'absolute', top: 44, right: 0, zIndex: 999, background: '#fff', borderRadius: 14, boxShadow: '0 8px 32px rgba(15,23,42,0.18)', overflow: 'hidden', minWidth: 200, animation: 'fadeIn 0.15s ease' }}>
                          {/* Share */}
                          <button onClick={doShare}
                            style={{ display: 'flex', alignItems: 'center', gap: 12, width: '100%', padding: '14px 16px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, fontWeight: 600, color: '#1e293b', fontFamily: 'inherit', borderBottom: '1px solid #f1f5f9' }}>
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                              <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/>
                            </svg>
                            Paylaş
                          </button>
                          {/* Copy link */}
                          <button onClick={copyLink}
                            style={{ display: 'flex', alignItems: 'center', gap: 12, width: '100%', padding: '14px 16px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, fontWeight: 600, color: copied ? '#10b981' : '#1e293b', fontFamily: 'inherit', borderBottom: '1px solid #f1f5f9', transition: 'color 0.2s' }}>
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                              <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                            </svg>
                            {copied ? 'Kopyalandı!' : 'Linki kopyala'}
                          </button>
                          {/* Report */}
                          <button onClick={() => { setMenuOpen(false); alert('Şikayət göndərildi. Baxacağıq.'); }}
                            style={{ display: 'flex', alignItems: 'center', gap: 12, width: '100%', padding: '14px 16px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, fontWeight: 600, color: '#f59e0b', fontFamily: 'inherit', borderBottom: '1px solid #f1f5f9' }}>
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                              <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>
                            </svg>
                            Şikayət et
                          </button>
                          {/* Block */}
                          <button onClick={() => { setMenuOpen(false); setBlockConfirm(true); }}
                            style={{ display: 'flex', alignItems: 'center', gap: 12, width: '100%', padding: '14px 16px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, fontWeight: 600, color: '#ef4444', fontFamily: 'inherit' }}>
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                              <circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>
                            </svg>
                            Blokla
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Statistika — altda, separator ilə */}
          <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: 12, paddingTop: 4 }}>
            {[
              { val: profile.followerCount || 0, label: 'İzləyici', onClick: () => setTab('followers') },
              { val: profile.followingCount || 0, label: 'İzlənilən', onClick: () => setTab('following') },
              { val: posts.reduce((acc: number, p: any) => acc + (p.likeCount || 0), 0), label: 'Bəyənmə' },
            ].map((s, i) => (
              <div key={i} onClick={s.onClick} style={{ cursor: s.onClick ? 'pointer' : 'default', textAlign: 'center', flex: 1 }}>
                <div style={{ fontSize: 20, fontWeight: 800, color: '#0f172a', lineHeight: 1.2 }}>
                  {s.val >= 1000000 ? `${(s.val/1000000).toFixed(1)}M` : s.val >= 1000 ? `${(s.val/1000).toFixed(1)}K` : s.val}
                </div>
                <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 2 }}>{s.label}</div>
              </div>
            ))}
          </div>


        </div>

        {/* Tab */}
        <div style={{ display: 'flex', borderTop: '1px solid #f1f5f9', borderBottom: '1px solid #f1f5f9' }}>
          {[
            { id: 'posts', icon: (
              <div style={{ position: 'relative', display: 'inline-flex' }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
                {posts.length > 0 && (
                  <span style={{ position: 'absolute', top: -8, right: -10, background: '#6366f1', color: '#fff', fontSize: 9, fontWeight: 800, borderRadius: 99, padding: '1px 5px', minWidth: 16, textAlign: 'center' }}>
                    {posts.length}
                  </span>
                )}
              </div>
            )},

            { id: 'bookmarks', icon: (
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
            )},
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id as Tab)}
              style={{ flex: 1, background: 'none', border: 'none', padding: '12px', cursor: 'pointer', color: tab === t.id ? '#6366f1' : '#94a3b8', borderBottom: tab === t.id ? '2px solid #6366f1' : '2px solid transparent', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {t.icon}
            </button>
          ))}
        </div>

        {/* 3 sütunlu grid */}
        {gridData !== null && (
          gridData.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '60px 20px', color: '#94a3b8' }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>{tab === 'posts' ? '📷' : tab === 'likes' ? '♥' : '🔖'}</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#475569' }}>Hələ {tab === 'posts' ? 'post' : tab === 'likes' ? 'bəyənilmiş post' : 'saxlanmış post'} yoxdur</div>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: '33.333vw 33.333vw 33.333vw', gap: '1.5px', width: '100vw', marginLeft: 0, boxSizing: 'border-box' as any }}>
              {gridData.map((post: any, idx: number) => (
                <div key={post.id} onClick={() => setSelectedPost(post)}
                  style={{ width: '33.333vw', height: '44vw', overflow: 'hidden', cursor: 'pointer', position: 'relative', background: '#e2e8f0' }}>

                  {/* Media */}
                  {post.mediaUrls?.length > 0 ? (
                    isVideo(post.mediaUrls[0]) ? (
                      <>
                        <video src={post.mediaUrls[0]} muted playsInline preload="metadata"
                          style={{ width: '33.333vw', height: '44vw', objectFit: 'cover', display: 'block', position: 'absolute', inset: 0 }} />
                        {/* Video ikonu */}
                        <div style={{ position: 'absolute', top: 6, right: 6 }}>
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff" filter="drop-shadow(0 1px 2px rgba(0,0,0,0.5))"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
                        </div>
                      </>
                    ) : (
                      <img src={post.mediaUrls[0]} alt="" style={{ width: '33.333vw', height: '44vw', objectFit: 'cover', display: 'block', position: 'absolute', inset: 0 }} />
                    )
                  ) : (
                    // Yalnız mətn post
                    <div style={{ position: 'absolute', inset: 0, background: grad(post.user?.username || 'A'), display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 8 }}>
                      <span style={{ fontSize: 11, color: '#fff', fontWeight: 600, lineHeight: 1.4, textAlign: 'center', overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 5, WebkitBoxOrient: 'vertical' as any }}>
                        {post.content}
                      </span>
                    </div>
                  )}

                  {/* Çox şəkil varsa ikonu göstər */}
                  {post.mediaUrls?.length > 1 && (
                    <div style={{ position: 'absolute', top: 6, right: 6 }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="#fff" filter="drop-shadow(0 1px 2px rgba(0,0,0,0.5))"><rect x="8" y="3" width="13" height="13" rx="2"/><path d="M3 8v10a2 2 0 0 0 2 2h10"/></svg>
                    </div>
                  )}

                  {/* Hover: like sayı */}
                  <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0)', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0, transition: 'all 0.15s' }}
                    onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.background = 'rgba(0,0,0,0.35)'; (e.currentTarget as HTMLDivElement).style.opacity = '1'; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.background = 'rgba(0,0,0,0)'; (e.currentTarget as HTMLDivElement).style.opacity = '0'; }}>
                    <span style={{ color: '#fff', fontWeight: 800, fontSize: 14 }}>♥ {post.likeCount || 0}</span>
                  </div>
                </div>
              ))}
            </div>
          )
        )}

        <div style={{ paddingBottom: 100 }} />

      {/* İzləyici / İzlənilən siyahısı */}
        {(tab === 'followers' || tab === 'following') && (
          <div style={{ padding: '4px 20px' }}>
            {(tab === 'followers' ? followers : followingList).length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 0', color: '#94a3b8' }}>
                <div style={{ fontSize: 40, marginBottom: 10 }}>👥</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#475569' }}>Hələ {tab === 'followers' ? 'izləyici' : 'izlənilən'} yoxdur</div>
              </div>
            ) : (
              (tab === 'followers' ? followers : followingList).map((u: any) => (
                <UserRow key={u.id} user={u} onNavigate={p => router.push(p)} />
              ))
            )}
          </div>
        )}
      </div>

      {/* Avatar modal */}
      {avatarModal && profile.avatarUrl && (
        <div onClick={() => setAvatarModal(false)}
          style={{ position: 'fixed', inset: 0, zIndex: 600, background: 'rgba(0,0,0,0.95)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <img src={profile.avatarUrl} style={{ width: '90vw', height: '90vw', objectFit: 'cover', borderRadius: '50%' }} />
          <button onClick={() => setAvatarModal(false)}
            style={{ position: 'absolute', top: 20, right: 20, background: 'rgba(255,255,255,0.15)', border: 'none', borderRadius: '50%', width: 40, height: 40, color: '#fff', fontSize: 20, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>✕</button>
        </div>
      )}

      {/* Post detail modal */}
      {/* ── Block confirmation modal ── */}
      {blockConfirm && (
        <>
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 2000, backdropFilter: 'blur(4px)' }}
            onClick={() => setBlockConfirm(false)}/>
          <div style={{ position: 'fixed', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', zIndex: 2001, background: '#fff', borderRadius: 20, padding: '28px 24px', width: 'min(320px, 90vw)', boxShadow: '0 20px 60px rgba(0,0,0,0.25)', animation: 'fadeIn 0.18s ease' }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: '#fef2f2', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round">
                <circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>
              </svg>
            </div>
            <h3 style={{ textAlign: 'center', fontSize: 17, fontWeight: 800, color: '#0f172a', margin: '0 0 8px', fontFamily: 'inherit' }}>
              @{username}-i blokla?
            </h3>
            <p style={{ textAlign: 'center', fontSize: 13, color: '#64748b', margin: '0 0 24px', lineHeight: 1.55 }}>
              Bu istifadəçi səni tapa bilməyəcək və profilinə baxa bilməyəcək.
            </p>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setBlockConfirm(false)}
                style={{ flex: 1, padding: '12px 0', borderRadius: 12, background: '#f1f5f9', border: 'none', fontSize: 14, fontWeight: 700, cursor: 'pointer', color: '#475569', fontFamily: 'inherit' }}>
                Ləğv et
              </button>
              <button onClick={toggleBlock}
                style={{ flex: 1, padding: '12px 0', borderRadius: 12, background: '#ef4444', border: 'none', fontSize: 14, fontWeight: 700, cursor: 'pointer', color: '#fff', fontFamily: 'inherit' }}>
                Blokla
              </button>
            </div>
          </div>
        </>
      )}

      {selectedPost && (
        <ReelsViewer
          posts={posts}
          startPost={selectedPost}
          me={me}
          onClose={() => setSelectedPost(null)}
          onDelete={async (postId: string) => {
                        const res = await apiFetch(`${API}/posts/${postId}`, {
              method: 'DELETE'
            });
            if (res.ok) { setPosts((prev:any[]) => prev.filter((p:any) => p.id !== postId)); setSelectedPost(null); }
          }}
        />
      )}
    </div>
  );
}
