import { useState, useEffect, useRef, useCallback } from "react";

/* ─────────────────────────────────────────
   MOCK VIDEO DATA
   Replace `bg` with real `src` URLs
───────────────────────────────────────── */
const VIDEOS = [
  { id: 1,  user: "emin_ahmedoff",  avatar: "E", caption: "Həyat gözəldir ✨ #life #axin", likes: "48.2K", comments: "1.2K", shares: "892",  bg: "linear-gradient(160deg,#0f2027,#203a43,#2c5364)", music: "Orijinal səs · emin_ahmedoff" },
  { id: 2,  user: "aytən_xəyal",   avatar: "A", caption: "Bakı gecələri 🌆 #baku #night",  likes: "102K",  comments: "3.4K", shares: "2.1K", bg: "linear-gradient(160deg,#200122,#6f0000,#200122)", music: "Gecə — Murad Arif" },
  { id: 3,  user: "kamran.21",     avatar: "K", caption: "Dağ zirvəsi ⛰️ #nature #travel", likes: "77.5K", comments: "988",  shares: "1.5K", bg: "linear-gradient(160deg,#1a2a6c,#b21f1f,#fdbb2d)", music: "Epic Cinematic — Mix" },
  { id: 4,  user: "leyla_codes",   avatar: "L", caption: "Kod yazırıq 💻 #dev #coding",   likes: "31.1K", comments: "744",  shares: "433",  bg: "linear-gradient(160deg,#0f0c29,#302b63,#24243e)", music: "Lo-fi Beats · lofi_az" },
  { id: 5,  user: "ruslan_fit",    avatar: "R", caption: "Gym motivation 🔥 #fitness",    likes: "55.9K", comments: "2.1K", shares: "700",  bg: "linear-gradient(160deg,#134e5e,#71b280,#134e5e)", music: "Power Up — Sport Mix" },
  { id: 6,  user: "nigar.art",     avatar: "N", caption: "Rəsm çəkirəm 🎨 #art #creative", likes: "89K",   comments: "4.5K", shares: "3.2K", bg: "linear-gradient(160deg,#f7971e,#ffd200,#f7971e)", music: "Creative Vibes · nigar.art" },
  { id: 7,  user: "tural_music",   avatar: "T", caption: "Yeni mahnı 🎵 #music #azerbaijan",likes: "210K", comments: "8.7K", shares: "15K",  bg: "linear-gradient(160deg,#360033,#0b8793,#360033)", music: "Sən Olmasan — Tural M." },
];

/* ─────────────────────────────────────────
   HEART BURST ANIMATION
───────────────────────────────────────── */
function HeartBurst({ x, y, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 900); return () => clearTimeout(t); }, []);
  return (
    <div style={{ position: "absolute", left: x - 55, top: y - 55, pointerEvents: "none", zIndex: 50 }}>
      <svg width="110" height="110" viewBox="0 0 24 24" fill="#f43f5e"
        style={{ animation: "hPop .9s ease forwards", filter: "drop-shadow(0 0 18px rgba(244,63,94,.7))" }}>
        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
      </svg>
    </div>
  );
}

/* ─────────────────────────────────────────
   SEEK BAR
───────────────────────────────────────── */
function SeekBar({ progress, scrubbing, onPointerDown, onPointerMove, onPointerUp, seekRef }) {
  return (
    <div ref={seekRef}
      style={{ width: "100%", height: 22, display: "flex", alignItems: "center", position: "relative", touchAction: "none", cursor: "pointer" }}
      onPointerDown={onPointerDown} onPointerMove={onPointerMove}
      onPointerUp={onPointerUp} onPointerCancel={onPointerUp}>
      <div style={{ position: "absolute", left: 0, right: 0, height: scrubbing ? 4 : 2, borderRadius: 99, background: "rgba(255,255,255,0.22)", overflow: "hidden", transition: "height .15s" }}>
        <div style={{ position: "absolute", left: 0, width: `${progress}%`, height: "100%", background: "#fff", borderRadius: 99, transition: scrubbing ? "none" : "width .1s linear" }} />
      </div>
      <div style={{
        position: "absolute",
        left: `clamp(0px, calc(${progress}% - ${scrubbing ? 8 : 5}px), calc(100% - ${scrubbing ? 16 : 10}px))`,
        top: "50%", transform: "translateY(-50%)",
        width: scrubbing ? 16 : 10, height: scrubbing ? 16 : 10,
        borderRadius: "50%", background: "#fff",
        boxShadow: scrubbing ? "0 0 0 4px rgba(255,255,255,.2)" : "0 1px 4px rgba(0,0,0,.4)",
        transition: scrubbing ? "none" : "all .15s", pointerEvents: "none",
      }} />
    </div>
  );
}

/* ─────────────────────────────────────────
   SINGLE REEL CARD
───────────────────────────────────────── */
function ReelCard({ video, isActive, onLike, globalMuted, onMuteToggle }) {
  const vidRef    = useRef(null);
  const seekRef   = useRef(null);
  const lastTap   = useRef(0);
  const [playing,   setPlaying]   = useState(false);
  const [progress,  setProgress]  = useState(0);
  const [dur,       setDur]       = useState(0);
  const [scrubbing, setScrubbing] = useState(false);
  const [liked,     setLiked]     = useState(false);
  const [likeCount, setLikeCount] = useState(video.likes);
  const [saved,     setSaved]     = useState(false);
  const [hearts,    setHearts]    = useState([]);
  const [showUI,    setShowUI]    = useState(true);
  const hideTimer = useRef(null);

  /* auto-play when active */
  useEffect(() => {
    const v = vidRef.current;
    if (!v) return;
    if (isActive) {
      v.play().then(() => setPlaying(true)).catch(() => {});
      resetHideUI();
    } else {
      v.pause(); v.currentTime = 0;
      setPlaying(false); setProgress(0);
    }
  }, [isActive]);

  /* sync global mute */
  useEffect(() => {
    if (vidRef.current) vidRef.current.muted = globalMuted;
  }, [globalMuted]);

  function resetHideUI() {
    setShowUI(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setShowUI(false), 3500);
  }

  function handleTap(e) {
    resetHideUI();
    const now = Date.now();
    if (now - lastTap.current < 320) {
      // double tap — like + heart burst
      if (!liked) { setLiked(true); onLike?.(); }
      const rect = e.currentTarget.getBoundingClientRect();
      const hx = e.clientX - rect.left;
      const hy = e.clientY - rect.top;
      setHearts(h => [...h, { id: Date.now(), x: hx, y: hy }]);
    } else {
      // single tap — play/pause
      const v = vidRef.current;
      if (!v) return;
      if (playing) { v.pause(); setPlaying(false); }
      else { v.play().then(() => setPlaying(true)).catch(() => {}); }
    }
    lastTap.current = now;
  }

  /* seek */
  function getSeekPct(clientX) {
    if (!seekRef.current) return 0;
    const { left, width } = seekRef.current.getBoundingClientRect();
    return Math.max(0, Math.min(100, ((clientX - left) / width) * 100));
  }
  function onSeekDown(e) {
    e.stopPropagation();
    seekRef.current?.setPointerCapture(e.pointerId);
    setScrubbing(true);
    if (vidRef.current) vidRef.current.currentTime = (getSeekPct(e.clientX) / 100) * vidRef.current.duration;
  }
  function onSeekMove(e) {
    if (!scrubbing) return;
    if (vidRef.current) vidRef.current.currentTime = (getSeekPct(e.clientX) / 100) * vidRef.current.duration;
  }
  function onSeekUp() { setScrubbing(false); }

  const fmt = s => `${~~(s / 60)}:${String(~~(s % 60)).padStart(2, "0")}`;
  const fmtN = n => typeof n === "string" ? n : n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e3 ? (n / 1e3).toFixed(1) + "K" : String(n);

  /* avatar gradient */
  const colors = ["#6366f1","#ec4899","#10b981","#f59e0b","#3b82f6","#8b5cf6","#ef4444"];
  const avatarColor = colors[video.user.charCodeAt(0) % colors.length];

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", overflow: "hidden", background: video.bg }}
      onClick={handleTap}>

      {/* video or gradient bg */}
      {video.src ? (
        <video ref={vidRef} src={video.src} loop playsInline muted={globalMuted}
          onTimeUpdate={() => { if (vidRef.current) setProgress(vidRef.current.currentTime / (vidRef.current.duration || 1) * 100); }}
          onLoadedMetadata={e => setDur(e.target.duration)}
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
      ) : (
        /* demo: animated gradient + waveform visual */
        <div style={{ position: "absolute", inset: 0 }}>
          <div style={{ position: "absolute", inset: 0, background: video.bg, animation: "bgPulse 4s ease-in-out infinite alternate" }} />
          {/* fake waveform bars */}
          <div style={{ position: "absolute", bottom: "38%", left: "50%", transform: "translateX(-50%)", display: "flex", gap: 3, alignItems: "center" }}>
            {Array.from({ length: 28 }).map((_, i) => (
              <div key={i} style={{
                width: 3, borderRadius: 99,
                background: "rgba(255,255,255,0.55)",
                height: `${16 + Math.sin(i * 0.8 + (isActive ? Date.now() / 200 : 0)) * 14}px`,
                animation: isActive ? `wave ${0.4 + (i % 5) * 0.08}s ease-in-out infinite alternate` : "none",
                animationDelay: `${i * 0.03}s`,
              }} />
            ))}
          </div>
        </div>
      )}

      {/* gradient overlays */}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(0,0,0,.35) 0%, transparent 30%, transparent 45%, rgba(0,0,0,.8) 100%)", pointerEvents: "none" }} />

      {/* heart bursts */}
      {hearts.map(h => (
        <HeartBurst key={h.id} x={h.x} y={h.y} onDone={() => setHearts(hs => hs.filter(x => x.id !== h.id))} />
      ))}

      {/* play/pause icon */}
      {!playing && (
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", pointerEvents: "none", zIndex: 5 }}>
          <div style={{ width: 70, height: 70, borderRadius: "50%", background: "rgba(0,0,0,.4)", backdropFilter: "blur(10px)", display: "flex", alignItems: "center", justifyContent: "center", border: "1.5px solid rgba(255,255,255,.2)" }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff" style={{ marginLeft: 4 }}><polygon points="5 3 19 12 5 21" /></svg>
          </div>
        </div>
      )}

      {/* ── TOP: mute button ── */}
      <div style={{ position: "absolute", top: 16, right: 14, zIndex: 20, opacity: showUI ? 1 : 0, transition: "opacity .3s" }}
        onClick={e => { e.stopPropagation(); onMuteToggle(); }}>
        <div style={{ width: 38, height: 38, borderRadius: "50%", background: "rgba(0,0,0,.4)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid rgba(255,255,255,.15)" }}>
          {globalMuted
            ? <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>
            : <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
          }
        </div>
      </div>

      {/* ── RIGHT: action buttons ── */}
      <div style={{ position: "absolute", right: 12, bottom: 100, zIndex: 20, display: "flex", flexDirection: "column", alignItems: "center", gap: 20 }}
        onClick={e => e.stopPropagation()}>

        {/* avatar */}
        <div style={{ position: "relative", marginBottom: 4 }}>
          <div style={{ width: 48, height: 48, borderRadius: "50%", background: avatarColor, border: "2.5px solid #fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 800, color: "#fff", overflow: "hidden", cursor: "pointer" }}>
            {video.avatar}
          </div>
          <div style={{ position: "absolute", bottom: -10, left: "50%", transform: "translateX(-50%)", width: 22, height: 22, borderRadius: "50%", background: "#fe2c55", border: "2px solid #000", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="10" height="10" viewBox="0 0 24 24" fill="#fff"><line x1="12" y1="5" x2="12" y2="19" stroke="#fff" strokeWidth="3" strokeLinecap="round"/><line x1="5" y1="12" x2="19" y2="12" stroke="#fff" strokeWidth="3" strokeLinecap="round"/></svg>
          </div>
        </div>

        {/* like */}
        {[
          {
            icon: <svg width="30" height="30" viewBox="0 0 24 24" fill={liked ? "#fe2c55" : "none"} stroke={liked ? "#fe2c55" : "#fff"} strokeWidth="1.6"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" strokeLinecap="round"/></svg>,
            label: likeCount,
            action: () => { const next = !liked; setLiked(next); },
            active: liked, activeColor: "#fe2c55",
          },
          {
            icon: <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.6" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
            label: video.comments, action: () => {},
          },
          {
            icon: <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.6" strokeLinecap="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>,
            label: video.shares, action: () => {},
          },
          {
            icon: <svg width="24" height="24" viewBox="0 0 24 24" fill={saved ? "#ffcc00" : "none"} stroke={saved ? "#ffcc00" : "#fff"} strokeWidth="1.6" strokeLinecap="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>,
            label: "Saxla", action: () => setSaved(s => !s),
          },
        ].map(({ icon, label, action, active, activeColor }, i) => (
          <button key={i} onClick={action} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 4, padding: 0 }}>
            <div style={{ width: 50, height: 50, borderRadius: "50%", background: active ? `${activeColor}22` : "rgba(255,255,255,.1)", backdropFilter: "blur(6px)", border: `1px solid ${active ? activeColor + "44" : "rgba(255,255,255,.12)"}`, display: "flex", alignItems: "center", justifyContent: "center", transition: "all .2s cubic-bezier(.34,1.56,.64,1)" }}>
              {icon}
            </div>
            <span style={{ color: "#fff", fontSize: 11, fontWeight: 700, textShadow: "0 1px 4px rgba(0,0,0,.6)" }}>{label}</span>
          </button>
        ))}

        {/* spinning disc */}
        <div style={{ width: 44, height: 44, borderRadius: "50%", background: "linear-gradient(135deg,#333,#111)", border: "3px solid #555", display: "flex", alignItems: "center", justifyContent: "center", animation: isActive && playing ? "spin 4s linear infinite" : "none", overflow: "hidden" }}>
          <div style={{ width: "100%", height: "100%", borderRadius: "50%", background: avatarColor, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 800, color: "#fff" }}>
            {video.avatar}
          </div>
        </div>
      </div>

      {/* ── BOTTOM: user info + music + seekbar ── */}
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 80, zIndex: 20, padding: "0 16px 0" }}
        onClick={e => e.stopPropagation()}>
        <div style={{ marginBottom: 6 }}>
          <span style={{ color: "#fff", fontWeight: 800, fontSize: 15, fontFamily: "'Outfit', sans-serif", textShadow: "0 1px 6px rgba(0,0,0,.6)" }}>@{video.user}</span>
        </div>
        <p style={{ color: "rgba(255,255,255,.88)", fontSize: 13, lineHeight: 1.55, margin: "0 0 10px", textShadow: "0 1px 6px rgba(0,0,0,.5)", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
          {video.caption}
        </p>
        {/* music row */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="#fff"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
          <span style={{ color: "rgba(255,255,255,.75)", fontSize: 12, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{video.music}</span>
        </div>
      </div>

      {/* ── SEEK BAR — full width at very bottom ── */}
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 22, padding: "0 0 6px" }}
        onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", padding: "0 14px 2px" }}>
          <span style={{ color: "rgba(255,255,255,.45)", fontSize: 9, fontVariantNumeric: "tabular-nums" }}>{fmt((progress / 100) * (dur || 0))}</span>
          <span style={{ color: "rgba(255,255,255,.3)", fontSize: 9, fontVariantNumeric: "tabular-nums" }}>{fmt(dur || 0)}</span>
        </div>
        <div style={{ padding: "0 0" }}>
          <SeekBar progress={progress} scrubbing={scrubbing} seekRef={seekRef}
            onPointerDown={onSeekDown} onPointerMove={onSeekMove} onPointerUp={onSeekUp} />
        </div>
      </div>

      <style>{`
        @keyframes hPop   { 0%{transform:scale(0);opacity:0} 30%{transform:scale(1.4);opacity:1} 60%{transform:scale(1);opacity:1} 100%{transform:scale(1.1);opacity:0} }
        @keyframes wave   { from{transform:scaleY(.3)} to{transform:scaleY(1)} }
        @keyframes spin   { to{transform:rotate(360deg)} }
        @keyframes bgPulse{ from{filter:brightness(.9)} to{filter:brightness(1.1)} }
      `}</style>
    </div>
  );
}

/* ─────────────────────────────────────────
   MAIN FEED
───────────────────────────────────────── */
export default function TikTokFeed() {
  const containerRef  = useRef(null);
  const [activeIdx,   setActiveIdx]   = useState(0);
  const [feed,        setFeed]        = useState(VIDEOS);
  const [globalMuted, setGlobalMuted] = useState(false);
  const [transitioning, setTransitioning] = useState(false);

  // touch state
  const touchStartY = useRef(0);
  const touchStartTime = useRef(0);
  const isDragging  = useRef(false);
  const [dragDelta, setDragDelta] = useState(0);

  /* infinite feed — append more when near end */
  useEffect(() => {
    if (activeIdx >= feed.length - 3) {
      setFeed(prev => [
        ...prev,
        ...VIDEOS.map(v => ({ ...v, id: Date.now() + v.id, _dupe: true })),
      ]);
    }
  }, [activeIdx]);

  /* CSS snap scroll — track active index on scroll */
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const idx = Math.round(el.scrollTop / window.innerHeight);
        setActiveIdx(idx);
        ticking = false;
      });
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  /* programmatic navigate */
  const goTo = useCallback((idx) => {
    if (transitioning) return;
    const el = containerRef.current;
    if (!el) return;
    setTransitioning(true);
    el.scrollTo({ top: idx * window.innerHeight, behavior: "smooth" });
    setActiveIdx(idx);
    setTimeout(() => setTransitioning(false), 450);
  }, [transitioning]);

  /* keyboard navigation */
  useEffect(() => {
    const onKey = e => {
      if (e.key === "ArrowDown" || e.key === "ArrowRight") goTo(Math.min(activeIdx + 1, feed.length - 1));
      if (e.key === "ArrowUp"   || e.key === "ArrowLeft")  goTo(Math.max(activeIdx - 1, 0));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [activeIdx, feed.length, goTo]);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #000; overflow: hidden; font-family: 'Outfit', sans-serif; }
      `}</style>

      {/* scroll container with CSS snap */}
      <div ref={containerRef} style={{
        width: "100%", height: "100vh",
        overflowY: "scroll",
        scrollSnapType: "y mandatory",
        scrollBehavior: "auto",         /* we handle smooth ourselves */
        WebkitOverflowScrolling: "touch",
        background: "#000",
      }}>
        {feed.map((video, i) => (
          <div key={`${video.id}-${i}`} style={{
            width: "100%", height: "100vh",
            scrollSnapAlign: "start",
            scrollSnapStop: "always",
            flexShrink: 0,
            position: "relative",
            overflow: "hidden",
          }}>
            {/* only render ±2 from active for perf */}
            {Math.abs(i - activeIdx) <= 2 && (
              <ReelCard
                video={video}
                isActive={i === activeIdx}
                globalMuted={globalMuted}
                onMuteToggle={() => setGlobalMuted(m => !m)}
                onLike={() => {}}
              />
            )}
          </div>
        ))}
      </div>

      {/* progress dots — right side */}
      <div style={{
        position: "fixed", right: 6, top: "50%", transform: "translateY(-50%)",
        display: "flex", flexDirection: "column", gap: 4, zIndex: 100,
        pointerEvents: "none",
      }}>
        {feed.slice(Math.max(0, activeIdx - 3), activeIdx + 4).map((_, i) => {
          const absI = Math.max(0, activeIdx - 3) + i;
          const isAct = absI === activeIdx;
          return (
            <div key={absI} style={{
              width: isAct ? 3 : 2,
              height: isAct ? 18 : 5,
              borderRadius: 99,
              background: isAct ? "#fff" : "rgba(255,255,255,.35)",
              transition: "all .2s",
            }} />
          );
        })}
      </div>
    </>
  );
}
