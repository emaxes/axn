'use client';
import { getToken, apiFetch, clearSession } from '../../lib/auth';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useUnread } from '../unread-provider';

const API = 'http://localhost:3001/api/v1';

const PAL: [string, string][] = [
  ['#6366f1','#a5b4fc'],['#ec4899','#fbcfe8'],
  ['#10b981','#a7f3d0'],['#f59e0b','#fde68a'],
  ['#3b82f6','#bfdbfe'],['#8b5cf6','#ddd6fe'],
];
const grad = (name = 'A') => {
  const [a, b] = PAL[name.charCodeAt(0) % PAL.length];
  return `linear-gradient(135deg, ${a}, ${b})`;
};
const fmt = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : String(n || 0);

// ── SVG İkonlar ──────────────────────────────────────
const IHeart = ({ filled }: { filled: boolean }) => filled
  ? <svg width="20" height="20" viewBox="0 0 24 24" fill="#f43f5e"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
  : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>;

const IComment = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;

const IRepost = ({ active }: { active: boolean }) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={active ? '#10b981' : 'currentColor'} strokeWidth="1.8" strokeLinecap="round">
    <polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/>
    <polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/>
  </svg>
);

const IBookmark = ({ filled }: { filled: boolean }) => filled
  ? <svg width="20" height="20" viewBox="0 0 24 24" fill="#6366f1"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
  : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>;

const IShare = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>;

const IImage = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>;

function Avatar({ name, url, size }: { name: string; url?: string; size: number }) {
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', overflow: 'hidden', background: grad(name), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size * 0.38, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
      {url ? <img src={url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : name?.[0]?.toUpperCase()}
    </div>
  );
}

// ── Tam ekran şəkil modalı ──────────────────────────
function ImageModal({ src, onClose }: { src: string; onClose: () => void }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', h);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', h);
      document.body.style.overflow = '';
    };
  }, [onClose]);
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.97)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      onClick={onClose}>
      <button onClick={onClose}
        style={{ position: 'absolute', top: 16, right: 16, background: 'rgba(255,255,255,0.15)', border: 'none', borderRadius: '50%', width: 42, height: 42, cursor: 'pointer', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000, fontSize: 18 }}>✕</button>
      <img src={src} alt=""
        onClick={e => e.stopPropagation()}
        style={{ maxWidth: '100vw', maxHeight: '100vh', objectFit: 'contain', display: 'block' }}
        onError={e => { (e.target as HTMLImageElement).style.border = '2px solid red'; }}
      />
    </div>
  );
}

// ── Story Viewer (tam ekran) ──────────────────────────
function StoryViewer({ groups, startIdx, onClose, me }: {
  groups: any[]; startIdx: number; onClose: () => void; me: any;
}) {
  const [groupIdx, setGroupIdx] = useState(startIdx);
  const [storyIdx, setStoryIdx] = useState(0);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef<any>(null);
  const DURATION = 5000; // 5 saniyə

  const group = groups[groupIdx];
  const story = group?.stories[storyIdx];

  useEffect(() => {
    setProgress(0);
    clearInterval(timerRef.current);
    const startTime = Date.now();
    timerRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const p = Math.min((elapsed / DURATION) * 100, 100);
      setProgress(p);
      if (elapsed >= DURATION) {
        clearInterval(timerRef.current);
        // setTimeout ilə render-dən kənarda çağır
        setTimeout(() => {
          setStoryIdx(prev => {
            const group = groups[groupIdx];
            if (prev < group.stories.length - 1) return prev + 1;
            setGroupIdx(gi => {
              if (gi < groups.length - 1) {
                setStoryIdx(0);
                return gi + 1;
              }
              onClose();
              return gi;
            });
            return prev;
          });
        }, 0);
      }
    }, 50);
    return () => clearInterval(timerRef.current);
  }, [groupIdx, storyIdx]);

  function nextStory() {
    clearInterval(timerRef.current);
    if (storyIdx < group.stories.length - 1) {
      setStoryIdx(i => i + 1);
    } else if (groupIdx < groups.length - 1) {
      setGroupIdx(i => i + 1);
      setStoryIdx(0);
    } else {
      onClose();
    }
  }

  function prevStory2() {
    clearInterval(timerRef.current);
    if (storyIdx > 0) setStoryIdx(i => i - 1);
    else if (groupIdx > 0) { setGroupIdx(i => i - 1); setStoryIdx(0); }
  }

  function prevStory() {
    if (storyIdx > 0) setStoryIdx(i => i - 1);
    else if (groupIdx > 0) { setGroupIdx(i => i - 1); setStoryIdx(0); }
  }

  if (!story) return null;

  const timeLeft = Math.round((100 - progress) / 100 * DURATION / 1000);
  const PAL: [string,string][] = [['#6366f1','#a5b4fc'],['#ec4899','#fbcfe8'],['#10b981','#a7f3d0'],['#f59e0b','#fde68a']];
  const grad2 = (n='A') => { const [a,b]=PAL[n.charCodeAt(0)%PAL.length]; return `linear-gradient(135deg,${a},${b})`; };

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 500, background: '#000', display: 'flex', flexDirection: 'column' }}>
      {/* Progress xətləri */}
      <div style={{ display: 'flex', gap: 3, padding: '12px 12px 8px', position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10 }}>
        {group.stories.map((_: any, i: number) => (
          <div key={i} style={{ flex: 1, height: 2.5, borderRadius: 99, background: 'rgba(255,255,255,0.35)', overflow: 'hidden' }}>
            <div style={{ height: '100%', borderRadius: 99, background: '#fff',
              width: i < storyIdx ? '100%' : i === storyIdx ? `${progress}%` : '0%',
              transition: i === storyIdx ? 'none' : 'none' }} />
          </div>
        ))}
      </div>

      {/* Header */}
      <div style={{ position: 'absolute', top: 28, left: 0, right: 0, zIndex: 10, padding: '8px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%', overflow: 'hidden', background: grad2(group.user?.username), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, fontWeight: 700, color: '#fff', border: '2px solid #fff' }}>
          {group.user?.avatarUrl ? <img src={group.user.avatarUrl} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : group.user?.username?.[0]?.toUpperCase()}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#fff' }}>{group.user?.displayName || group.user?.username}</div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)' }}>{timeLeft}s</div>
        </div>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#fff', fontSize: 22, cursor: 'pointer', padding: 4 }}>✕</button>
      </div>

      {/* Media */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {story.mediaType === 'video'
          ? <video src={story.mediaUrl} autoPlay loop playsInline style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
          : <img src={story.mediaUrl} style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
        }
        {story.text && (
          <div style={{ position: 'absolute', bottom: '20%', left: '10%', right: '10%', textAlign: 'center', fontSize: 22, fontWeight: 800, color: story.textColor || '#fff', textShadow: '0 2px 8px rgba(0,0,0,0.8)', lineHeight: 1.3 }}>
            {story.text}
          </div>
        )}
      </div>

      {/* Sol/Sağ tap zonaları */}
      <div style={{ position: 'absolute', inset: 0, display: 'flex' }}>
        <div style={{ flex: 1 }} onClick={prevStory2} />
        <div style={{ flex: 1 }} onClick={nextStory} />
      </div>
    </div>
  );
}

// ── Story Dairələri (Feed yuxarısı) ──────────────────
function StoryRow({ me, onAddStory }: { me: any; onAddStory: () => void }) {
  const [groups, setGroups] = useState<any[]>([]);
  const [viewerIdx, setViewerIdx] = useState<number | null>(null);

  useEffect(() => {
        if (!getToken()) return;
    apiFetch(`${API}/stories`)
      .then(r => r.json()).then(d => { if (d.success) setGroups(d.data || []); })
      .catch(() => {});
  }, []);

  const PAL: [string,string][] = [['#6366f1','#a5b4fc'],['#ec4899','#fbcfe8'],['#10b981','#a7f3d0'],['#f59e0b','#fde68a']];
  const grad2 = (n='A') => { const [a,b]=PAL[n.charCodeAt(0)%PAL.length]; return `linear-gradient(135deg,${a},${b})`; };

  return (
    <>
      <div style={{ background: '#fff', borderRadius: 20, marginBottom: 12, padding: '14px 8px', boxShadow: '0 1px 3px rgba(15,23,42,0.04)', border: '1px solid #f1f5f9', overflowX: 'auto', display: 'flex', gap: 12, scrollbarWidth: 'none' as any }}>

        {/* Öz story əlavə et */}
        <div onClick={onAddStory} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, flexShrink: 0, cursor: 'pointer', minWidth: 60 }}>
          <div style={{ width: 58, height: 58, borderRadius: '50%', position: 'relative' }}>
            <div style={{ width: '100%', height: '100%', borderRadius: '50%', overflow: 'hidden', background: me?.avatarUrl ? 'transparent' : grad2(me?.username || 'A'), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, fontWeight: 700, color: '#fff', border: '2px solid #e2e8f0' }}>
              {me?.avatarUrl ? <img src={me.avatarUrl} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : me?.username?.[0]?.toUpperCase()}
            </div>
            <div style={{ position: 'absolute', bottom: 0, right: 0, width: 20, height: 20, borderRadius: '50%', background: 'linear-gradient(135deg,#6366f1,#818cf8)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px solid #fff' }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </div>
          </div>
          <span style={{ fontSize: 10, color: '#64748b', fontWeight: 500, textAlign: 'center' }}>Storyn</span>
        </div>

        {/* Digər story-lər */}
        {groups.map((group, i) => (
          <div key={group.user?.id} onClick={() => setViewerIdx(i)}
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, flexShrink: 0, cursor: 'pointer', minWidth: 60 }}>
            <div style={{ width: 58, height: 58, borderRadius: '50%', padding: 2, background: 'linear-gradient(135deg,#f43f5e,#f59e0b,#6366f1)', position: 'relative' }}>
              <div style={{ width: '100%', height: '100%', borderRadius: '50%', overflow: 'hidden', background: grad2(group.user?.username), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, fontWeight: 700, color: '#fff', border: '2.5px solid #fff' }}>
                {group.user?.avatarUrl ? <img src={group.user.avatarUrl} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : group.user?.username?.[0]?.toUpperCase()}
              </div>
              {/* Story sayı */}
              {group.stories.length > 1 && (
                <div style={{ position: 'absolute', top: 0, right: 0, width: 18, height: 18, borderRadius: '50%', background: '#6366f1', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 800, color: '#fff', border: '2px solid #fff' }}>
                  {group.stories.length}
                </div>
              )}
            </div>
            <span style={{ fontSize: 10, color: '#64748b', fontWeight: 500, textAlign: 'center', maxWidth: 58, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {group.user?.username}
            </span>
          </div>
        ))}
      </div>

      {/* Story viewer */}
      {viewerIdx !== null && (
        <StoryViewer groups={groups} startIdx={viewerIdx} onClose={() => setViewerIdx(null)} me={me} />
      )}
    </>
  );
}

// ── Story əlavə et modal ──────────────────────────────
function AddStoryModal({ user, onClose, onAdded }: { user: any; onClose: () => void; onAdded: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [commentPost, setCommentPost] = useState<any>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
      document.body.classList.remove('comment-open');
      const fab = document.getElementById('feed-fab');
      if (fab) (fab as HTMLElement).style.display = '';
    };
  }, []);

  async function pickFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const isVid = f.type.startsWith('video/');
    setMediaType(isVid ? 'video' : 'image');
    if (!isVid) {
      const c = await compressImage(f);
      setFile(c);
      setPreview(URL.createObjectURL(c));
    } else {
      setFile(f);
      setPreview(URL.createObjectURL(f));
    }
    e.target.value = '';
  }

  async function submit() {
    if (!file) return;
    setLoading(true);
        const fd = new FormData();
    fd.append('file', file);
    const r = await apiFetch(`${API}/storage/upload`, { method: 'POST', body: fd });
    const t = await r.text();
    let d: any = {};
    try { d = JSON.parse(t); } catch {}
    const url = d?.data?.data?.url || d?.data?.url || d?.url || null;
    if (url) {
      await apiFetch(`${API}/stories`, { method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ mediaUrl: url, mediaType, text }),
      });
      onAdded();
    }
    setLoading(false);
    onClose();
  }

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 300, background: '#000', display: 'flex', flexDirection: 'column', fontFamily: "-apple-system,'Segoe UI',system-ui,sans-serif" }}>
      {/* Header */}
      <div style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#fff', fontSize: 22, cursor: 'pointer' }}>✕</button>
        <span style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>Story əlavə et</span>
        <button onClick={submit} disabled={!file || loading}
          style={{ background: file ? '#6366f1' : 'rgba(255,255,255,0.2)', border: 'none', borderRadius: 99, padding: '8px 18px', fontSize: 13, fontWeight: 700, color: '#fff', cursor: file ? 'pointer' : 'default', fontFamily: 'inherit' }}>
          {loading ? '...' : 'Paylaş'}
        </button>
      </div>

      {/* Preview */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
        {!file ? (
          <div onClick={() => fileRef.current?.click()}
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, cursor: 'pointer' }}>
            <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
            </div>
            <span style={{ color: '#fff', fontSize: 16, fontWeight: 600 }}>Şəkil və ya video seç</span>
            <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: 13 }}>24 saat sonra silinir</span>
          </div>
        ) : (
          <>
            {mediaType === 'video'
              ? <video src={preview} autoPlay loop playsInline style={{ maxWidth: '100%', maxHeight: '70vh', objectFit: 'contain' }} />
              : <img src={preview} style={{ maxWidth: '100%', maxHeight: '70vh', objectFit: 'contain' }} />
            }
            {/* Mətn əlavə et */}
            {text && (
              <div style={{ position: 'absolute', bottom: '15%', left: '10%', right: '10%', textAlign: 'center', fontSize: 22, fontWeight: 800, color: '#fff', textShadow: '0 2px 8px rgba(0,0,0,0.8)' }}>
                {text}
              </div>
            )}
          </>
        )}
      </div>

      {/* Alt bar */}
      {file && (
        <div style={{ padding: '12px 20px 32px', flexShrink: 0 }}>
          <input value={text} onChange={e => setText(e.target.value)}
            placeholder="Mətn əlavə et..."
            style={{ width: '100%', background: 'rgba(255,255,255,0.15)', border: 'none', borderRadius: 12, padding: '12px 16px', fontSize: 15, color: '#fff', fontFamily: 'inherit', outline: 'none' }}
          />
        </div>
      )}

      <input ref={fileRef} type="file" accept="image/*,video/*" onChange={pickFile} style={{ display: 'none' }} />
    </div>
  );
}

// ── Skeleton Loading ─────────────────────────────────
function SkeletonCard() {
  return (
    <article style={{ background: '#fff', borderRadius: 20, marginBottom: 12, border: '1px solid #f1f5f9', overflow: 'hidden' }}>
      <style>{`
        @keyframes shimmer {
          0% { background-position: -400px 0; }
          100% { background-position: 400px 0; }
        }
        .sk { background: linear-gradient(90deg, #f1f5f9 25%, #e2e8f0 50%, #f1f5f9 75%); background-size: 400px 100%; animation: shimmer 1.4s infinite; border-radius: 8px; }
      `}</style>

      {/* Header */}
      <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div className="sk" style={{ width: 42, height: 42, borderRadius: '50%', flexShrink: 0 }} />
        <div style={{ flex: 1 }}>
          <div className="sk" style={{ height: 13, width: '40%', marginBottom: 6 }} />
          <div className="sk" style={{ height: 11, width: '25%' }} />
        </div>
      </div>

      {/* Şəkil */}
      <div className="sk" style={{ width: '100%', height: 280, borderRadius: 0 }} />

      {/* Mətn */}
      <div style={{ padding: '12px 16px' }}>
        <div className="sk" style={{ height: 13, width: '90%', marginBottom: 8 }} />
        <div className="sk" style={{ height: 13, width: '70%' }} />
      </div>

      {/* Aksiyalar */}
      <div style={{ padding: '8px 16px 14px', display: 'flex', gap: 20 }}>
        {[60, 50, 50].map((w, i) => (
          <div key={i} className="sk" style={{ height: 13, width: w }} />
        ))}
      </div>
    </article>
  );
}

// ── Delete Comment Button ───────────────────────────────
function DeleteCommentBtn({ comment: c, replies, me, postOwner, onDeleted }: {
  comment: any; replies: any[]; me: any; postOwner: boolean;
  onDeleted: (ids: string[], isTop: boolean) => void;
}) {
  const isTopLevel = !c.content?.startsWith('@');
  const idx = replies.indexOf(c);
  const childReplies = isTopLevel
    ? replies.slice(idx + 1).filter((x: any) => x.content?.startsWith('@'))
    : [];

  async function doDelete() {
        const toDelete = [c.id, ...childReplies.map((x: any) => x.id)];
    const results = await Promise.all(toDelete.map((id: string) =>
      apiFetch(`${API}/posts/${id}`, { method: 'DELETE' })
        .then(r => ({ id, ok: r.ok, status: r.status }))
    ));
    const deleted = results.filter(r => r.ok).map(r => r.id);
    if (deleted.length > 0) {
      onDeleted(deleted, isTopLevel);
    }
  }

  return (
    <button onClick={doDelete}
      style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ef4444', padding: 0, fontFamily: 'inherit', fontSize: 12, marginLeft: 'auto' }}>
      Sil
    </button>
  );
}

// ── Comment Panel ──────────────────────────────────────
function CommentPanel({ post, me, onClose, onUpdate }: { post: any; me: any; onClose: () => void; onUpdate: (id: string, update: any) => void }) {
  const [replies, setReplies] = useState<any[]>([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [replyTo, setReplyTo] = useState<string|null>(null);
  const [expandedReplies, setExpandedReplies] = useState<Set<string>>(new Set());
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const PAL: [string,string][] = [['#6366f1','#a5b4fc'],['#ec4899','#fbcfe8'],['#10b981','#a7f3d0'],['#f59e0b','#fde68a']];
  const grad = (n='A') => { const [a,b]=PAL[n.charCodeAt(0)%PAL.length]; return `linear-gradient(135deg,${a},${b})`; };

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    // Navbar və FAB-ı gizlət
    document.body.classList.add('comment-open');
    const fab = document.getElementById('feed-fab');
    if (fab) (fab as HTMLElement).style.display = 'none';
    fetch(`${API}/posts/${post.id}/replies`)
      .then(r => r.json())
      .then(d => {
        if (d.success) {
          const list = d.data?.replies || [];
          const total = d.data?.total ?? list.length;
          setReplies(list);
          setLocalCount(total);
          onUpdate(post.id, { replyCount: total });
        }
      })
      .finally(() => setFetching(false));
    setTimeout(() => inputRef.current?.focus(), 400);
    return () => {
      document.body.style.overflow = '';
      document.body.classList.remove('comment-open');
      const fab = document.getElementById('feed-fab');
      if (fab) (fab as HTMLElement).style.display = '';
    };
  }, []);

  function timeAgo(iso: string) {
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 60) return `${~~s}s`;
    if (s < 3600) return `${~~(s/60)}dəq`;
    if (s < 86400) return `${~~(s/3600)}saat`;
    return new Date(iso).toLocaleDateString('az-AZ', { day: 'numeric', month: 'short' });
  }

  async function send() {
    const trimmed = text.trim();
    if (!trimmed || loading) return;
    setLoading(true);
        if (!getToken()) { alert('Sessiya bitib. Yenidən daxil olun.'); setLoading(false); return; }
    const finalText = replyTo ? `@${replyTo} ${trimmed}` : trimmed;
    try {
      const res = await apiFetch(`${API}/posts`, { method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ content: finalText, parentId: post.id }),
      });
      const data = await res.json();
      if (data.success) {
        const newReply = { ...data.data, user: me, content: finalText, createdAt: new Date().toISOString() };
        setReplies(prev => [...prev, newReply]);
        setLocalCount(prev => prev + 1);
        onUpdate(post.id, { replyCount: (post.replyCount || 0) + 1 });
        setText('');
        setReplyTo(null);
      } else if (data.statusCode === 401) {
        window.location.href = '/';
      } else {
        alert('Xəta: ' + (data.message || 'Naməlum'));
      }
    } catch(e) {
      alert('Şəbəkə xətası');
    }
    setLoading(false);
  }

  const [localCount, setLocalCount] = useState(post.replyCount || 0);

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 400, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.45)' }} />

      <div style={{ position: 'relative', background: '#fff', borderRadius: '16px 16px 0 0', height: '75vh', display: 'flex', flexDirection: 'column', animation: 'slideUp 0.28s cubic-bezier(.4,0,.2,1)' }}>
        <style>{`
  @keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
  body.comment-open nav { display: none !important; }
`}</style>

        {/* Handle */}
        <div style={{ paddingTop: 10, paddingBottom: 4, flexShrink: 0, display: 'flex', justifyContent: 'center' }}>
          <div style={{ width: 40, height: 4, borderRadius: 99, background: '#e2e8f0' }} />
        </div>

        {/* Header — şərh sayı ortada */}
        <div style={{ padding: '6px 20px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0, borderBottom: '1px solid #f1f5f9' }}>
          <div style={{ width: 32 }} />
          <span style={{ fontSize: 15, fontWeight: 800, color: '#0f172a' }}>{localCount} şərh</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', display: 'flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32, borderRadius: '50%', background: '#f1f5f9' as any }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>

        {/* Şərhlər */}
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {fetching ? (
            <div style={{ padding: '30px 0', textAlign: 'center', color: '#94a3b8', fontSize: 14 }}>Yüklənir...</div>
          ) : replies.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '50px 20px', color: '#94a3b8' }}>
              <div style={{ fontSize: 40, marginBottom: 10 }}>💬</div>
              <div style={{ fontSize: 15, fontWeight: 600, color: '#475569' }}>İlk şərhi sən yaz!</div>
            </div>
          ) : (() => {
            // id-yə görə düzgün qruplaşdırma
            const topLevel = replies.filter(r => !r.content?.startsWith('@'));
            const subReplies = replies.filter(r => r.content?.startsWith('@'));

            // Hər top-level şərhin cavablarını tap — sıra ilə, id-yə görə
            const getChildReplies = (parentId: string, parentIdx: number) => {
              // Yalnız bu şərhdən SONRA gələn @ cavabları
              const afterIdx = replies.findIndex(r => r.id === parentId);
              const after = replies.slice(afterIdx + 1);
              const children: any[] = [];
              for (const r of after) {
                if (!r.content?.startsWith('@')) break; // başqa top-level gəldisə dur
                children.push(r);
              }
              return children;
            };

            return topLevel.map((r, i) => {
              const children = getChildReplies(r.id, i);
              const isExpanded = expandedReplies.has(r.id);
              const mention = (rep: any) => rep.content?.startsWith('@') ? rep.content.split(' ')[0].slice(1) : '';
              const body = (rep: any) => rep.content?.startsWith('@') ? rep.content.slice(rep.content.indexOf(' ')+1) : rep.content;

              const CommentRow = ({ c, nested }: { c: any; nested?: boolean }) => (
                <div style={{ padding: nested ? '10px 16px 10px 66px' : '12px 16px', display: 'flex', gap: 10, borderBottom: nested ? 'none' : '1px solid #f8fafc' }}>
                  <div onClick={() => { onClose(); setTimeout(() => window.location.href=`/profile/${c.user?.username}`,100); }}
                    style={{ width: nested?30:38, height: nested?30:38, borderRadius:'50%', overflow:'hidden', background: grad(c.user?.username||'A'), display:'flex', alignItems:'center', justifyContent:'center', fontSize: nested?12:15, fontWeight:700, color:'#fff', flexShrink:0, cursor:'pointer' }}>
                    {c.user?.avatarUrl ? <img src={c.user.avatarUrl} style={{ width:'100%', height:'100%', objectFit:'cover' }} /> : c.user?.username?.[0]?.toUpperCase()}
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ marginBottom:3 }}>
                      <span onClick={() => { onClose(); setTimeout(() => window.location.href=`/profile/${c.user?.username}`,100); }}
                        style={{ fontWeight:700, fontSize: nested?12:13, color:'#0f172a', marginRight:6, cursor:'pointer' }}>{c.user?.username||'?'}</span>
                      <span style={{ fontSize: nested?11:12, color:'#94a3b8' }}>{timeAgo(c.createdAt)}</span>
                    </div>
                    <div style={{ fontSize: nested?13:14, color:'#0f172a', lineHeight:1.55 }}>
                      {nested && <span onClick={() => { onClose(); setTimeout(() => window.location.href=`/profile/${mention(c)}`,100); }} style={{ color:'#6366f1', fontWeight:600, marginRight:4, cursor:'pointer' }}>@{mention(c)}</span>}
                      {body(c)}
                    </div>
                    <div style={{ display:'flex', gap:14, marginTop:5, alignItems:'center' }}>
                      <button onClick={async () => {
                                                const res = await apiFetch(`${API}/posts/${c.id}/like`, { method:'POST' });
                        const data = await res.json();
                        if (data.success) setReplies(prev => prev.map(x => x.id===c.id ? { ...x, likeCount: data.data.liked?(x.likeCount||0)+1:Math.max(0,(x.likeCount||1)-1), isLiked:data.data.liked } : x));
                      }}
                        style={{ background:'none', border:'none', cursor:'pointer', fontSize:12, color: c.isLiked?'#f43f5e':'#94a3b8', display:'flex', alignItems:'center', gap:4, padding:0, fontFamily:'inherit' }}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill={c.isLiked?'#f43f5e':'none'} stroke={c.isLiked?'#f43f5e':'currentColor'} strokeWidth="2" strokeLinecap="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                        {c.likeCount||''}
                      </button>
                      <button onClick={() => { setReplyTo(c.user?.username||null); setText(''); setTimeout(()=>inputRef.current?.focus(),100); }}
                        style={{ background:'none', border:'none', cursor:'pointer', fontSize:12, color:'#94a3b8', padding:0, fontFamily:'inherit' }}>Cavabla</button>
                      {(c.user?.id === me?.id || post.user?.id === me?.id) && (
                        <DeleteCommentBtn
                          comment={c}
                          replies={replies}
                          me={me}
                          postOwner={post.user?.id === me?.id}
                          onDeleted={(ids, isTop) => {
                            setReplies(prev => prev.filter((x:any) => !ids.includes(x.id)));
                            if (isTop) {
                              setLocalCount(prev => Math.max(0, prev - 1));
                              onUpdate(post.id, { replyCount: Math.max(0, (post.replyCount||0) - 1) });
                            }
                          }}
                        />
                      )}
                    </div>
                  </div>
                </div>
              );

              return (
                <div key={r.id}>
                  <CommentRow c={r} />
                  {children.length > 0 && (
                    <button onClick={() => setExpandedReplies(prev => { const n = new Set(prev); isExpanded ? n.delete(r.id) : n.add(r.id); return n; })}
                      style={{ background:'none', border:'none', cursor:'pointer', fontSize:12, color:'#6366f1', fontWeight:700, padding:'4px 16px 8px 66px', display:'flex', alignItems:'center', gap:6, fontFamily:'inherit' }}>
                      <div style={{ width:16, height:1, background:'#cbd5e1' }} />
                      {isExpanded ? 'Yanıtları gizlə' : `${children.length} yanıtı gör`}
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round"><polyline points={isExpanded?'18 15 12 9 6 15':'6 9 12 15 18 9'}/></svg>
                    </button>
                  )}
                  {isExpanded && children.map((rep, ri) => (
                    <CommentRow key={rep.id||`r${ri}`} c={rep} nested />
                  ))}
                </div>
              );
            });
          })()}
        </div>

        {/* Input — sabit aşağıda */}
        <div style={{ borderTop: '1px solid #f1f5f9', flexShrink: 0, background: '#fff' }}>
          {/* ReplyTo banner */}
          {replyTo && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 16px', background: '#f8fafc', borderBottom: '1px solid #f1f5f9' }}>
              <span style={{ fontSize: 12, color: '#64748b' }}>
                <span style={{ fontWeight: 700, color: '#6366f1' }}>@{replyTo}</span> istifadəçiyə cavab verirsən
              </span>
              <button onClick={() => { setReplyTo(null); setText(''); }}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', fontSize: 16, display: 'flex', alignItems: 'center' }}>✕</button>
            </div>
          )}

          <div style={{ padding: '10px 16px', paddingBottom: 'calc(12px + env(safe-area-inset-bottom))', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', overflow: 'hidden', background: grad(me?.username || 'A'), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
              {me?.avatarUrl ? <img src={me.avatarUrl} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : me?.username?.[0]?.toUpperCase()}
            </div>
            <div style={{ flex: 1, background: '#f1f5f9', borderRadius: 24, padding: '9px 16px', display: 'flex', alignItems: 'center', gap: 8 }}>
              <textarea ref={inputRef} value={text} onChange={e => setText(e.target.value)}
                placeholder={replyTo ? `@${replyTo} cavabla...` : 'Şərh əlavə edin...'}
                maxLength={500} rows={1}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
                onInput={e => { const t = e.target as HTMLTextAreaElement; t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 80) + 'px'; }}
                style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 14, color: '#0f172a', fontFamily: 'inherit', resize: 'none', lineHeight: 1.4, maxHeight: 80 }}
              />
            </div>
            <button onClick={send} disabled={!text.trim() || loading}
              style={{ background: text.trim() ? '#6366f1' : '#e2e8f0', border: 'none', borderRadius: '50%', width: 36, height: 36, cursor: text.trim() ? 'pointer' : 'default', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'background 0.2s' }}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={text.trim() ? '#fff' : '#94a3b8'} strokeWidth="2.5" strokeLinecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Music Player ─────────────────────────────────────
const activeAudios: HTMLAudioElement[] = [];

function MusicPlayer({ url, name }: { url: string; name?: string }) {
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const audio = new Audio(url);
    audio.loop = true;
    audio.volume = 0.7;
    audioRef.current = audio;

    // IntersectionObserver — görünəndə avtomatik çal
    const el = document.getElementById(`music-${url.slice(-20)}`);
    if (!el) return;
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        // Digər musiqiləri durdur
        activeAudios.forEach(a => { if (a !== audio) { a.pause(); a.currentTime = 0; } });
        activeAudios.length = 0;
        activeAudios.push(audio);
        audio.play().then(() => setPlaying(true)).catch(() => {});
      } else {
        audio.pause();
        setPlaying(false);
      }
    }, { threshold: 0.5 });
    obs.observe(el);

    return () => {
      obs.disconnect();
      audio.pause();
      audio.src = '';
    };
  }, [url]);

  function toggle() {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) { audio.pause(); setPlaying(false); }
    else {
      activeAudios.forEach(a => { if (a !== audio) { a.pause(); a.currentTime = 0; } });
      audio.play().then(() => setPlaying(true)).catch(() => {});
    }
  }

  return (
    <div id={`music-${url.slice(-20)}`}
      style={{ margin: '6px 12px', background: 'linear-gradient(135deg, #1e1b4b, #312e81)', borderRadius: 12, padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
      <button onClick={toggle}
        style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(255,255,255,0.2)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        {playing
          ? <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
          : <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        }
      </button>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: '#fff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          🎵 {name || 'Musiqi'}
        </div>
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.6)' }}>Jamendo · Pulsuz musiqi</div>
      </div>
      {playing && (
        <div style={{ display: 'flex', gap: 2, alignItems: 'flex-end', height: 16 }}>
          {[0,1,2,3].map(i => (
            <div key={i} style={{ width: 3, borderRadius: 2, background: '#a5b4fc', animation: `musicBar${i} 0.8s ${i*0.15}s infinite ease-in-out` }} />
          ))}
        </div>
      )}
      <style>{`
        @keyframes musicBar0{0%,100%{height:4px}50%{height:14px}}
        @keyframes musicBar1{0%,100%{height:8px}50%{height:4px}}
        @keyframes musicBar2{0%,100%{height:12px}50%{height:6px}}
        @keyframes musicBar3{0%,100%{height:5px}50%{height:12px}}
      `}</style>
    </div>
  );
}

// ── Video Player ─────────────────────────────────────
function VideoPlayer({ src }: { src: string }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [muted, setMuted] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const hideTimer = useRef<any>(null);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        v.play().then(() => setPlaying(true)).catch(() => {});
      } else {
        v.pause(); setPlaying(false);
      }
    }, { threshold: 0.6 });
    obs.observe(v);
    return () => obs.disconnect();
  }, []);

  function togglePlay() {
    const v = videoRef.current;
    if (!v) return;
    if (playing) { v.pause(); setPlaying(false); }
    else { v.play().then(() => setPlaying(true)).catch(() => {}); }
    resetHideTimer();
  }

  function resetHideTimer() {
    setShowControls(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setShowControls(false), 2500);
  }

  function onTimeUpdate() {
    const v = videoRef.current;
    if (!v || !v.duration) return;
    setProgress(v.currentTime / v.duration * 100);
  }

  function seek(e: React.MouseEvent<HTMLDivElement>) {
    const v = videoRef.current;
    if (!v) return;
    const rect = e.currentTarget.getBoundingClientRect();
    v.currentTime = ((e.clientX - rect.left) / rect.width) * v.duration;
    e.stopPropagation();
  }

  function fmtTime(s: number) {
    const m = ~~(s / 60);
    return `${m}:${String(~~(s % 60)).padStart(2, '0')}`;
  }

  return (
    <div style={{ position: 'relative', width: '100%', overflow: 'hidden', cursor: 'pointer', background: '#000' }}
      onClick={togglePlay}>
      {/* Video — cover ilə tam doldurur, qara kənar yox */}
      <video ref={videoRef} src={src} muted={muted} loop playsInline
        onTimeUpdate={onTimeUpdate}
        onLoadedMetadata={e => setDuration((e.target as HTMLVideoElement).duration)}
        style={{ width: '100%', display: 'block', objectFit: 'cover', maxHeight: 500 }}
      />

      {/* Oynat/Durdur — tap edəndə görünür */}
      {(!playing || showControls) && (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: playing ? 'rgba(0,0,0,0.05)' : 'rgba(0,0,0,0.25)' }}>
          <div style={{ width: 60, height: 60, borderRadius: '50%', background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1.5px solid rgba(255,255,255,0.4)' }}>
            {playing
              ? <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
              : <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff" style={{ marginLeft: 3 }}><polygon points="5 3 19 12 5 21 5 3"/></svg>
            }
          </div>
        </div>
      )}

      {/* Alt panel — TikTok kimi: gradient + ince xətt + vaxt + səs */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        background: 'linear-gradient(to top, rgba(0,0,0,0.65) 0%, transparent 100%)',
        padding: '30px 12px 10px',
        opacity: showControls || !playing ? 1 : 0,
        transition: 'opacity 0.25s',
        pointerEvents: showControls ? 'auto' : 'none',
      }}>
        {/* İncə progress xətti — TikTok kimi */}
        <div onClick={seek} style={{ height: 2, background: 'rgba(255,255,255,0.3)', borderRadius: 99, marginBottom: 8, cursor: 'pointer', position: 'relative' }}>
          <div style={{ height: '100%', width: `${progress}%`, background: '#fff', borderRadius: 99, transition: 'width 0.1s linear' }} />
          {/* Kiçik dairə — sürükləmə nöqtəsi */}
          <div style={{ position: 'absolute', top: '50%', left: `${progress}%`, transform: 'translate(-50%, -50%)', width: 10, height: 10, borderRadius: '50%', background: '#fff', boxShadow: '0 0 4px rgba(0,0,0,0.5)' }} />
        </div>

        <div style={{ display: 'flex', alignItems: 'center' }}>
          <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.85)', fontWeight: 600, letterSpacing: '0.3px' }}>
            {fmtTime(videoRef.current?.currentTime || 0)} / {fmtTime(duration)}
          </span>
          <div style={{ flex: 1 }} />
          <button onClick={e => { e.stopPropagation(); setMuted(m => !m); }}
            style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', padding: 6, borderRadius: '50%', background: 'rgba(0,0,0,0.3)' } as any}>
            {muted
              ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>
              : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
            }
          </button>
        </div>
      </div>

      {/* Səssiz badge — sağ üstdə kiçik */}
      {muted && playing && !showControls && (
        <div style={{ position: 'absolute', top: 10, right: 10, background: 'rgba(0,0,0,0.5)', borderRadius: 99, padding: '3px 9px', display: 'flex', alignItems: 'center', gap: 4 }}>
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>
          <span style={{ fontSize: 9, color: '#fff', fontWeight: 700 }}>SƏSSİZ</span>
        </div>
      )}
    </div>
  );
}

// ── Media Carousel ──────────────────────────────────
function MediaCarousel({ urls, onZoom }: { urls: string[]; onZoom: (url: string) => void }) {
  const [idx, setIdx] = useState(0);
  const touchStartX = useRef(0);

  function onTouchStart(e: React.TouchEvent) { touchStartX.current = e.touches[0].clientX; }
  function onTouchEnd(e: React.TouchEvent) {
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (dx < -40 && idx < urls.length - 1) setIdx(i => i + 1);
    if (dx > 40  && idx > 0)               setIdx(i => i - 1);
  }

  const isVideo = (url: string) =>
    /\.(mp4|mov|webm|ogg|avi|mkv)$/i.test(url.split('?')[0]) ||
    url.includes('video') || url.includes('.mov');

  return (
    <div style={{ position: 'relative', marginTop: 8, overflow: 'hidden', userSelect: 'none' as any }}
      onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
      {isVideo(urls[idx])
        ? <VideoPlayer src={urls[idx]} />
        : <img src={urls[idx]} alt=""
            onClick={e => { e.stopPropagation(); onZoom(urls[idx]); }}
            style={{ width: '100%', maxHeight: 480, objectFit: 'cover', display: 'block', cursor: 'zoom-in' }}
            loading="lazy"
          />
      }
      {urls.length > 1 && (
        <div style={{ position: 'absolute', bottom: 10, left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: 5, zIndex: 2 }}>
          {urls.map((_, i) => (
            <div key={i} onClick={() => setIdx(i)}
              style={{ width: i === idx ? 16 : 6, height: 6, borderRadius: 99, background: i === idx ? '#fff' : 'rgba(255,255,255,0.55)', cursor: 'pointer', transition: 'all 0.2s' }} />
          ))}
        </div>
      )}
      {urls.length > 1 && (
        <div style={{ position: 'absolute', top: 10, right: 10, background: 'rgba(0,0,0,0.55)', color: '#fff', fontSize: 11, fontWeight: 700, padding: '3px 8px', borderRadius: 99, zIndex: 2 }}>
          {idx + 1}/{urls.length}
        </div>
      )}
    </div>
  );
}

// ── Post kartı ──────────────────────────────────────
function PostCard({ post, me, onUpdate, onNavigate, onComment }: { post: any; me: any; onUpdate: (id: string, update: any) => void; onNavigate: (p: string) => void; onComment: (id: string) => void }) {
  const [likeAnim, setLikeAnim] = useState(false);
  const [imgModal, setImgModal] = useState('');
  const [copied, setCopied] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editContent, setEditContent] = useState(post.content || '');
  const [editLoading, setEditLoading] = useState(false);
  const name = post.user?.username || '?';
  const isMyPost = me?.id === post.user?.id;

  async function doLike(e: React.MouseEvent) {
    e.stopPropagation();
    setLikeAnim(true);
    setTimeout(() => setLikeAnim(false), 350);
        const res = await apiFetch(`${API}/posts/${post.id}/like`, { method: 'POST' });
    const data = await res.json();
    if (data.success) onUpdate(post.id, { isLiked: data.data.liked, likeCount: data.data.liked ? post.likeCount + 1 : post.likeCount - 1 });
  }

  async function doRepost(e: React.MouseEvent) {
    e.stopPropagation();
        const res = await apiFetch(`${API}/posts/${post.id}/repost`, { method: 'POST' });
    const data = await res.json();
    if (data.success) onUpdate(post.id, { isReposted: data.data.reposted, repostCount: data.data.reposted ? post.repostCount + 1 : post.repostCount - 1 });
  }

  async function doBookmark(e: React.MouseEvent) {
    e.stopPropagation();
        const res = await apiFetch(`${API}/posts/${post.id}/bookmark`, { method: 'POST' });
    const data = await res.json();
    if (data.success) onUpdate(post.id, { isBookmarked: data.data.bookmarked });
  }

  async function doDelete() {
    if (!confirm('Postu silmək istəyirsən?')) return;
    setMenuOpen(false);
        try {
      const res = await apiFetch(`${API}/posts/${post.id}`, { method: 'DELETE' });
      if (res.ok) {
        onUpdate(post.id, { _deleted: true });
        return;
      }
      const text = await res.text();
      alert('Silinmədi: ' + res.status);
    } catch(e) {
      alert('Xəta baş verdi');
    }
  }

  async function doEdit() {
    setEditLoading(true);
        const res = await apiFetch(`${API}/posts/${post.id}`, { method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` },
      body: JSON.stringify({ content: editContent }),
    });
    const data = await res.json();
    if (data.success) onUpdate(post.id, { content: editContent });
    setEditMode(false);
    setEditLoading(false);
  }

  function doShare(e: React.MouseEvent) {
    e.stopPropagation();
    const url = `${window.location.origin}/post/${post.id}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  function timeAgo(iso: string) {
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 60) return `${~~s}s`;
    if (s < 3600) return `${~~(s/60)}dəq`;
    if (s < 86400) return `${~~(s/3600)}saat`;
    return new Date(iso).toLocaleDateString('az-AZ', { day: 'numeric', month: 'short' });
  }

  return (
    <>
      {imgModal && <ImageModal src={imgModal} onClose={() => setImgModal('')} />}
      <article style={{ background: '#fff', borderRadius: 20, marginBottom: 12, boxShadow: '0 1px 3px rgba(15,23,42,0.04)', border: '1px solid #f1f5f9', overflow: 'hidden' }}>

        {/* Başlıq */}
        <div style={{ padding: '14px 16px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div onClick={() => onNavigate(`/profile/${name}`)} style={{ cursor: 'pointer' }}>
            <Avatar name={name} url={post.user?.avatarUrl} size={42} />
          </div>
          <div style={{ flex: 1 }} onClick={() => onNavigate(`/profile/${name}`)} style={{ cursor: 'pointer', flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 14, color: '#0f172a' }}>{post.user?.displayName || name}</div>
            <div style={{ fontSize: 12, color: '#94a3b8' }}>@{name} · {timeAgo(post.createdAt)}</div>
          </div>
          <div style={{ position: 'relative' }}>
            <button onClick={e => { e.stopPropagation(); setMenuOpen(v => !v); }}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', padding: 4, borderRadius: 8 }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></svg>
            </button>
            {menuOpen && (
              <>
                <div onClick={() => setMenuOpen(false)} style={{ position: 'fixed', inset: 0, zIndex: 99 }} />
                <div style={{ position: 'absolute', right: 0, top: 28, background: '#fff', borderRadius: 14, boxShadow: '0 8px 30px rgba(15,23,42,0.15)', border: '1px solid #f1f5f9', zIndex: 100, minWidth: 180, overflow: 'hidden' }}>
                  {isMyPost ? (<>
                    <div onClick={() => { setEditMode(true); setMenuOpen(false); }}
                      style={{ padding: '13px 16px', cursor: 'pointer', fontSize: 14, fontWeight: 600, color: '#0f172a', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid #f8fafc' }}
                      onTouchStart={e => (e.currentTarget.style.background='#f8fafc')}
                      onTouchEnd={e => (e.currentTarget.style.background='transparent')}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6366f1" strokeWidth="2" strokeLinecap="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                      Redaktə et
                    </div>
                    <div onClick={doDelete}
                      style={{ padding: '13px 16px', cursor: 'pointer', fontSize: 14, fontWeight: 600, color: '#ef4444', display: 'flex', alignItems: 'center', gap: 10 }}
                      onTouchStart={e => (e.currentTarget.style.background='#fef2f2')}
                      onTouchEnd={e => (e.currentTarget.style.background='transparent')}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                      Sil
                    </div>
                  </>) : (<>
                    <div onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/post/${post.id}`); setMenuOpen(false); }}
                      style={{ padding: '13px 16px', cursor: 'pointer', fontSize: 14, fontWeight: 600, color: '#0f172a', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid #f8fafc' }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6366f1" strokeWidth="2" strokeLinecap="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                      Linki kopyala
                    </div>
                    <div onClick={() => { alert('Şikayət göndərildi'); setMenuOpen(false); }}
                      style={{ padding: '13px 16px', cursor: 'pointer', fontSize: 14, fontWeight: 600, color: '#f59e0b', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid #f8fafc' }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                      Şikayət et
                    </div>
                    <div onClick={() => { alert('İstifadəçi bloklandı'); setMenuOpen(false); }}
                      style={{ padding: '13px 16px', cursor: 'pointer', fontSize: 14, fontWeight: 600, color: '#ef4444', display: 'flex', alignItems: 'center', gap: 10 }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                      Blokla
                    </div>
                  </>)}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Media carousel — yuxarıda */}
        {post.mediaUrls?.length > 0 && (
          <MediaCarousel urls={post.mediaUrls} onZoom={url => setImgModal(url)} />
        )}

        {/* Məzmun + yer + hashtaglər */}
        <div onClick={() => onNavigate(`/post/${post.id}`)} style={{ padding: '10px 16px 6px', cursor: 'pointer' }}>
          {post.content && (() => {
            // Mətni hashtaglər ilə rəngləndiririk
            const parts = post.content.split(/(#\w+|@\w+)/g);
            return (
              <div style={{ fontSize: 15, lineHeight: 1.6, color: '#1e293b', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                {parts.map((part: string, i: number) => {
                  if (part.startsWith('#')) return <span key={i} style={{ color: '#6366f1', fontWeight: 600 }}>{part}</span>;
                  if (part.startsWith('@')) return <span key={i} style={{ color: '#3b82f6', fontWeight: 600 }}>{part}</span>;
                  return part;
                })}
              </div>
            );
          })()}

          {/* Yer */}
          {post.location && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 6, color: '#10b981', fontSize: 12, fontWeight: 600 }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              {post.location}
            </div>
          )}
        </div>

        {/* Redaktə modu */}
        {editMode && (
          <div style={{ padding: '0 16px 12px' }}>
            <textarea value={editContent} onChange={e => setEditContent(e.target.value)}
              rows={3} maxLength={500}
              style={{ width: '100%', background: '#f8fafc', border: '1.5px solid #e2e8f0', borderRadius: 12, padding: '10px 14px', fontSize: 15, color: '#0f172a', fontFamily: 'inherit', outline: 'none', resize: 'none' }}
            />
            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              <button onClick={() => setEditMode(false)}
                style={{ flex: 1, background: '#f1f5f9', border: 'none', borderRadius: 10, padding: '9px', fontSize: 13, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit', color: '#64748b' }}>
                Ləğv et
              </button>
              <button onClick={doEdit} disabled={editLoading}
                style={{ flex: 1, background: 'linear-gradient(135deg,#6366f1,#818cf8)', border: 'none', borderRadius: 10, padding: '9px', fontSize: 13, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit', color: '#fff' }}>
                {editLoading ? '...' : 'Saxla'}
              </button>
            </div>
          </div>
        )}

        {/* Musiqi player */}
        {post.musicUrl && (
          <MusicPlayer url={post.musicUrl} name={post.musicName} />
        )}

        {/* Aksiyalar */}
        <div style={{ padding: '8px 12px 10px', display: 'flex', alignItems: 'center', gap: 0, borderTop: '1px solid #f8fafc', marginTop: 8 }}>

          {/* Bəyən */}
          <button onClick={doLike}
            style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: post.isLiked ? '#f43f5e' : '#94a3b8', padding: '8px 0', borderRadius: 10, transition: 'all 0.15s', transform: likeAnim ? 'scale(1.25)' : 'scale(1)' }}>
            <IHeart filled={post.isLiked} />
            <span style={{ fontSize: 13, fontWeight: post.isLiked ? 700 : 500 }}>{fmt(post.likeCount)}</span>
          </button>

          {/* Şərh */}
          <button onClick={e => { e.stopPropagation(); onComment(post.id); }}
            style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', padding: '8px 0', borderRadius: 10, transition: 'all 0.15s' }}>
            <IComment />
            <span style={{ fontSize: 13, fontWeight: 500 }}>{fmt(post.replyCount)}</span>
          </button>

          {/* Repost - gizlədildi */}
          <div style={{ flex: 1 }} />

          {/* Bookmark */}
          <button onClick={doBookmark}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'none', border: 'none', cursor: 'pointer', color: post.isBookmarked ? '#6366f1' : '#94a3b8', padding: '8px 12px', borderRadius: 10, transition: 'all 0.15s' }}>
            <IBookmark filled={post.isBookmarked} />
          </button>

          {/* Paylaş / Kopyala */}
          <button onClick={doShare}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'none', border: 'none', cursor: 'pointer', color: copied ? '#10b981' : '#94a3b8', padding: '8px 12px', borderRadius: 10, transition: 'all 0.15s', position: 'relative' }}>
            {copied
              ? <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
              : <IShare />
            }
          </button>
        </div>
      </article>
    </>
  );
}

// ── Şəkil sıxma funksiyası — canvas ilə, xəta halında original ──
async function compressImage(file: File, maxW = 1080, quality = 0.8): Promise<File> {
  return new Promise(resolve => {
    // 2MB-dan kiçikdirsə sıxma
    if (file.size < 2 * 1024 * 1024) { resolve(file); return; }
    try {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        try {
          const scale = Math.min(1, maxW / Math.max(img.width, img.height));
          const w = Math.round(img.width * scale);
          const h = Math.round(img.height * scale);
          const canvas = document.createElement('canvas');
          canvas.width = w; canvas.height = h;
          const ctx = canvas.getContext('2d');
          if (!ctx) { URL.revokeObjectURL(url); resolve(file); return; }
          ctx.drawImage(img, 0, 0, w, h);
          URL.revokeObjectURL(url);
          canvas.toBlob(blob => {
            if (!blob || blob.size === 0) { resolve(file); return; }
            resolve(new File([blob], file.name.replace(/\.[^.]+$/, '.jpg'), { type: 'image/jpeg' }));
          }, 'image/jpeg', quality);
        } catch { URL.revokeObjectURL(url); resolve(file); }
      };
      img.onerror = () => { resolve(file); };
      img.src = url;
    } catch { resolve(file); }
  });
}

// ── Location Picker ──────────────────────────────────
function LocationPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [query, setQuery] = useState(value || '');
  const [results, setResults] = useState<{ name: string; flag: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [commentPost, setCommentPost] = useState<any>(null);
  const searchTimer = useRef<any>(null);

  // İlk açılışda populyar Azərbaycan şəhərləri
  const defaults = [
    { name: 'Bakı, Azərbaycan', flag: '🇦🇿' },
    { name: 'Gəncə, Azərbaycan', flag: '🇦🇿' },
    { name: 'Sumqayıt, Azərbaycan', flag: '🇦🇿' },
    { name: 'Mingəçevir, Azərbaycan', flag: '🇦🇿' },
    { name: 'Naxçıvan, Azərbaycan', flag: '🇦🇿' },
    { name: 'Lənkəran, Azərbaycan', flag: '🇦🇿' },
    { name: 'Şirvan, Azərbaycan', flag: '🇦🇿' },
    { name: 'Yevlax, Azərbaycan', flag: '🇦🇿' },
    { name: 'Şəki, Azərbaycan', flag: '🇦🇿' },
    { name: 'Quba, Azərbaycan', flag: '🇦🇿' },
    { name: 'İstanbul, Türkiyə', flag: '🇹🇷' },
    { name: 'Ankara, Türkiyə', flag: '🇹🇷' },
    { name: 'Moskva, Rusiya', flag: '🇷🇺' },
    { name: 'Dubai, BAƏ', flag: '🇦🇪' },
    { name: 'London, İngiltərə', flag: '🇬🇧' },
    { name: 'Berlin, Almaniya', flag: '🇩🇪' },
    { name: 'Paris, Fransa', flag: '🇫🇷' },
    { name: 'Nyu-York, ABŞ', flag: '🇺🇸' },
    { name: 'Tbilisi, Gürcüstan', flag: '🇬🇪' },
    { name: 'Kiyev, Ukrayna', flag: '🇺🇦' },
  ];

  useEffect(() => {
    if (!query.trim()) {
      setResults(defaults);
      return;
    }
    clearTimeout(searchTimer.current);
    setLoading(true);
    searchTimer.current = setTimeout(async () => {
      try {
        // OpenStreetMap Nominatim — tamamilə pulsuz, lisenziyasız
        const res = await fetch(
          `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=10&accept-language=az,tr,ru,en&addressdetails=1`,
          { headers: { 'Accept-Language': 'az,tr,ru,en' } }
        );
        const data = await res.json();
        const mapped = data.map((item: any) => {
          const addr = item.address || {};
          const city = addr.city || addr.town || addr.village || addr.county || item.display_name.split(',')[0];
          const country = addr.country || '';
          const countryCode = (addr.country_code || '').toUpperCase();
          // Ölkə bayrağı
          const flag = countryCode.length === 2
            ? String.fromCodePoint(...[...countryCode].map(c => 0x1F1E6 - 65 + c.charCodeAt(0)))
            : '📍';
          return { name: `${city}${country ? ', ' + country : ''}`, flag };
        });
        // Dublikatları sil
        const unique = mapped.filter((v: any, i: number, a: any[]) =>
          a.findIndex((t: any) => t.name === v.name) === i
        );
        setResults(unique);
      } catch {
        setResults([]);
      }
      setLoading(false);
    }, 600);
    return () => clearTimeout(searchTimer.current);
  }, [query]);

  return (
    <div style={{ borderTop: '1px solid #f1f5f9', borderBottom: '1px solid #f1f5f9' }}>
      {/* Axtarış sahəsi */}
      <div style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: 10, background: '#f8fafc', borderBottom: '1px solid #f1f5f9' }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
        <input value={query} onChange={e => setQuery(e.target.value)}
          placeholder="Şəhər, rayon, ölkə axtar..."
          autoFocus
          style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 14, color: '#0f172a', fontFamily: 'inherit' }}
        />
        {loading && <span style={{ fontSize: 12, color: '#6366f1' }}>🔍</span>}
        {query && !loading && (
          <button onClick={() => setQuery('')} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', fontSize: 18, padding: 0 }}>✕</button>
        )}
      </div>

      {/* Nəticələr */}
      <div style={{ maxHeight: 240, overflowY: 'auto' }}>
        {!query && (
          <div style={{ padding: '8px 20px 4px', fontSize: 11, fontWeight: 700, color: '#94a3b8', letterSpacing: '0.5px' }}>
            POPULYAR YERLƏR
          </div>
        )}
        {results.map((loc, i) => (
          <div key={i} onClick={() => onChange(loc.name)}
            style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 20px', cursor: 'pointer', borderBottom: '1px solid #f8fafc' }}
            onTouchStart={e => (e.currentTarget.style.background = '#f5f3ff')}
            onTouchEnd={e => (e.currentTarget.style.background = 'transparent')}>
            <span style={{ fontSize: 20 }}>{loc.flag}</span>
            <span style={{ fontSize: 14, color: '#0f172a' }}>{loc.name}</span>
          </div>
        ))}
        {results.length === 0 && query && !loading && (
          <div style={{ padding: '20px', textAlign: 'center', color: '#94a3b8', fontSize: 13 }}>
            "{query}" tapılmadı
          </div>
        )}
      </div>
    </div>
  );
}

// ── Post Modal — 2 addımlı ───────────────────────────
function PostModal({ user, onClose, onPosted, onUploadStart }: { user: any; onClose: () => void; onPosted: (p: any) => void; onUploadStart: (preview: string, onProgress: (p: number) => void) => void }) {
  const [step, setStep] = useState<1 | 2>(1);
  const [postContent, setPostContent] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0); // 0-100
  const [uploadLabel, setUploadLabel] = useState('');
  const [mediaType, setMediaType] = useState<'none' | 'image' | 'video'>('none');
  const [files, setFiles] = useState<{ file: File; preview: string }[]>([]);
  const [activeIdx, setActiveIdx] = useState(0);
  const [compressing, setCompressing] = useState(false);
  const [location, setLocation] = useState('');
  const [showLocationInput, setShowLocationInput] = useState(false);
  const [audience, setAudience] = useState<'public' | 'followers'>('public');
  const [showAudienceModal, setShowAudienceModal] = useState(false);
  const [mentionResults, setMentionResults] = useState<any[]>([]);
  const [mentionTrigger, setMentionTrigger] = useState<number | null>(null);
  const [showMusicPanel, setShowMusicPanel] = useState(false);
  const [musicQuery, setMusicQuery] = useState('');
  const [musicResults, setMusicResults] = useState<any[]>([]);
  const [musicSearching, setMusicSearching] = useState(false);
  const [selectedMusic, setSelectedMusic] = useState<{name: string; url: string; artist: string} | null>(null);
  const [previewAudio, setPreviewAudio] = useState<HTMLAudioElement | null>(null);
  const musicTimer = useRef<any>(null);
  const textRef = useRef<HTMLTextAreaElement>(null);
  const imgRef = useRef<HTMLInputElement>(null);
  const vidRef = useRef<HTMLInputElement>(null);
  const mentionTimer = useRef<any>(null);

  const MAX = 500;
  const canNext = files.length > 0;
  const canPost = (postContent.trim().length > 0 || files.length > 0) && !uploading;

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
      document.body.classList.remove('comment-open');
      const fab = document.getElementById('feed-fab');
      if (fab) (fab as HTMLElement).style.display = '';
    };
  }, []);

  function handleTextChange(val: string) {
    setPostContent(val);
    const cursor = textRef.current?.selectionStart || val.length;
    const before = val.slice(0, cursor);
    const match = before.match(/@(\w{1,20})$/);
    if (match) {
      setMentionTrigger(cursor - match[0].length);
      clearTimeout(mentionTimer.current);
      mentionTimer.current = setTimeout(async () => {
                const res = await apiFetch(`${API}/users/search?q=${match[1]}`);
        const d = await res.json();
        if (d.success) setMentionResults((d.data || []).slice(0, 5));
      }, 400);
    } else {
      setMentionResults([]);
      setMentionTrigger(null);
    }
  }

  function selectMention(username: string) {
    if (mentionTrigger === null) return;
    const cursor = textRef.current?.selectionStart || postContent.length;
    const newVal = postContent.slice(0, mentionTrigger) + '@' + username + ' ' + postContent.slice(cursor);
    setPostContent(newVal);
    setMentionResults([]);
    setMentionTrigger(null);
    setTimeout(() => textRef.current?.focus(), 30);
  }

  async function pickImages(e: React.ChangeEvent<HTMLInputElement>) {
    const sel = Array.from(e.target.files || []).slice(0, 3 - files.length);
    if (!sel.length) return;
    setCompressing(true);
    setMediaType('image');
    const added = await Promise.all(sel.map(async f => {
      const c = await compressImage(f);
      return { file: c, preview: URL.createObjectURL(c) };
    }));
    setFiles(p => [...p, ...added]);
    setCompressing(false);
    e.target.value = '';
  }

  async function pickVideo(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 50 * 1024 * 1024) { alert('Max 50MB'); return; }
    setMediaType('video');
    setFiles([{ file: f, preview: URL.createObjectURL(f) }]);
    e.target.value = '';
  }

  function removeFile(idx: number) {
    URL.revokeObjectURL(files[idx].preview);
    const next = files.filter((_, i) => i !== idx);
    setFiles(next);
    if (next.length === 0) { setMediaType('none'); setStep(1); }
    setActiveIdx(Math.max(0, idx - 1));
  }

  async function searchMusic(q: string) {
    if (!q.trim()) { setMusicResults([]); return; }
    setMusicSearching(true);
    try {
      // iTunes Search API — pulsuz, lisenziyasız, 30 san preview
      const res = await fetch(
        `https://itunes.apple.com/search?term=${encodeURIComponent(q)}&media=music&entity=song&limit=10&country=az`
      );
      const d = await res.json();
      const tracks = (d.results || []).filter((t: any) => t.previewUrl).map((t: any) => ({
        id: t.trackId,
        name: t.trackName,
        artist_name: t.artistName,
        audio: t.previewUrl, // 30 san preview
        artwork: t.artworkUrl60,
      }));
      setMusicResults(tracks);
    } catch {
      setMusicResults([]);
    }
    setMusicSearching(false);
  }

  function playPreview(url: string) {
    if (previewAudio) { previewAudio.pause(); previewAudio.src = ''; }
    if (url) {
      const a = new Audio(url);
      a.volume = 0.6;
      a.play().catch(() => {});
      setPreviewAudio(a);
    }
  }

  function stopPreview() {
    if (previewAudio) { previewAudio.pause(); previewAudio.src = ''; setPreviewAudio(null); }
  }

  function selectMusic(track: any) {
    setSelectedMusic({ name: track.name, url: track.audio, artist: track.artist_name || '' });
    stopPreview();
    setShowMusicPanel(false);
    setMusicQuery('');
    setMusicResults([]);
  }

  async function submit() {
    if (!canPost) return;
    stopPreview();
    const previewUrl = files[0]?.preview || '';
    let progressCb: (p: number) => void = () => {};
    onUploadStart(previewUrl, (cb) => { progressCb = cb; });
    onClose();

        const mediaUrls: string[] = [];
    const total = files.length;

    for (let i = 0; i < files.length; i++) {
      progressCb(Math.round((i / total) * 80));
      const fd = new FormData();
      fd.append('file', files[i].file);
      try {
        const r = await apiFetch(`${API}/storage/upload`, { method: 'POST', body: fd });
        const t = await r.text();
        let d: any = {};
        try { d = JSON.parse(t); } catch {}
        const url = d?.data?.data?.url || d?.data?.url || d?.url || null;
        if (url) mediaUrls.push(url);
      } catch {}
    }

    const res = await apiFetch(`${API}/posts`, { method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` },
      body: JSON.stringify({ content: postContent, mediaUrls, location, audience, musicUrl: selectedMusic?.url, musicName: selectedMusic ? `${selectedMusic.name} — ${selectedMusic.artist}` : undefined }),
    });
    const data = await res.json();

    await new Promise(r => setTimeout(r, 600));

    progressCb(100);
    if (data.success) {
      files.forEach(f => URL.revokeObjectURL(f.preview));
      onPosted({ ...data.data, user, isLiked: false, isBookmarked: false, isReposted: false });
    }
  }

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 200, background: '#f8fafc', display: 'flex', flexDirection: 'column', fontFamily: "-apple-system,'Segoe UI',system-ui,sans-serif" }}>
      <style>{`@keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}`}</style>

      {/* Header */}
      <div style={{ background: '#fff', borderBottom: '1px solid #f1f5f9', padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <button onClick={step === 1 ? onClose : () => setStep(1)}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b', padding: 4, display: 'flex', alignItems: 'center' }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 15, fontWeight: 800, color: '#0f172a' }}>{step === 1 ? 'Media seç' : 'Yeni post'}</span>
          {/* Addım göstəricisi */}
          <div style={{ display: 'flex', gap: 4 }}>
            {[1, 2].map(s => (
              <div key={s} style={{ width: s === step ? 16 : 6, height: 6, borderRadius: 99, background: s === step ? '#6366f1' : '#e2e8f0', transition: 'all 0.2s' }} />
            ))}
          </div>
        </div>

        {step === 1
          ? <button onClick={() => canNext && setStep(2)} disabled={!canNext}
              style={{ background: 'none', border: 'none', fontSize: 15, fontWeight: 700, color: canNext ? '#6366f1' : '#cbd5e1', cursor: canNext ? 'pointer' : 'default', fontFamily: 'inherit' }}>
              İrəli
            </button>
          : <button onClick={submit} disabled={!canPost}
              style={{ background: 'none', border: 'none', fontSize: 15, fontWeight: 700, color: canPost ? '#6366f1' : '#cbd5e1', cursor: canPost ? 'pointer' : 'default', fontFamily: 'inherit' }}>
              Paylaş
            </button>
        }
      </div>

      {/* ── ADDIM 1: Media seç ── */}
      {step === 1 && (
        <div style={{ flex: 1, overflowY: 'auto', animation: 'fadeIn 0.2s ease' }}>
          {files.length === 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 20, padding: 32 }}>
              <div style={{ width: 100, height: 100, borderRadius: '50%', background: '#eef2ff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#6366f1" strokeWidth="1.5" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: '#0f172a', marginBottom: 6 }}>Paylaşmaq istəyirsən?</div>
                <div style={{ fontSize: 14, color: '#94a3b8' }}>Şəkil və ya video seç</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12, width: '100%', maxWidth: 280 }}>
                <button onClick={() => imgRef.current?.click()}
                  style={{ background: 'linear-gradient(135deg,#6366f1,#818cf8)', color: '#fff', border: 'none', borderRadius: 14, padding: '14px', fontSize: 15, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, boxShadow: '0 6px 20px rgba(99,102,241,0.3)' }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                  📷 Şəkil seç (max 3)
                </button>
                <button onClick={() => vidRef.current?.click()}
                  style={{ background: '#fff', color: '#f59e0b', border: '2px solid #fde68a', borderRadius: 14, padding: '14px', fontSize: 15, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
                  🎬 Video seç (max 60 san)
                </button>
              </div>
            </div>
          ) : (
            <div style={{ animation: 'fadeIn 0.2s ease' }}>
              {/* Media preview */}
              <div style={{ position: 'relative', background: '#000' }}>
                {mediaType === 'video'
                  ? <video src={files[0].preview} controls style={{ width: '100%', maxHeight: 400, display: 'block' }} />
                  : <img src={files[activeIdx].preview} style={{ width: '100%', maxHeight: 420, objectFit: 'cover', display: 'block' }} />
                }
                <button onClick={() => removeFile(activeIdx)}
                  style={{ position: 'absolute', top: 12, right: 12, width: 32, height: 32, borderRadius: '50%', background: 'rgba(0,0,0,0.65)', border: 'none', color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>✕</button>

                {/* Thumbnail sıra */}
                {mediaType === 'image' && (
                  <div style={{ display: 'flex', gap: 4, padding: '8px 10px', background: 'rgba(0,0,0,0.5)', position: 'absolute', bottom: 0, left: 0, right: 0 }}>
                    {files.map((f, i) => (
                      <div key={i} onClick={() => setActiveIdx(i)}
                        style={{ width: 48, height: 48, borderRadius: 10, overflow: 'hidden', flexShrink: 0, border: i === activeIdx ? '2.5px solid #fff' : '2.5px solid rgba(255,255,255,0.3)', cursor: 'pointer' }}>
                        <img src={f.preview} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      </div>
                    ))}
                    {files.length < 3 && mediaType === 'image' && (
                      <div onClick={() => imgRef.current?.click()}
                        style={{ width: 48, height: 48, borderRadius: 10, border: '2.5px dashed rgba(255,255,255,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 24, cursor: 'pointer', flexShrink: 0 }}>+</div>
                    )}
                  </div>
                )}
              </div>

              {compressing && <div style={{ padding: '12px 20px', fontSize: 13, color: '#6366f1', fontWeight: 600, textAlign: 'center' }}>Şəkil optimallaşdırılır...</div>}

              {/* İrəli düyməsi */}
              <div style={{ padding: '16px 20px' }}>
                <button onClick={() => setStep(2)}
                  style={{ width: '100%', background: 'linear-gradient(135deg,#6366f1,#818cf8)', color: '#fff', border: 'none', borderRadius: 14, padding: '14px', fontSize: 15, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit', boxShadow: '0 6px 20px rgba(99,102,241,0.3)' }}>
                  İrəli →
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── ADDIM 2: Təfərrüatlar ── */}
      {step === 2 && (
        <div style={{ flex: 1, overflowY: 'auto', animation: 'fadeIn 0.2s ease' }}>

          {/* Kiçik media + açıqlama */}
          <div style={{ background: '#fff', padding: '16px 20px', display: 'flex', gap: 12, borderBottom: '1px solid #f1f5f9' }}>
            {/* Kiçik thumbnail */}
            <div style={{ width: 72, height: 72, borderRadius: 12, overflow: 'hidden', flexShrink: 0, background: '#e2e8f0' }}>
              {mediaType === 'video'
                ? <video src={files[0].preview} style={{ width: '100%', height: '100%', objectFit: 'cover' }} muted />
                : <img src={files[activeIdx]?.preview} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              }
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#0f172a', marginBottom: 6 }}>{user?.displayName || user?.username}</div>
              <textarea ref={textRef} value={postContent} onChange={e => handleTextChange(e.target.value)}
                maxLength={MAX} rows={3} autoFocus
                placeholder="Açıqlama yaz... #hashtag @mention"
                style={{ width: '100%', background: 'none', border: 'none', outline: 'none', fontSize: 15, lineHeight: 1.6, color: '#0f172a', fontFamily: 'inherit', resize: 'none' }}
              />
              {MAX - postContent.length < 80 && (
                <div style={{ fontSize: 11, color: MAX - postContent.length < 20 ? '#f43f5e' : '#94a3b8', textAlign: 'right' }}>{MAX - postContent.length}</div>
              )}
            </div>
          </div>

          {/* Mention siyahısı */}
          {mentionResults.length > 0 && (
            <div style={{ background: '#fff', borderBottom: '1px solid #f1f5f9' }}>
              {mentionResults.map((u: any) => (
                <div key={u.id} onClick={() => selectMention(u.username)}
                  style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', borderBottom: '1px solid #f8fafc' }}>
                  <div style={{ width: 32, height: 32, borderRadius: '50%', overflow: 'hidden', background: 'linear-gradient(135deg,#6366f1,#a5b4fc)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
                    {u.avatarUrl ? <img src={u.avatarUrl} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : u.username?.[0]?.toUpperCase()}
                  </div>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: '#0f172a' }}>{u.displayName || u.username}</div>
                    <div style={{ fontSize: 12, color: '#94a3b8' }}>@{u.username}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Seçimlər */}
          <div style={{ background: '#fff', marginTop: 8 }}>
            {/* Kimə görünür */}
            <div onClick={() => setShowAudienceModal(true)}
              style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '15px 20px', borderBottom: '1px solid #f8fafc', cursor: 'pointer' }}>
              <span style={{ fontSize: 20 }}>{audience === 'public' ? '🌍' : '👥'}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#0f172a' }}>Kimə görünür</div>
                <div style={{ fontSize: 12, color: '#6366f1', fontWeight: 600, marginTop: 1 }}>{audience === 'public' ? 'Hamı' : 'Yalnız izləyicilər'}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
            </div>

            {/* Yer */}
            <div onClick={() => setShowLocationInput(v => !v)}
              style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '15px 20px', borderBottom: showLocationInput ? 'none' : '1px solid #f8fafc', cursor: 'pointer' }}>
              <span style={{ fontSize: 20 }}>📍</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#0f172a' }}>Yer əlavə et</div>
                {location && <div style={{ fontSize: 12, color: '#10b981', fontWeight: 600, marginTop: 1 }}>{location}</div>}
              </div>
              {location
                ? <button onClick={e => { e.stopPropagation(); setLocation(''); setShowLocationInput(false); }} style={{ background: 'none', border: 'none', color: '#94a3b8', fontSize: 18, cursor: 'pointer', padding: 0 }}>✕</button>
                : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
              }
            </div>
            {showLocationInput && (
              <LocationPicker value={location} onChange={v => { setLocation(v); setShowLocationInput(false); }} />
            )}
          </div>

          {/* Musiqi */}
          <div style={{ background: '#fff', borderTop: '1px solid #f8fafc' }}>
            {/* Seçilmiş musiqi */}
            {selectedMusic ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 20px' }}>
                <span style={{ fontSize: 20 }}>🎵</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#0f172a' }}>{selectedMusic.name}</div>
                  <div style={{ fontSize: 11, color: '#94a3b8' }}>{selectedMusic.artist}</div>
                </div>
                <button onClick={() => setSelectedMusic(null)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', fontSize: 18 }}>✕</button>
              </div>
            ) : (
              <div onClick={() => setShowMusicPanel(v => !v)}
                style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '15px 20px', cursor: 'pointer' }}>
                <span style={{ fontSize: 20 }}>🎵</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: '#0f172a' }}>Musiqi əlavə et</div>
                  <div style={{ fontSize: 12, color: '#94a3b8' }}>Jamendo — pulsuz musiqi</div>
                </div>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
              </div>
            )}

            {/* Musiqi axtarış paneli */}
            {showMusicPanel && (
              <div style={{ padding: '0 20px 16px' }}>
                <div style={{ position: 'relative', marginBottom: 10 }}>
                  <input value={musicQuery}
                    onChange={e => {
                      setMusicQuery(e.target.value);
                      clearTimeout(musicTimer.current);
                      musicTimer.current = setTimeout(() => searchMusic(e.target.value), 500);
                    }}
                    placeholder="Mahnı adı axtar..."
                    autoFocus
                    style={{ width: '100%', background: '#f8fafc', border: '1.5px solid #e2e8f0', borderRadius: 10, padding: '10px 14px', fontSize: 14, color: '#0f172a', fontFamily: 'inherit', outline: 'none' }}
                  />
                  {musicSearching && <span style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 12, color: '#6366f1' }}>🔍</span>}
                </div>
                {musicResults.length > 0 && (
                  <div style={{ maxHeight: 220, overflowY: 'auto', borderRadius: 12, border: '1px solid #e2e8f0', overflow: 'hidden' }}>
                    {musicResults.map((t: any) => (
                      <div key={t.id}
                        style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', borderBottom: '1px solid #f8fafc' }}>
                        {/* Artwork */}
                        <div style={{ width: 40, height: 40, borderRadius: 8, overflow: 'hidden', flexShrink: 0, background: '#e2e8f0' }}>
                          {t.artwork && <img src={t.artwork} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 13, fontWeight: 700, color: '#0f172a', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.name}</div>
                          <div style={{ fontSize: 11, color: '#94a3b8' }}>{t.artist_name}</div>
                        </div>
                        {/* Preview */}
                        <button onClick={() => playPreview(t.audio)}
                          style={{ width: 30, height: 30, borderRadius: '50%', background: '#eef2ff', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          <svg width="11" height="11" viewBox="0 0 24 24" fill="#6366f1"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        </button>
                        <button onClick={() => selectMusic(t)}
                          style={{ background: '#6366f1', border: 'none', borderRadius: 99, padding: '5px 12px', fontSize: 11, fontWeight: 700, color: '#fff', cursor: 'pointer', fontFamily: 'inherit', flexShrink: 0 }}>
                          Seç
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Paylaş düyməsi */}
          <div style={{ padding: '16px 20px 40px' }}>
            <button onClick={submit} disabled={!canPost}
              style={{ width: '100%', background: canPost ? 'linear-gradient(135deg,#6366f1,#818cf8)' : '#e2e8f0', color: canPost ? '#fff' : '#94a3b8', border: 'none', borderRadius: 14, padding: '15px', fontSize: 15, fontWeight: 700, cursor: canPost ? 'pointer' : 'default', fontFamily: 'inherit', boxShadow: canPost ? '0 6px 20px rgba(99,102,241,0.3)' : 'none' }}>
              Paylaş
            </button>
          </div>
        </div>
      )}

      {/* Kimə görünür modal */}
      {showAudienceModal && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 99999, display: 'flex', alignItems: 'flex-end' }}>
          <div onClick={() => setShowAudienceModal(false)} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)' }} />
          <div style={{ position: 'relative', width: '100%', background: '#fff', borderRadius: '20px 20px 0 0', paddingBottom: 'calc(90px + env(safe-area-inset-bottom))' }}>
            <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 8px' }}>
              <div style={{ width: 36, height: 4, borderRadius: 99, background: '#e2e8f0' }} />
            </div>
            <div style={{ textAlign: 'center', padding: '4px 20px 16px', fontSize: 16, fontWeight: 800, color: '#0f172a', borderBottom: '1px solid #f1f5f9' }}>Kimə görünür?</div>
            {[
              { key: 'public',    icon: '🌍', label: 'Hamı',         desc: 'Bütün istifadəçilər görə bilər' },
              { key: 'followers', icon: '👥', label: 'İzləyicilər',  desc: 'Yalnız izləyicilər görə bilər' },
              { key: 'private',   icon: '🔒', label: 'Yalnız mən',   desc: 'Heç kim görə bilməz' },
            ].map(opt => (
              <div key={opt.key} onClick={() => { setAudience(opt.key as any); setShowAudienceModal(false); }}
                style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '18px 20px', cursor: 'pointer', background: audience === opt.key ? '#f5f3ff' : 'transparent', borderBottom: '1px solid #f8fafc' }}>
                <span style={{ fontSize: 28 }}>{opt.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 15, fontWeight: 700, color: '#0f172a' }}>{opt.label}</div>
                  <div style={{ fontSize: 13, color: '#94a3b8', marginTop: 2 }}>{opt.desc}</div>
                </div>
                {audience === opt.key && (
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      <input ref={imgRef} type="file" accept="image/*" multiple onChange={pickImages} style={{ display: 'none' }} />
      <input ref={vidRef} type="file" accept="video/*" onChange={pickVideo} style={{ display: 'none' }} />
    </div>
  );
}

// ── Compositor ────────────────────────────────────────
function Composer({ user, onPosted }: { user: any; onPosted: (p: any) => void }) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [commentPost, setCommentPost] = useState<any>(null);
  const [focused, setFocused] = useState(false);
  const [files, setFiles] = useState<{ file: File; preview: string; type: 'image' | 'video'; compressed?: number }[]>([]);
  const [activeIdx, setActiveIdx] = useState(0);
  const [compressing, setCompressing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  const imgRef = useRef<HTMLInputElement>(null);
  const vidRef = useRef<HTMLInputElement>(null);
  const touchStartX = useRef(0);
  const MAX = 500;
  const left = MAX - content.length;
  const can = (content.trim().length > 0 || files.length > 0) && !loading && content.length <= MAX;

  async function addFiles(e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video') {
    const selected = Array.from(e.target.files || []);
    if (!selected.length) return;
    const remaining = 3 - files.length;
    const toAdd = selected.slice(0, remaining);
    setCompressing(true);

    const newFiles = await Promise.all(toAdd.map(async f => {
      if (type === 'image') {
        const compressed = await compressImage(f);
        const previewUrl = URL.createObjectURL(compressed);
        return {
          file: compressed,
          preview: previewUrl,
          type: 'image' as const,
          compressed: Math.round(compressed.size / 1024),
        };
      } else {
        // Video — ölçü yoxla (max 50MB)
        if (f.size > 50 * 1024 * 1024) {
          alert('Video max 50MB ola bilər');
          return null;
        }
        // Müddət yoxla — max 60 saniyə
        const duration = await new Promise<number>(resolve => {
          const v = document.createElement('video');
          v.preload = 'metadata';
          v.onloadedmetadata = () => { URL.revokeObjectURL(v.src); resolve(v.duration); };
          v.src = URL.createObjectURL(f);
        });
        if (duration > 60) {
          alert(`Video max 60 saniyə ola bilər (sizinki: ${~~duration} san)`);
          return null;
        }
        return { file: f, preview: URL.createObjectURL(f), type: 'video' as const };
      }
    }));

    setFiles(prev => [...prev, ...newFiles.filter(Boolean) as any]);
    setActiveIdx(files.length);
    setCompressing(false);
    e.target.value = '';
  }

  function removeFile(idx: number) {
    URL.revokeObjectURL(files[idx].preview);
    setFiles(prev => prev.filter((_, i) => i !== idx));
    setActiveIdx(prev => Math.max(0, prev - 1));
  }

  // Swipe
  function onTouchStart(e: React.TouchEvent) { touchStartX.current = e.touches[0].clientX; }
  function onTouchEnd(e: React.TouchEvent) {
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(dx) > 40) {
      if (dx < 0 && activeIdx < files.length - 1) setActiveIdx(i => i + 1);
      if (dx > 0 && activeIdx > 0) setActiveIdx(i => i - 1);
    }
  }

  async function submit() {
    if (!can) return;
    setLoading(true);
        const mediaUrls: string[] = [];

    for (let i = 0; i < files.length; i++) {
      try {
        const fd = new FormData();
        fd.append('file', files[i].file);
        const r = await apiFetch(`${API}/storage/upload`, { method: 'POST',
          body: fd });
        const text = await r.text();
        let d: any = {};
        try { d = JSON.parse(text); } catch {}
        // Bütün response formatlarını yoxla
        const url = d?.data?.data?.url || d?.data?.url || d?.url || null;
        if (url && typeof url === 'string') {
          mediaUrls.push(url);
        } else {
          console.error('Upload xetasi:', r.status, text);
          setUploadProgress(`Fayl ${i+1} yüklənmədi (${r.status})`);
          await new Promise(res => setTimeout(res, 1500));
        }
      } catch (e) { console.error('Upload error:', e); }
    }
    const res = await apiFetch(`${API}/posts`, { method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` },
      body: JSON.stringify({ content, mediaUrls }),
    });
    const data = await res.json();
    if (data.success) {
      files.forEach(f => URL.revokeObjectURL(f.preview));
      setContent(''); setFiles([]); setActiveIdx(0);
      onPosted({ ...data.data, user, isLiked: false, isBookmarked: false, isReposted: false });
    }
    setLoading(false);
  }

  return (
    <div style={{ background: '#fff', borderRadius: 20, padding: 16, marginBottom: 12, boxShadow: '0 1px 3px rgba(15,23,42,0.04)', border: focused ? '1px solid #c7d2fe' : '1px solid #f1f5f9', transition: 'border-color 0.2s' }}>
      <div style={{ display: 'flex', gap: 12 }}>
        {user && <Avatar name={user.username} url={user.avatarUrl} size={42} />}
        <div style={{ flex: 1 }}>
          <textarea value={content} onChange={e => setContent(e.target.value)}
            onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
            placeholder="Nə düşünürsən?" maxLength={MAX}
            rows={focused || content || files.length > 0 ? 3 : 1}
            style={{ width: '100%', background: 'transparent', border: 'none', outline: 'none', color: '#0f172a', fontSize: 15, lineHeight: 1.6, fontFamily: 'inherit', caretColor: '#6366f1', resize: 'none' }}
          />

          {/* Media carousel */}
          {files.length > 0 && (
            <div style={{ marginTop: 10, borderRadius: 14, overflow: 'hidden', border: '1px solid #e2e8f0', position: 'relative', userSelect: 'none' }}
              onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
              {/* Aktiv media */}
              <div style={{ position: 'relative' }}>
                {files[activeIdx].type === 'image' ? (
                  <img src={files[activeIdx].preview} alt="" style={{ width: '100%', maxHeight: 280, objectFit: 'cover', display: 'block' }} />
                ) : (
                  <video src={files[activeIdx].preview} controls style={{ width: '100%', maxHeight: 280, display: 'block', background: '#000' }} />
                )}

                {/* Sil düyməsi */}
                <button onClick={() => removeFile(activeIdx)}
                  style={{ position: 'absolute', top: 8, right: 8, background: 'rgba(0,0,0,0.65)', border: 'none', borderRadius: '50%', width: 30, height: 30, cursor: 'pointer', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14 }}>✕</button>

                {/* Sıxılma məlumatı */}
                {files[activeIdx].compressed && (
                  <div style={{ position: 'absolute', bottom: 8, left: 8, background: 'rgba(0,0,0,0.6)', color: '#fff', fontSize: 10, fontWeight: 600, padding: '3px 8px', borderRadius: 99 }}>
                    📦 {files[activeIdx].compressed} KB
                  </div>
                )}

                {/* Say göstəricisi */}
                {files.length > 1 && (
                  <div style={{ position: 'absolute', top: 8, left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: 5 }}>
                    {files.map((_, i) => (
                      <div key={i} onClick={() => setActiveIdx(i)}
                        style={{ width: i === activeIdx ? 16 : 6, height: 6, borderRadius: 99, background: i === activeIdx ? '#fff' : 'rgba(255,255,255,0.5)', cursor: 'pointer', transition: 'all 0.2s' }} />
                    ))}
                  </div>
                )}

                {/* Sol/sağ oxlar */}
                {files.length > 1 && activeIdx > 0 && (
                  <button onClick={() => setActiveIdx(i => i - 1)}
                    style={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', background: 'rgba(0,0,0,0.5)', border: 'none', borderRadius: '50%', width: 32, height: 32, cursor: 'pointer', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
                  </button>
                )}
                {files.length > 1 && activeIdx < files.length - 1 && (
                  <button onClick={() => setActiveIdx(i => i + 1)}
                    style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', background: 'rgba(0,0,0,0.5)', border: 'none', borderRadius: '50%', width: 32, height: 32, cursor: 'pointer', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
                  </button>
                )}
              </div>

              {/* Kiçik thumbnail-lər */}
              {files.length > 1 && (
                <div style={{ display: 'flex', gap: 3, padding: 6, background: '#f8fafc' }}>
                  {files.map((f, i) => (
                    <div key={i} onClick={() => setActiveIdx(i)}
                      style={{ width: 48, height: 48, borderRadius: 8, overflow: 'hidden', cursor: 'pointer', border: i === activeIdx ? '2.5px solid #6366f1' : '2.5px solid transparent', flexShrink: 0, transition: 'border-color 0.15s' }}>
                      {f.type === 'image'
                        ? <img src={f.preview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        : <div style={{ width: '100%', height: '100%', background: '#1e293b', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 18 }}>▶</div>
                      }
                    </div>
                  ))}
                  {files.length < 3 && (
                    <div onClick={() => imgRef.current?.click()}
                      style={{ width: 48, height: 48, borderRadius: 8, border: '2px dashed #e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#94a3b8', fontSize: 20, flexShrink: 0 }}>
                      +
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Sıxılır göstəricisi */}
          {compressing && (
            <div style={{ marginTop: 8, fontSize: 12, color: '#6366f1', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6 }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" style={{ animation: 'spin 0.8s linear infinite' }}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
              Şəkil sıxılır...
            </div>
          )}

          <div style={{ display: 'flex', alignItems: 'center', marginTop: 10, paddingTop: 10, borderTop: '1px solid #f1f5f9', gap: 4 }}>
            {/* Şəkil əlavə et */}
            <button onClick={() => imgRef.current?.click()} disabled={files.length >= 3 || compressing}
              style={{ background: files.some(f => f.type === 'image') ? '#eef2ff' : 'none', border: 'none', cursor: files.length >= 3 ? 'not-allowed' : 'pointer', color: files.length >= 3 ? '#cbd5e1' : '#6366f1', padding: 8, borderRadius: 10, display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, fontWeight: 600 }}>
              <IImage />
              {files.length > 0 && <span>{files.filter(f => f.type === 'image').length}/3</span>}
            </button>
            <input ref={imgRef} type="file" accept="image/*" multiple onChange={e => addFiles(e, 'image')} style={{ display: 'none' }} />

            {/* Video əlavə et */}
            <button onClick={() => vidRef.current?.click()} disabled={files.length >= 3}
              style={{ background: files.some(f => f.type === 'video') ? '#fef9c3' : 'none', border: 'none', cursor: files.length >= 3 ? 'not-allowed' : 'pointer', color: files.length >= 3 ? '#cbd5e1' : '#f59e0b', padding: 8, borderRadius: 10, display: 'flex', alignItems: 'center', gap: 4 }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                <polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/>
              </svg>
            </button>
            <input ref={vidRef} type="file" accept="video/*" onChange={e => addFiles(e, 'video')} style={{ display: 'none' }} />

            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginLeft: 'auto' }}>
              {uploadProgress && <span style={{ fontSize: 11, color: '#6366f1', fontWeight: 600 }}>{uploadProgress}</span>}
              {!uploadProgress && content.length > 0 && left <= 80 && (
                <span style={{ fontSize: 12, color: left < 20 ? '#f43f5e' : '#94a3b8', fontWeight: 600 }}>{left}</span>
              )}
              <button onClick={submit} disabled={!can}
                style={{ background: can ? 'linear-gradient(135deg, #6366f1, #818cf8)' : '#e2e8f0', color: can ? '#fff' : '#94a3b8', border: 'none', borderRadius: 99, padding: '9px 20px', fontSize: 13, fontWeight: 700, cursor: can ? 'pointer' : 'not-allowed', transition: 'all 0.2s', boxShadow: can ? '0 4px 12px rgba(99,102,241,0.25)' : 'none' }}>
                {loading ? '...' : 'Paylaş'}
              </button>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}

// ── Axın Reels Feed (TikTok × Instagram hibrid) ──────
function WaveBar() {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:2.5, height:18 }}>
      {[0.4,0.7,1,0.85,0.6,1,0.75,0.5,0.9,0.65,1,0.8].map((h,i) => (
        <div key={i} style={{
          width:3, borderRadius:99,
          background:'rgba(255,255,255,0.9)',
          height:`${h*18}px`,
          animation:`wave 1.1s ${i*0.08}s ease-in-out infinite alternate`,
        }}/>
      ))}
      <style>{`@keyframes wave{from{transform:scaleY(0.3)}to{transform:scaleY(1)}}`}</style>
    </div>
  );
}

function ReelCard({ post, isActive, me, onComment, onNavigate }: {
  post:any; isActive:boolean; me:any;
  onComment:(p:any)=>void; onNavigate:(p:string)=>void;
}) {
  const vidRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dur, setDur] = useState(0);
  const [muted, setMuted] = useState(false);
  const [liked, setLiked] = useState(post.isLiked||false);
  const [likeCount, setLikeCount] = useState(post.likeCount||0);
  const [saved, setSaved] = useState(post.isBookmarked||false);
  const [likeAnim, setLikeAnim] = useState(false);
  const [showHeart, setShowHeart] = useState(false);
  const lastTap = useRef(0);

  const mediaUrl = post.mediaUrls?.[0] || '';
  const isVid = /\.(mp4|mov|webm)/i.test(mediaUrl);
  const fmt = (s:number) => `${~~(s/60)}:${String(~~(s%60)).padStart(2,'0')}`;

  // Aktiv olanda play, deyilsə pause
  useEffect(() => {
    const v = vidRef.current;
    if (!v || !isVid) return;
    if (isActive) { v.play().then(()=>setPlaying(true)).catch(()=>{}); }
    else { v.pause(); setPlaying(false); v.currentTime=0; setProgress(0); }
  }, [isActive]);

  function togglePlay() {
    const v = vidRef.current;
    if (!v) return;
    if (playing) { v.pause(); setPlaying(false); }
    else { v.play().then(()=>setPlaying(true)).catch(()=>{}); }
  }

  function doubleTapLike() {
    const now = Date.now();
    if (now - lastTap.current < 350) {
      if (!liked) {
        setLiked(true);
        setLikeCount(c=>c+1);
        toggleLikeAPI();
      }
      setShowHeart(true);
      setTimeout(()=>setShowHeart(false), 900);
    }
    lastTap.current = now;
    togglePlay();
  }

  async function toggleLike() {
    const prev = liked;
    setLiked(!prev);
    setLikeCount(c=>prev?c-1:c+1);
    setLikeAnim(true);
    setTimeout(()=>setLikeAnim(false),400);
    toggleLikeAPI();
  }

  async function toggleLikeAPI() {
        await apiFetch(`${API}/posts/${post.id}/like`, { method:'POST' });
  }

  async function toggleSave() {
    setSaved((s:boolean)=>!s);
        await apiFetch(`${API}/posts/${post.id}/bookmark`, { method:'POST' }).catch(()=>{});
  }

  async function doShare() {
    const url = `${window.location.origin}/post/${post.id}`;
    if ((navigator as any).share) { try { await (navigator as any).share({title:'Axın',url}); } catch {} }
    else { await navigator.clipboard.writeText(url); }
  }

  const fmtCount = (n:number) => n>=1000000 ? (n/1000000).toFixed(1)+'M' : n>=1000 ? (n/1000).toFixed(n>=10000?0:1)+'K' : String(n||0);

  return (
    <div style={{
      position:'relative', width:'100%', height:'100vh',
      flexShrink:0, overflow:'hidden', background:'#000',
    }} onClick={doubleTapLike}>

      {/* ── Media ── */}
      {isVid ? (
        <video ref={vidRef} src={mediaUrl} muted={muted} loop playsInline
          onTimeUpdate={()=>{ if(vidRef.current) setProgress(vidRef.current.currentTime/(vidRef.current.duration||1)*100); }}
          onLoadedMetadata={e=>setDur((e.target as HTMLVideoElement).duration)}
          style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'cover'}}
        />
      ) : mediaUrl ? (
        <img src={mediaUrl} alt="" style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'cover'}}/>
      ) : (
        <div style={{position:'absolute',inset:0,background:
          `linear-gradient(160deg,${['#6366f1','#8b5cf6','#06b6d4','#10b981','#f59e0b','#ef4444'][post.user?.username?.charCodeAt(0)%6||0]},#0f172a)`
        }}>
          <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',padding:32}}>
            <p style={{color:'#fff',fontSize:20,fontWeight:700,lineHeight:1.6,textAlign:'center',textShadow:'0 2px 12px rgba(0,0,0,0.4)'}}>{post.content}</p>
          </div>
        </div>
      )}

      {/* Gradient overlays */}
      <div style={{position:'absolute',inset:0,background:'linear-gradient(to bottom,rgba(0,0,0,0.25) 0%,transparent 30%,transparent 50%,rgba(0,0,0,0.7) 100%)',pointerEvents:'none'}}/>

      {/* ── Double-tap heart ── */}
      {showHeart && (
        <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',pointerEvents:'none',zIndex:20}}>
          <div style={{animation:'heartPop 0.9s ease forwards'}}>
            <svg width="100" height="100" viewBox="0 0 24 24" fill="#f43f5e" filter="drop-shadow(0 0 20px rgba(244,63,94,0.6))">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
          </div>
          <style>{`@keyframes heartPop{0%{transform:scale(0);opacity:0}30%{transform:scale(1.3);opacity:1}60%{transform:scale(1);opacity:1}100%{transform:scale(1.1);opacity:0}}`}</style>
        </div>
      )}

      {/* Pause icon */}
      {!playing && isVid && (
        <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',pointerEvents:'none',zIndex:5}}>
          <div style={{width:72,height:72,borderRadius:'50%',background:'rgba(0,0,0,0.4)',backdropFilter:'blur(8px)',display:'flex',alignItems:'center',justifyContent:'center',border:'1.5px solid rgba(255,255,255,0.3)'}}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff" style={{marginLeft:4}}><polygon points="5 3 19 12 5 21"/></svg>
          </div>
        </div>
      )}

      {/* ── Sağ panel — aksiyalar ── */}
      <div style={{
        position:'absolute', right:12, bottom:130, zIndex:10,
        display:'flex', flexDirection:'column', alignItems:'center', gap:20,
      }} onClick={e=>e.stopPropagation()}>

        {/* Avatar + follow */}
        <div style={{position:'relative', marginBottom:4}}>
          <div onClick={()=>onNavigate(`/profile/${post.user?.username}`)} style={{
            width:48, height:48, borderRadius:'50%', overflow:'hidden',
            border:'2.5px solid #fff', cursor:'pointer',
            background:'linear-gradient(135deg,#6366f1,#8b5cf6)',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:18, fontWeight:800, color:'#fff',
          }}>
            {post.user?.avatarUrl
              ? <img src={post.user.avatarUrl} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
              : post.user?.username?.[0]?.toUpperCase()
            }
          </div>
          {post.user?.username !== me?.username && (
            <div style={{
              position:'absolute', bottom:-10, left:'50%', transform:'translateX(-50%)',
              width:22, height:22, borderRadius:'50%',
              background:'linear-gradient(135deg,#6366f1,#8b5cf6)',
              display:'flex', alignItems:'center', justifyContent:'center',
              border:'2px solid #000', cursor:'pointer',
              boxShadow:'0 0 10px rgba(99,102,241,0.6)',
            }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="#fff" strokeWidth="0"><line x1="12" y1="5" x2="12" y2="19" stroke="#fff" strokeWidth="3" strokeLinecap="round"/><line x1="5" y1="12" x2="19" y2="12" stroke="#fff" strokeWidth="3" strokeLinecap="round"/></svg>
            </div>
          )}
        </div>

        {/* Like */}
        <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:3}}>
          <button onClick={toggleLike} style={{
            background:'none', border:'none', cursor:'pointer', padding:8,
            borderRadius:'50%',
            background: liked ? 'rgba(244,63,94,0.15)' : 'rgba(255,255,255,0.1)',
            backdropFilter:'blur(4px)',
            transform: likeAnim ? 'scale(1.35)' : 'scale(1)',
            transition:'all 0.2s cubic-bezier(.34,1.56,.64,1)',
          } as any}>
            <svg width="28" height="28" viewBox="0 0 24 24"
              fill={liked?'#f43f5e':'none'} stroke={liked?'#f43f5e':'#fff'} strokeWidth="1.8">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" strokeLinecap="round"/>
            </svg>
          </button>
          <span style={{color:'#fff',fontSize:12,fontWeight:700,textShadow:'0 1px 4px rgba(0,0,0,0.5)'}}>{fmtCount(likeCount)}</span>
        </div>

        {/* Şərh */}
        <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:3}}>
          <button onClick={()=>onComment(post)} style={{
            background:'rgba(255,255,255,0.1)', backdropFilter:'blur(4px)',
            border:'none', cursor:'pointer', padding:8, borderRadius:'50%',
          }}>
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
          <span style={{color:'#fff',fontSize:12,fontWeight:700,textShadow:'0 1px 4px rgba(0,0,0,0.5)'}}>{fmtCount(post.replyCount||0)}</span>
        </div>

        {/* Saxla */}
        <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:3}}>
          <button onClick={toggleSave} style={{
            background: saved ? 'rgba(99,102,241,0.2)' : 'rgba(255,255,255,0.1)',
            backdropFilter:'blur(4px)',
            border:'none', cursor:'pointer', padding:8, borderRadius:'50%',
            transition:'all 0.2s',
          }}>
            <svg width="24" height="24" viewBox="0 0 24 24"
              fill={saved?'#6366f1':'none'} stroke={saved?'#6366f1':'#fff'} strokeWidth="1.8" strokeLinecap="round">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
          <span style={{color:'#fff',fontSize:12,fontWeight:700,textShadow:'0 1px 4px rgba(0,0,0,0.5)'}}>{fmtCount(post.bookmarkCount||0)}</span>
        </div>

        {/* Paylaş */}
        <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:3}}>
          <button onClick={doShare} style={{
            background:'rgba(255,255,255,0.1)', backdropFilter:'blur(4px)',
            border:'none', cursor:'pointer', padding:8, borderRadius:'50%',
          }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round">
              <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
            </svg>
          </button>
          <span style={{color:'#fff',fontSize:12,fontWeight:700,textShadow:'0 1px 4px rgba(0,0,0,0.5)'}}>{fmtCount(post.shareCount||0)}</span>
        </div>

        {/* Səs */}
        <button onClick={e=>{e.stopPropagation();setMuted(m=>!m);if(vidRef.current)vidRef.current.muted=!muted;}} style={{
          background:'rgba(255,255,255,0.1)', backdropFilter:'blur(4px)',
          border:'none', cursor:'pointer', padding:8, borderRadius:'50%',
        }}>
          {muted
            ? <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>
            : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
          }
        </button>
      </div>

      {/* ── Sol alt: istifadəçi + mətn + musiqi ── */}
      <div style={{
        position:'absolute', bottom:0, left:0, right:80,
        padding:'0 16px 100px', zIndex:10,
      }} onClick={e=>e.stopPropagation()}>
        {/* İstifadəçi adı */}
        <div onClick={()=>onNavigate(`/profile/${post.user?.username}`)}
          style={{display:'flex',alignItems:'center',gap:8,marginBottom:8,cursor:'pointer'}}>
          <span style={{color:'#fff',fontWeight:800,fontSize:15,textShadow:'0 1px 6px rgba(0,0,0,0.5)'}}>
            @{post.user?.username}
          </span>
          {post.user?.username !== me?.username && (
            <span style={{
              fontSize:11, fontWeight:700, color:'#fff',
              border:'1.5px solid rgba(255,255,255,0.6)',
              borderRadius:99, padding:'2px 10px',
            }}>İzlə</span>
          )}
        </div>

        {/* Mətn */}
        {post.content && (
          <p style={{
            color:'rgba(255,255,255,0.9)', fontSize:13, lineHeight:1.55,
            margin:'0 0 10px', textShadow:'0 1px 6px rgba(0,0,0,0.5)',
            display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical', overflow:'hidden',
          } as any}>{post.content}</p>
        )}

        {/* Musiqi — waveform animasiya */}
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <div style={{
            width:32, height:32, borderRadius:'50%',
            background:'linear-gradient(135deg,#6366f1,#8b5cf6)',
            display:'flex', alignItems:'center', justifyContent:'center',
            animation:'spin 4s linear infinite',
            boxShadow:'0 0 12px rgba(99,102,241,0.5)',
          }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="#fff"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
          </div>
          <div style={{overflow:'hidden', flex:1}}>
            <div style={{
              display:'flex', alignItems:'center', gap:6,
              animation:'marquee 8s linear infinite',
              whiteSpace:'nowrap',
            }}>
              <span style={{color:'rgba(255,255,255,0.85)',fontSize:12,fontWeight:600}}>
                {post.musicTitle || 'Orijinal səs'}
              </span>
              <span style={{color:'rgba(255,255,255,0.5)',fontSize:11}}>·</span>
              <span style={{color:'rgba(255,255,255,0.6)',fontSize:11}}>{post.user?.username}</span>
            </div>
          </div>
          <WaveBar/>
        </div>
      </div>

      {/* ── Alt scrubber (video üçün) ── */}
      {isVid && (
        <div style={{
          position:'absolute', bottom:0, left:0, right:0, height:3,
          background:'rgba(255,255,255,0.15)', zIndex:20,
        }}>
          <div style={{
            height:'100%', width:`${progress}%`,
            background:'linear-gradient(90deg,#6366f1,#8b5cf6)',
            transition:'width 0.1s linear',
            boxShadow:'0 0 6px rgba(99,102,241,0.8)',
          }}/>
        </div>
      )}

      <style>{`
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes marquee{0%{transform:translateX(0)}50%{transform:translateX(-30%)}100%{transform:translateX(0)}}
      `}</style>
    </div>
  );
}

function AxinReelsFeed({ me, onNavigate }: { me:any; onNavigate:(p:string)=>void }) {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeIdx, setActiveIdx] = useState(0);
  const [commentPost, setCommentPost] = useState<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
        if (!getToken()) return;
    apiFetch(`${API}/feed?page=1&limit=20`)
      .then(r=>r.json())
      .then(d => { if (d.success) setPosts(d.data||[]); })
      .finally(()=>setLoading(false));
  }, []);

  // Scroll snap — aktiv indexi tap
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    function onScroll() {
      const idx = Math.round(el!.scrollTop / window.innerHeight);
      setActiveIdx(idx);
    }
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => el.removeEventListener('scroll', onScroll);
  }, []);

  if (!ready || posts === null) return <FeedSkeleton />;

  if (posts !== null && posts.length === 0) return (
    <div style={{height:'100vh',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',background:'#0f172a',color:'#fff'}}>
      <div style={{fontSize:48,marginBottom:16}}>🎬</div>
      <div style={{fontSize:17,fontWeight:700}}>Video tapılmadı</div>
      <div style={{fontSize:13,color:'rgba(255,255,255,0.5)',marginTop:6}}>İlk videonu sən paylaş!</div>
    </div>
  );

  return (
    <>
      <div ref={containerRef} style={{
        height:'100vh', overflowY:'scroll',
        scrollSnapType:'y mandatory',
        scrollBehavior:'smooth',
        background:'#000',
      }}>
        {(posts ?? []).map((post, i) => (
          <div key={post.id} style={{ scrollSnapAlign:'start', scrollSnapStop:'always' }}>
            <ReelCard
              post={post}
              isActive={i===activeIdx}
              me={me}
              onComment={setCommentPost}
              onNavigate={onNavigate}
            />
          </div>
        ))}
      </div>

      {commentPost && (
        <CommentPanel
          post={commentPost}
          me={me}
          onClose={()=>setCommentPost(null)}
          onUpdate={()=>{}}
        />
      )}
    </>
  );
}

function FeedSkeleton() {
  return (
    <div style={{ padding: '0 12px' }}>
      {[0,1,2,3].map(i => (
        <div key={i} style={{ background: '#fff', borderRadius: 16, marginBottom: 12, overflow: 'hidden', animation: 'shimmer 1.4s ease-in-out infinite' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 14px 10px' }}>
            <div style={{ width: 42, height: 42, borderRadius: '50%', background: '#f0f0f0' }}/>
            <div style={{ flex: 1 }}>
              <div style={{ width: '45%', height: 12, background: '#f0f0f0', borderRadius: 6, marginBottom: 6 }}/>
              <div style={{ width: '30%', height: 10, background: '#f0f0f0', borderRadius: 6 }}/>
            </div>
          </div>
          <div style={{ height: 200, background: '#f0f0f0', margin: '0 14px', borderRadius: 12, marginBottom: 12 }}/>
          <div style={{ padding: '0 14px 14px', display: 'flex', gap: 16 }}>
            {[0,1,2].map(j => <div key={j} style={{ width: 40, height: 12, background: '#f0f0f0', borderRadius: 6 }}/>)}
          </div>
        </div>
      ))}
      <style>{`
        @keyframes shimmer {
          0%   { opacity: 1; }
          50%  { opacity: 0.5; }
          100% { opacity: 1; }
        }
      `}</style>
    </div>
  );
}

// ── Ana komponent ───────────────────────────────────
export default function Feed() {
  const router = useRouter();
  const { unread } = useUnread();
  const [posts, setPosts]   = useState<any[] | null>(null); // null = not yet fetched
  const [user, setUser]     = useState<any>(null);
  const [loading, setLoading] = useState(true); // true until first fetch done
  const [ready, setReady]   = useState(false);  // hydration guard
  const [commentPost, setCommentPost] = useState<any>(null);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [activeTab, setActiveTab] = useState<'foryou' | 'following'>('foryou');
  const [postModalOpen, setPostModalOpen] = useState(false);
  const [addStoryOpen, setAddStoryOpen] = useState(false);
  const [uploadState, setUploadState] = useState<{
    preview: string;
    progress: number;
    done: boolean;
  } | null>(null);
  const loaderRef      = useRef<HTMLDivElement>(null);
  // Stable refs so closure never goes stale

  useEffect(() => {
    if (!getToken()) { router.push('/'); return; }
    // Parallel — both must complete before showing feed
    Promise.all([fetchMe(), fetchPosts(1, activeTab)])
      .finally(() => { setLoading(false); setReady(true); });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!getToken() || !ready) return;
    setPosts(null); // show skeleton during tab switch
    fetchPosts(1, activeTab);
  }, [activeTab]); // eslint-disable-line react-hooks/exhaustive-deps

  async function fetchMe() {
    try {
      const res = await apiFetch(`${API}/auth/me`);
      const data = await res.json();
      if (data.success) setUser(data.data);
      else { clearSession(); router.push('/'); }
    } catch {}
  }

  async function fetchPosts(pageNum = 1, tab = activeTab, append = false) {
    const endpoint = tab === 'foryou' ? `/feed?page=${pageNum}` : `/feed/following?page=${pageNum}`;
    try {
      const res = await apiFetch(`${API}${endpoint}`);
      const data = await res.json();
      if (data.success) {
        const items: any[] = data.data || [];
        if (append) {
          setPosts(prev => prev ? [...prev, ...items] : items);
        } else {
          setPosts(items);
        }
        setHasMore(items.length >= 20);
        setPage(pageNum);
      }
    } catch {}
  }

  // Infinite scroll
  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore && !loadingMore) {
                if (getToken()) {
          setLoadingMore(true);
          fetchPosts(page + 1, activeTab, true).finally(() => setLoadingMore(false));
        }
      }
    }, { threshold: 0.1 });
    if (loaderRef.current) observer.observe(loaderRef.current);
    return () => observer.disconnect();
  }, [hasMore, loadingMore, page, activeTab]);

  function updatePost(id: string, update: any) {
    if (update._deleted) {
      setPosts(prev => prev.filter(p => p.id !== id));
    } else {
      setPosts(prev => prev.map(p => p.id === id ? { ...p, ...update } : p));
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: "-apple-system,'Segoe UI',system-ui,sans-serif", display: 'flex', justifyContent: 'center' }}>
      <style>{`
        * { box-sizing:border-box; margin:0; padding:0; }
        html, body { background: #f8fafc; overflow-x: hidden; }
        /* Native pull-to-refresh enabled (no overscroll-behavior override) */
        button { font-family:inherit; }
        textarea { font-family:inherit; resize:none; }
        @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(-6px)} to{opacity:1;transform:translateY(0)} }
      `}</style>

      <div style={{ width: '100%', maxWidth: 500, paddingBottom: 120 }}>

        {/* Header */}
        <header style={{ position: 'sticky', top: 0, zIndex: 50, background: 'rgba(248,250,252,0.96)', backdropFilter: 'blur(14px)', borderBottom: '1px solid #f1f5f9' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '13px 16px 10px' }}>
            <span style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.6px', background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Axın</span>
            {user && <Avatar name={user.username} url={user.avatarUrl} size={32} />}
          </div>
          <div style={{ display: 'flex', padding: '0 12px 8px', gap: 6 }}>
            {(['foryou', 'following'] as const).map(t => (
              <button key={t} onClick={() => setActiveTab(t)}
                style={{ flex: 1, background: activeTab === t ? '#fff' : 'transparent', border: 'none', padding: '9px 0', fontSize: 13, fontWeight: activeTab === t ? 700 : 500, color: activeTab === t ? '#0f172a' : '#94a3b8', cursor: 'pointer', borderRadius: 12, transition: 'all 0.15s', boxShadow: activeTab === t ? '0 1px 4px rgba(15,23,42,0.06)' : 'none' }}>
                {t === 'foryou' ? 'Sənin üçün' : 'İzlədiklərin'}
              </button>
            ))}
          </div>
        </header>

        {/* Story sıra */}
        <div style={{ padding: '12px 12px 0' }}>
          <StoryRow me={user} onAddStory={() => setAddStoryOpen(true)} />
        </div>

        {/* Postlar */}
        <div style={{ padding: '0 12px' }}>
          {posts !== null && posts.length === 0 && !loadingMore ? (
            <div style={{ textAlign: 'center', padding: '60px 20px', color: '#94a3b8' }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>✨</div>
              <div style={{ fontSize: 16, fontWeight: 600, color: '#475569' }}>Hələ post yoxdur</div>
              <div style={{ fontSize: 13, marginTop: 6 }}>İlk postu sən et!</div>
            </div>
          ) : (posts ?? []).map((post, i) => (
            <div key={post.id} style={{ animation: i < 3 ? 'fadeIn 0.3s ease' : 'none' }}>
              <PostCard post={post} me={user} onUpdate={updatePost} onNavigate={p => router.push(p)} onComment={id => setCommentPost(posts.find(p => p.id === id))} />
            </div>
          ))}

          {/* Loader */}
          <div ref={loaderRef} style={{ height: 60, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {loadingMore && (
              <div style={{ display: 'flex', gap: 6 }}>
                {[0,1,2].map(i => <div key={i} style={{ width: 8, height: 8, borderRadius: '50%', background: '#6366f1', opacity: 0.7, animation: `bounce 1s ${i*0.15}s infinite` }} />)}
              </div>
            )}
            {!hasMore && (posts?.length ?? 0) > 0 && <span style={{ fontSize: 13, color: '#cbd5e1', fontWeight: 500 }}>Bütün postlar yükləndi ✓</span>}
          </div>
        </div>
      </div>

      {/* ── Upload indicator ── */}
      {uploadState && (
        <div style={{ position: 'fixed', top: 60, left: 16, zIndex: 500, display: 'flex', alignItems: 'center', gap: 10, background: '#fff', borderRadius: 50, padding: '6px 14px 6px 6px', boxShadow: '0 4px 20px rgba(15,23,42,0.15)', border: '1px solid #f1f5f9', animation: 'slideDown 0.3s ease' }}>
          <style>{`@keyframes slideDown{from{opacity:0;transform:translateY(-20px)}to{opacity:1;transform:translateY(0)}}`}</style>
          {/* Dairəvi progress + şəkil */}
          <div style={{ position: 'relative', width: 44, height: 44, flexShrink: 0 }}>
            <svg width="44" height="44" viewBox="0 0 44 44" style={{ position: 'absolute', inset: 0, transform: 'rotate(-90deg)' }}>
              <circle cx="22" cy="22" r="19" fill="none" stroke="#e2e8f0" strokeWidth="3"/>
              <circle cx="22" cy="22" r="19" fill="none" stroke={uploadState.done ? '#10b981' : '#6366f1'} strokeWidth="3"
                strokeDasharray={`${2 * Math.PI * 19}`}
                strokeDashoffset={`${2 * Math.PI * 19 * (1 - (uploadState.done ? 1 : uploadState.progress) / 100)}`}
                strokeLinecap="round"
                style={{ transition: 'stroke-dashoffset 0.3s ease, stroke 0.3s ease' }}
              />
            </svg>
            <div style={{ position: 'absolute', inset: 4, borderRadius: '50%', overflow: 'hidden', background: '#f1f5f9' }}>
              {uploadState.preview && (
                <img src={uploadState.preview} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              )}
            </div>
            {uploadState.done && (
              <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: 'rgba(16,185,129,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
            )}
          </div>
          <span style={{ fontSize: 13, fontWeight: 600, color: uploadState.done ? '#10b981' : '#0f172a', whiteSpace: 'nowrap' }}>
            {uploadState.done ? 'Paylaşıldı!' : 'Paylaşılır...'}
          </span>
        </div>
      )}

      {/* ── FAB: + düyməsi ── */}
      <button id="feed-fab" onClick={() => setPostModalOpen(true)}
        style={{ position: 'fixed', right: 20, bottom: 'calc(72px + env(safe-area-inset-bottom))', width: 56, height: 56, borderRadius: '50%', background: 'linear-gradient(135deg, #6366f1, #818cf8)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 6px 24px rgba(99,102,241,0.5)', zIndex: 9999 }}
        onTouchStart={e => (e.currentTarget.style.transform = 'scale(0.9)')}
        onTouchEnd={e => (e.currentTarget.style.transform = 'scale(1)')}>
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round">
          <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
        </svg>
      </button>

      {/* ── Add Story Modal ── */}
      {addStoryOpen && (
        <AddStoryModal user={user} onClose={() => setAddStoryOpen(false)} onAdded={() => setAddStoryOpen(false)} />
      )}

      {/* ── Post Modal ── */}
      {postModalOpen && (
        <PostModal
          user={user}
          onClose={() => setPostModalOpen(false)}
          onUploadStart={(preview, bindProgress) => {
            setUploadState({ preview, progress: 0, done: false });
            bindProgress((p: number) => {
              setUploadState(prev => prev ? { ...prev, progress: p } : null);
            });
          }}
          onPosted={p => {
            setPosts(prev => [p, ...prev]);
            setUploadState(prev => prev ? { ...prev, progress: 100, done: true } : null);
            setTimeout(() => setUploadState(null), 2000);
          }}
        />
      )}

      {/* Comment Panel */}
      {commentPost && (
        <CommentPanel
          post={commentPost}
          me={user}
          onClose={() => setCommentPost(null)}
          onUpdate={updatePost}
        />
      )}
    </div>
  );
}
