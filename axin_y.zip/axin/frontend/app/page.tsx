'use client';
import { getToken, apiFetch, saveSession } from '../lib/auth';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';

const API = 'http://localhost:3001/api/v1';

export default function Home() {
  const router = useRouter();
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [mounted, setMounted] = useState(false);

  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [regData, setRegData] = useState({ displayName: '', username: '', email: '', password: '' });
  const [regErrors, setRegErrors] = useState<Record<string, string>>({});
  const [usernameStatus, setUsernameStatus] = useState<'idle' | 'checking' | 'available' | 'taken'>('idle');
  const usernameTimer = useRef<any>(null);

  useEffect(() => {
    setMounted(true);
        if (getToken()) router.push('/feed');
  }, []);

  // Username avtomatik təmizlə + real-time yoxla
  function handleUsername(val: string) {
    const clean = val.toLowerCase().replace(/[^a-z0-9_.]/g, '').slice(0, 30);
    setRegData(d => ({ ...d, username: clean }));
    setUsernameStatus('idle');
    clearTimeout(usernameTimer.current);
    if (clean.length >= 3) {
      setUsernameStatus('checking');
      usernameTimer.current = setTimeout(async () => {
        try {
          const res = await fetch(`${API}/users/${clean}`);
          const data = await res.json();
          setUsernameStatus(data.success ? 'taken' : 'available');
        } catch {
          setUsernameStatus('available');
        }
      }, 600);
    }
  }

  function validateReg() {
    const e: Record<string, string> = {};
    if (!regData.displayName.trim()) e.displayName = 'Ad lazımdır';
    if (!regData.username || regData.username.length < 3) e.username = 'Min 3 simvol';
    else if (usernameStatus === 'taken') e.username = 'Bu istifadəçi adı artıq mövcuddur';
    else if (usernameStatus === 'checking') e.username = 'Yoxlanılır, bir az gözləyin';
    if (!regData.email.includes('@')) e.email = 'Düzgün email daxil edin';
    if (regData.password.length < 8) e.password = 'Min 8 simvol';
    setRegErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleLogin() {
    if (!loginData.email || !loginData.password) return setError('Bütün xanaları doldurun');
    setLoading(true); setError('');
    try {
      const res = await fetch(`${API}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginData),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Giriş uğursuz oldu');
      const _s = data.data || data; saveSession(_s.accessToken, _s.refreshToken, _s.user);
      router.push('/feed');
    } catch (e: any) { setError(e.message); }
    finally { setLoading(false); }
  }

  async function handleRegister() {
    if (!validateReg()) return;
    setLoading(true); setError('');
    try {
      const res = await fetch(`${API}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(regData),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Qeydiyyat uğursuz oldu');
      const _s = data.data || data; saveSession(_s.accessToken, _s.refreshToken, _s.user);
      router.push('/feed');
    } catch (e: any) { setError(e.message); }
    finally { setLoading(false); }
  }

  if (!mounted) return null;

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(160deg, #f8fafc 0%, #eef2ff 50%, #f0fdf4 100%)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: '24px', fontFamily: "-apple-system,'Segoe UI',system-ui,sans-serif",
    }}>
      <style>{`
        * { box-sizing:border-box; margin:0; padding:0; }
        input { font-family:inherit; }
        button { font-family:inherit; }
        @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes shake { 0%,100%{transform:translateX(0)} 20%,60%{transform:translateX(-6px)} 40%,80%{transform:translateX(6px)} }
      `}</style>

      <div style={{ width: '100%', maxWidth: 400, animation: 'fadeUp 0.5s ease' }}>

        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 36 }}>
          <div style={{
            width: 72, height: 72, borderRadius: 22, margin: '0 auto 16px',
            background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 12px 32px rgba(99,102,241,0.35)',
          }}>
            <span style={{ fontSize: 36, fontWeight: 900, color: '#fff', letterSpacing: '-2px' }}>A</span>
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 900, letterSpacing: '-0.8px', color: '#0f172a', marginBottom: 6 }}>Axın</h1>
          <p style={{ fontSize: 14, color: '#64748b' }}>Azərbaycanın sosial şəbəkəsi</p>
        </div>

        {/* Kart */}
        <div style={{ background: '#fff', borderRadius: 24, padding: 28, boxShadow: '0 4px 24px rgba(15,23,42,0.08), 0 1px 4px rgba(15,23,42,0.04)' }}>

          {/* Tab başlığı */}
          <h2 style={{ fontSize: 18, fontWeight: 800, color: '#0f172a', marginBottom: 20, letterSpacing: '-0.4px' }}>
            {tab === 'login' ? 'Xoş gəldiniz 👋' : 'Hesab yarat'}
          </h2>

          {/* Xəta mesajı */}
          {error && (
            <div style={{
              background: '#fff1f2', border: '1px solid #fecdd3', color: '#be123c',
              padding: '12px 14px', borderRadius: 12, fontSize: 13, marginBottom: 18,
              display: 'flex', alignItems: 'center', gap: 8,
              animation: 'shake 0.4s ease',
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
              {error}
            </div>
          )}

          {/* GİRİŞ formu */}
          {tab === 'login' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <Field label="Email" type="email" value={loginData.email}
                onChange={v => setLoginData(d => ({ ...d, email: v }))}
                onEnter={handleLogin} placeholder="email@example.com" />

              <PasswordField label="Şifrə" value={loginData.password} show={showPass}
                onToggle={() => setShowPass(v => !v)}
                onChange={v => setLoginData(d => ({ ...d, password: v }))}
                onEnter={handleLogin} />

              <button onClick={handleLogin} disabled={loading}
                style={{
                  marginTop: 4, padding: '13px', background: loading ? '#c7d2fe' : 'linear-gradient(135deg, #6366f1, #818cf8)',
                  color: '#fff', border: 'none', borderRadius: 14, fontSize: 14, fontWeight: 700,
                  cursor: loading ? 'not-allowed' : 'pointer', transition: 'all 0.2s',
                  boxShadow: loading ? 'none' : '0 6px 16px rgba(99,102,241,0.35)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                }}>
                {loading ? <Spinner /> : null}
                {loading ? 'Giriş edilir...' : 'Daxil ol →'}
              </button>

              <p style={{ textAlign: 'center', fontSize: 13, color: '#64748b', marginTop: 4 }}>
                Hesabınız yoxdur?{' '}
                <button onClick={() => setTab('register')}
                  style={{ background: 'none', border: 'none', color: '#6366f1', fontWeight: 700, cursor: 'pointer', fontSize: 13 }}>
                  Qeydiyyat
                </button>
              </p>
            </div>
          )}

          {/* QEYDİYYAT formu */}
          {tab === 'register' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <Field label="Ad Soyad" type="text" value={regData.displayName}
                onChange={v => setRegData(d => ({ ...d, displayName: v }))}
                placeholder="Emin Əhmədov" error={regErrors.displayName} />

              <div>
                <Field label="İstifadəçi adı" type="text" value={regData.username}
                  onChange={handleUsername}
                  placeholder="emin_az" error={regErrors.username}
                  prefix="@" status={usernameStatus} />
                {regData.username && !regErrors.username && (
                  <p style={{ fontSize: 11, color: '#94a3b8', marginTop: 4, paddingLeft: 4 }}>
                    Profil linkiniz: axin.app/@{regData.username}
                  </p>
                )}
              </div>

              <Field label="Email" type="email" value={regData.email}
                onChange={v => setRegData(d => ({ ...d, email: v }))}
                placeholder="email@example.com" error={regErrors.email} />

              <PasswordField label="Şifrə" value={regData.password} show={showPass}
                onToggle={() => setShowPass(v => !v)}
                onChange={v => setRegData(d => ({ ...d, password: v }))}
                onEnter={handleRegister} error={regErrors.password}
                hint={regData.password ? getStrength(regData.password) : undefined} />

              <button onClick={handleRegister} disabled={loading}
                style={{
                  marginTop: 4, padding: '13px', background: loading ? '#c7d2fe' : 'linear-gradient(135deg, #6366f1, #818cf8)',
                  color: '#fff', border: 'none', borderRadius: 14, fontSize: 14, fontWeight: 700,
                  cursor: loading ? 'not-allowed' : 'pointer', transition: 'all 0.2s',
                  boxShadow: loading ? 'none' : '0 6px 16px rgba(99,102,241,0.35)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                }}>
                {loading ? <Spinner /> : null}
                {loading ? 'Qeydiyyat edilir...' : 'Hesab yarat →'}
              </button>

              <p style={{ textAlign: 'center', fontSize: 12, color: '#94a3b8', lineHeight: 1.5 }}>
                Qeydiyyatdan keçməklə <span style={{ color: '#6366f1' }}>İstifadə Şərtlərini</span> qəbul edirsiniz
              </p>

              <p style={{ textAlign: 'center', fontSize: 13, color: '#64748b' }}>
                Hesabınız var?{' '}
                <button onClick={() => setTab('login')}
                  style={{ background: 'none', border: 'none', color: '#6366f1', fontWeight: 700, cursor: 'pointer', fontSize: 13 }}>
                  Giriş
                </button>
              </p>
            </div>
          )}
        </div>

        {/* Alt yazı */}
        <p style={{ textAlign: 'center', fontSize: 12, color: '#94a3b8', marginTop: 20 }}>
          © 2026 Axın · Azərbaycan
        </p>
      </div>
    </div>
  );
}

// ── Köməkçi komponentlər ────────────────────────────

function Field({ label, type, value, onChange, onEnter, placeholder, error, prefix, status }: {
  label: string; type: string; value: string; onChange: (v: string) => void;
  onEnter?: () => void; placeholder?: string; error?: string; prefix?: string;
  status?: 'idle' | 'checking' | 'available' | 'taken';
}) {
  const [focused, setFocused] = useState(false);
  const hasStatus = status && status !== 'idle';
  const borderColor = error ? '#fca5a5' : status === 'available' ? '#4ade80' : status === 'taken' ? '#fca5a5' : focused ? '#6366f1' : '#e2e8f0';
  const bg = error ? '#fff1f2' : status === 'available' ? '#f0fdf4' : status === 'taken' ? '#fff1f2' : focused ? '#fff' : '#f8fafc';

  return (
    <div>
      <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, letterSpacing: '0.2px' }}>
        {label}
      </label>
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center', background: bg, border: `1.5px solid ${borderColor}`, borderRadius: 12, transition: 'all 0.15s' }}>
        {prefix && <span style={{ paddingLeft: 14, color: '#94a3b8', fontSize: 15, fontWeight: 600, userSelect: 'none' as any }}>{prefix}</span>}
        <input type={type} value={value} onChange={e => onChange(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && onEnter) onEnter(); }}
          onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
          placeholder={placeholder}
          style={{ flex: 1, padding: `12px ${prefix ? '4px' : '14px'} 12px ${prefix ? '4px' : '14px'}`, background: 'transparent', border: 'none', outline: 'none', fontSize: 15, color: '#0f172a' }} />
        {/* Status ikonu */}
        {hasStatus && (
          <div style={{ paddingRight: 12 }}>
            {status === 'checking' && (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.5" strokeLinecap="round" style={{ animation: 'spin 0.8s linear infinite' }}>
                <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
              </svg>
            )}
            {status === 'available' && (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2.5" strokeLinecap="round">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            )}
            {status === 'taken' && (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2.5" strokeLinecap="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            )}
          </div>
        )}
      </div>
      {error && <p style={{ fontSize: 11, color: '#ef4444', marginTop: 4, paddingLeft: 4 }}>{error}</p>}
      {!error && status === 'available' && value && (
        <p style={{ fontSize: 11, color: '#22c55e', marginTop: 4, paddingLeft: 4, fontWeight: 600 }}>✓ Bu istifadəçi adı mövcuddur</p>
      )}
      {!error && status === 'taken' && (
        <p style={{ fontSize: 11, color: '#ef4444', marginTop: 4, paddingLeft: 4 }}>✗ Bu istifadəçi adı artıq tutulub</p>
      )}
    </div>
  );
}

function PasswordField({ label, value, show, onToggle, onChange, onEnter, error, hint }: {
  label: string; value: string; show: boolean; onToggle: () => void;
  onChange: (v: string) => void; onEnter?: () => void; error?: string;
  hint?: { label: string; color: string; width: string };
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div>
      <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6 }}>{label}</label>
      <div style={{ position: 'relative', background: error ? '#fff1f2' : focused ? '#fff' : '#f8fafc', border: `1.5px solid ${error ? '#fca5a5' : focused ? '#6366f1' : '#e2e8f0'}`, borderRadius: 12, transition: 'all 0.15s', display: 'flex', alignItems: 'center' }}>
        <input type={show ? 'text' : 'password'} value={value} onChange={e => onChange(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && onEnter) onEnter(); }}
          onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
          placeholder="••••••••"
          style={{ flex: 1, padding: '12px 14px', background: 'transparent', border: 'none', outline: 'none', fontSize: 15, color: '#0f172a' }} />
        <button type="button" onClick={onToggle}
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '0 14px', color: '#94a3b8', display: 'flex', alignItems: 'center' }}>
          {show
            ? <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
            : <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          }
        </button>
      </div>
      {hint && value && (
        <div style={{ marginTop: 8 }}>
          <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
            {['25%','50%','75%','100%'].map((w, i) => (
              <div key={i} style={{ flex: 1, height: 3, borderRadius: 99, background: parseInt(hint.width) >= parseInt(w) ? hint.color : '#e2e8f0', transition: 'all 0.3s' }} />
            ))}
          </div>
          <p style={{ fontSize: 11, color: hint.color, fontWeight: 600 }}>{hint.label}</p>
        </div>
      )}
      {error && <p style={{ fontSize: 11, color: '#ef4444', marginTop: 4, paddingLeft: 4 }}>{error}</p>}
    </div>
  );
}

function getStrength(p: string): { label: string; color: string; width: string } {
  let s = 0;
  if (p.length >= 8) s++;
  if (/[A-Z]/.test(p)) s++;
  if (/[0-9]/.test(p)) s++;
  if (/[^A-Za-z0-9]/.test(p)) s++;
  const levels = [
    { label: 'Çox zəif', color: '#ef4444', width: '25%' },
    { label: 'Zəif', color: '#f97316', width: '50%' },
    { label: 'Orta', color: '#eab308', width: '75%' },
    { label: 'Güclü 💪', color: '#22c55e', width: '100%' },
  ];
  return levels[Math.min(s - 1, 3)] || levels[0];
}

function Spinner() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"
      style={{ animation: 'spin 0.8s linear infinite' }}>
      <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
    </svg>
  );
}
