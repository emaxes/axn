'use client';
import {
  createContext, useContext, useState,
  useEffect, useRef, useCallback,
} from 'react';
import { useRouter, usePathname } from 'next/navigation';
import {
  restoreSession, logout as doLogout,
  getToken, refreshToken, isExpired,
} from '../lib/auth';

/* ── Types ─────────────────────────────────────────────── */
interface IAuthCtx {
  user: any | null;
  loading: boolean;
  isAuth: boolean;
  logout: () => void;
  setUser: (u: any) => void;
  refreshUser: () => Promise<void>;
}

const AuthCtx = createContext<IAuthCtx>({
  user: null, loading: true, isAuth: false,
  logout: () => {}, setUser: () => {}, refreshUser: async () => {},
});

const PUBLIC_PATHS = new Set(['/', '/login', '/register']);
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';

/* ── Provider ───────────────────────────────────────────── */
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUserState] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  const router   = useRouter();
  const pathname = usePathname();

  // Refs — no re-render triggers
  const initialized    = useRef(false);   // prevent double-init (StrictMode)
  const refreshTimer   = useRef<ReturnType<typeof setTimeout>>();
  const lastPathname   = useRef(pathname);
  const navigating     = useRef(false);   // prevent concurrent navigations
  const userRef        = useRef<any>(null); // stable ref to current user

  // Keep userRef in sync without causing render
  userRef.current = user;

  // ── Silent token refresh scheduler ──────────────────────
  const scheduleRefresh = useCallback(() => {
    clearTimeout(refreshTimer.current);
    const exp = localStorage.getItem('axin_exp');
    if (!exp) return;
    // Schedule 2 min before expiry
    const delay = Number(exp) - Date.now() - 120_000;
    if (delay < 0) {
      // Already near expiry — refresh now, no setState
      refreshToken().then(t => { if (t) scheduleRefresh(); else silentLogout(); });
      return;
    }
    refreshTimer.current = setTimeout(() => {
      refreshToken().then(t => { if (t) scheduleRefresh(); else silentLogout(); });
    }, Math.min(delay, 2_147_483_647)); // setTimeout max int
  }, []); // stable — no deps

  // ── Navigate once (prevent loops) ───────────────────────
  const navigateTo = useCallback((path: string) => {
    if (navigating.current || pathname === path) return;
    navigating.current = true;
    router.replace(path);
    // Reset after navigation settles
    setTimeout(() => { navigating.current = false; }, 500);
  }, [pathname, router]);

  // ── Logout (no re-render loop) ───────────────────────────
  const silentLogout = useCallback(() => {
    clearTimeout(refreshTimer.current);
    doLogout(); // clears localStorage, dispatches event
    setUserState(null);
  }, []);

  const logout = useCallback(() => {
    silentLogout();
    navigateTo('/');
  }, [silentLogout, navigateTo]);

  const setUser = useCallback((u: any) => {
    setUserState(u);
    if (u) localStorage.setItem('axin_user', JSON.stringify(u)); if (u?.username) localStorage.setItem('axin_username', u.username);
  }, []);

  const refreshUser = useCallback(async () => {
    const token = getToken();
    if (!token) return;
    try {
      const res = await fetch(`${API}/auth/me`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const d = await res.json();
        const fresh = d.data || d.user || d;
        if (fresh?.id) setUser(fresh);
      }
    } catch {}
  }, [setUser]);

  // ── ONE-TIME init — restore session ─────────────────────
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    restoreSession().then(restored => {
      if (restored) {
        setUserState(restored);
        scheduleRefresh();
        // If on public page after login, go to feed
        if (PUBLIC_PATHS.has(pathname)) navigateTo('/feed');
      } else {
        // No valid session
        if (!PUBLIC_PATHS.has(pathname)) navigateTo('/');
      }
    }).catch(() => {
      if (!PUBLIC_PATHS.has(pathname)) navigateTo('/');
    }).finally(() => {
      setLoading(false);
    });

    // Cleanup
    return () => { clearTimeout(refreshTimer.current); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  // ^ Empty deps — intentional, runs once only

  // ── Route-change protection (without re-render loop) ─────
  useEffect(() => {
    // Only run when pathname actually changed
    if (pathname === lastPathname.current) return;
    lastPathname.current = pathname;

    if (loading) return; // wait for init

    const isPublic = PUBLIC_PATHS.has(pathname);
    const loggedIn = !!userRef.current;

    if (!loggedIn && !isPublic) navigateTo('/');
    else if (loggedIn && pathname === '/') navigateTo('/feed');
  }, [pathname, loading, navigateTo]);
  // ^ Only pathname + loading trigger this, not user object

  // ── Global logout event ──────────────────────────────────
  useEffect(() => {
    const fn = () => { clearTimeout(refreshTimer.current); setUserState(null); };
    window.addEventListener('axin:logout', fn);
    return () => window.removeEventListener('axin:logout', fn);
  }, []);

  // ── Visibility change — validate token when tab focuses ──
  useEffect(() => {
    let checking = false;
    const fn = async () => {
      if (document.visibilityState !== 'visible') return;
      if (!getToken() || checking) return;
      if (!isExpired()) return; // still valid, skip
      checking = true;
      try {
        const t = await refreshToken();
        if (t) scheduleRefresh();
        else silentLogout();
      } finally { checking = false; }
    };
    document.addEventListener('visibilitychange', fn);
    return () => document.removeEventListener('visibilitychange', fn);
  }, [scheduleRefresh, silentLogout]);

  // ── Render ───────────────────────────────────────────────
  const ctx: IAuthCtx = {
    user, loading, isAuth: !!user,
    logout, setUser, refreshUser,
  };

  return (
    <AuthCtx.Provider value={ctx}>
      {loading ? <Splash /> : children}
    </AuthCtx.Provider>
  );
}

/* ── Splash screen ─────────────────────────────────────── */
function Splash() {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: '#fff',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      zIndex: 9999,
    }}>
      <div style={{
        width: 60, height: 60, borderRadius: 18,
        background: 'linear-gradient(135deg,#6366f1,#8b5cf6)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: '0 8px 32px rgba(99,102,241,.35)',
        marginBottom: 24,
      }}>
        <svg width="30" height="30" viewBox="0 0 24 24" fill="#fff">
          <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
        </svg>
      </div>
      <div style={{ display: 'flex', gap: 6 }}>
        {[0, 1, 2].map(i => (
          <div key={i} style={{
            width: 7, height: 7, borderRadius: '50%',
            background: '#6366f1',
            animation: `sp 1.1s ${i * .18}s ease-in-out infinite`,
          }} />
        ))}
      </div>
      <style>{`
        @keyframes sp {
          0%,100% { opacity:.25; transform:scale(.6); }
          50%      { opacity:1;   transform:scale(1);  }
        }
      `}</style>
    </div>
  );
}

export const useAuth = () => useContext(AuthCtx);
