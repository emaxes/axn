'use client';
import { getToken, apiFetch } from '../../lib/auth';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';

const API = 'http://localhost:3001/api/v1';

export default function Settings() {
  const router = useRouter();
  const [form, setForm] = useState({ displayName: '', bio: '', website: '', city: '' });
  const [avatar, setAvatar] = useState('');
  const [loading, setLoading] = useState(false);
  const [avatarLoading, setAvatarLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
        if (!getToken()) { router.push('/'); return; }
    apiFetch(`${API}/auth/me`)
      .then(r => r.json())
      .then(d => {
        if (d.success) {
          setForm({
            displayName: d.data.displayName || '',
            bio: d.data.bio || '',
            website: d.data.website || '',
            city: d.data.city || '',
          });
          setAvatar(d.data.avatarUrl || '');
        }
      });
  }, []);

  async function uploadAvatar(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setAvatarLoading(true);
    setError('');
    
    // Şəkil sıxma
    const compressed = await new Promise<Blob>(resolve => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        const size = 400;
        const canvas = document.createElement('canvas');
        canvas.width = size; canvas.height = size;
        const ctx = canvas.getContext('2d')!;
        const min = Math.min(img.width, img.height);
        const sx = (img.width - min) / 2;
        const sy = (img.height - min) / 2;
        ctx.drawImage(img, sx, sy, min, min, 0, 0, size, size);
        URL.revokeObjectURL(url);
        canvas.toBlob(b => resolve(b!), 'image/jpeg', 0.85);
      };
      img.src = url;
    });

    const fd = new FormData();
    fd.append('file', new File([compressed], 'avatar.jpg', { type: 'image/jpeg' }));

    try {
      const r = await apiFetch(`${API}/storage/upload`, { method: 'POST',
        body: fd });
      const t = await r.text();
      let d: any = {};
      try { d = JSON.parse(t); } catch {}
      const url = d?.data?.data?.url || d?.data?.url || d?.url || null;

      if (url) {
        // Profili yenilə
        const res = await apiFetch(`${API}/users/me`, { method: 'PATCH',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` },
          body: JSON.stringify({ avatarUrl: url }),
        });
        const data = await res.json();
        if (data.success) { setAvatar(url); setSuccess('Profil şəkli yeniləndi! ✅'); }
        else setError('Şəkil saxlanmadı');
      } else {
        setError('Yükləmə xətası');
      }
    } catch {
      setError('Şəbəkə xətası');
    }
    setAvatarLoading(false);
    e.target.value = '';
  }

  async function save() {
    setLoading(true); setError(''); setSuccess('');
        const res = await apiFetch(`${API}/users/me`, { method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` },
      body: JSON.stringify(form) });
    const data = await res.json();
    if (data.success) setSuccess('Profil yeniləndi! ✅');
    else setError(data.message || 'Xəta baş verdi');
    setLoading(false);
  }

  const PAL: [string,string][] = [['#6366f1','#a5b4fc'],['#ec4899','#fbcfe8'],['#10b981','#a7f3d0'],['#f59e0b','#fde68a']];
  const grad = (n='A') => { const [a,b]=PAL[n.charCodeAt(0)%PAL.length]; return `linear-gradient(135deg,${a},${b})`; };

  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: "-apple-system,'Segoe UI',system-ui,sans-serif" }}>
      {/* Header */}
      <div style={{ position: 'sticky', top: 0, zIndex: 50, background: '#fff', borderBottom: '1px solid #f1f5f9', padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 14 }}>
        <button onClick={() => router.back()} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', color: '#0f172a' }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <span style={{ fontSize: 17, fontWeight: 800, color: '#0f172a' }}>Profili redaktə et</span>
        <button onClick={save} disabled={loading}
          style={{ marginLeft: 'auto', background: 'linear-gradient(135deg,#6366f1,#818cf8)', border: 'none', borderRadius: 99, padding: '8px 20px', fontSize: 13, fontWeight: 700, color: '#fff', cursor: 'pointer', opacity: loading ? 0.7 : 1 }}>
          {loading ? '...' : 'Saxla'}
        </button>
      </div>

      <div style={{ maxWidth: 500, margin: '0 auto', padding: '20px 20px 100px' }}>
        {error && <div style={{ background: '#fef2f2', border: '1px solid #fecaca', color: '#dc2626', padding: '12px 16px', borderRadius: 12, marginBottom: 16, fontSize: 14 }}>{error}</div>}
        {success && <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#16a34a', padding: '12px 16px', borderRadius: 12, marginBottom: 16, fontSize: 14 }}>{success}</div>}

        {/* Avatar */}
        <div style={{ background: '#fff', borderRadius: 20, padding: '24px 20px', marginBottom: 12, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, boxShadow: '0 1px 3px rgba(15,23,42,0.06)' }}>
          {/* Avatar dairəsi */}
          <div style={{ position: 'relative', cursor: 'pointer' }} onClick={() => fileRef.current?.click()}>
            <div style={{ width: 100, height: 100, borderRadius: '50%', overflow: 'hidden', background: grad(form.displayName || 'A'), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 38, fontWeight: 700, color: '#fff' }}>
              {avatar
                ? <img src={avatar} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : (form.displayName || 'A')[0]?.toUpperCase()
              }
            </div>
            {/* Redaktə ikonu */}
            <div style={{ position: 'absolute', bottom: 0, right: 0, width: 30, height: 30, borderRadius: '50%', background: '#6366f1', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '3px solid #fff' }}>
              {avatarLoading
                ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" style={{ animation: 'spin 0.8s linear infinite' }}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                : <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
              }
            </div>
          </div>
          <button onClick={() => fileRef.current?.click()}
            style={{ background: 'none', border: '1.5px solid #e2e8f0', borderRadius: 99, padding: '8px 20px', fontSize: 13, fontWeight: 700, cursor: 'pointer', color: '#6366f1', fontFamily: 'inherit' }}>
            Profil şəklini dəyiş
          </button>
          <input ref={fileRef} type="file" accept="image/*" onChange={uploadAvatar} style={{ display: 'none' }} />
          <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
        </div>

        {/* Form */}
        <div style={{ background: '#fff', borderRadius: 20, overflow: 'hidden', boxShadow: '0 1px 3px rgba(15,23,42,0.06)' }}>
          {[
            { key: 'displayName', label: 'Ad Soyad', placeholder: 'Adınızı yazın', max: 50 },
            { key: 'bio', label: 'Bio', placeholder: 'Özünüz haqqında...', max: 160, multiline: true },
            { key: 'website', label: 'Vebsayt', placeholder: 'https://...', max: 100 },
            { key: 'city', label: 'Şəhər', placeholder: 'Bakı, Azərbaycan', max: 50 },
          ].map((field, i) => (
            <div key={field.key} style={{ padding: '14px 20px', borderBottom: i < 3 ? '1px solid #f8fafc' : 'none' }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: '#94a3b8', letterSpacing: '0.5px', display: 'block', marginBottom: 6 }}>
                {field.label.toUpperCase()}
              </label>
              {field.multiline ? (
                <textarea value={(form as any)[field.key]}
                  onChange={e => setForm({ ...form, [field.key]: e.target.value })}
                  maxLength={field.max} rows={3} placeholder={field.placeholder}
                  style={{ width: '100%', background: 'transparent', border: 'none', outline: 'none', fontSize: 15, color: '#0f172a', fontFamily: 'inherit', resize: 'none', lineHeight: 1.6 }}
                />
              ) : (
                <input type="text" value={(form as any)[field.key]}
                  onChange={e => setForm({ ...form, [field.key]: e.target.value })}
                  maxLength={field.max} placeholder={field.placeholder}
                  style={{ width: '100%', background: 'transparent', border: 'none', outline: 'none', fontSize: 15, color: '#0f172a', fontFamily: 'inherit' }}
                />
              )}
            </div>
          ))}
        </div>

        {/* Çıxış */}
        <button onClick={() => { localStorage.clear(); router.push('/'); }}
          style={{ width: '100%', marginTop: 16, background: '#fff', border: '1.5px solid #fecaca', borderRadius: 14, padding: '14px', fontSize: 14, fontWeight: 700, cursor: 'pointer', color: '#dc2626', fontFamily: 'inherit' }}>
          Çıxış
        </button>
      </div>
    </div>
  );
}
