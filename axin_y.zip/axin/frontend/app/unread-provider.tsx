'use client';
import { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { getToken, apiFetch } from '../lib/auth';

const API = 'http://localhost:3001/api/v1';

interface UnreadCtxType {
  unread: number;
  unreadMsg: number;
  refresh: () => void;
  clearNotifBadge: () => void;
}

const UnreadCtx = createContext<UnreadCtxType>({
  unread: 0, unreadMsg: 0, refresh: () => {}, clearNotifBadge: () => {},
});

export function UnreadProvider({ children }: { children: React.ReactNode }) {
  const [unread,    setUnread]    = useState(0);
  const [unreadMsg, setUnreadMsg] = useState(0);
  const timerRef  = useRef<ReturnType<typeof setInterval>>();
  const fetchingRef = useRef(false); // prevent concurrent polls

  const refresh = useCallback(async () => {
    if (!getToken()) return;
    if (fetchingRef.current) return; // skip if already fetching
    fetchingRef.current = true;

    try {
      const [notifRes, msgRes] = await Promise.allSettled([
        apiFetch(`${API}/notifications/unread`),
        apiFetch(`${API}/messages/unread`),
      ]);

      if (notifRes.status === 'fulfilled') {
        const d = await notifRes.value.json().catch(() => null);
        if (d?.success) setUnread(d.data?.count ?? 0);
      }
      if (msgRes.status === 'fulfilled') {
        const d = await msgRes.value.json().catch(() => null);
        if (d?.success) {
          const cnt = typeof d.data === 'number' ? d.data : (d.data?.count ?? 0);
          setUnreadMsg(cnt);
        }
      }
    } catch {}
    finally { fetchingRef.current = false; }
  }, []);

  // Clear notification badge instantly (called after opening notifications page)
  const clearNotifBadge = useCallback(() => setUnread(0), []);

  useEffect(() => {
    refresh();
    // Poll every 20s (reduced from 15s — less aggressive)
    timerRef.current = setInterval(refresh, 20_000);
    return () => clearInterval(timerRef.current);
  }, [refresh]);

  // Pause polling when tab hidden (saves battery/resources)
  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible') {
        refresh();
        timerRef.current = setInterval(refresh, 20_000);
      } else {
        clearInterval(timerRef.current);
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [refresh]);

  return (
    <UnreadCtx.Provider value={{ unread, unreadMsg, refresh, clearNotifBadge }}>
      {children}
    </UnreadCtx.Provider>
  );
}

export function useUnread() { return useContext(UnreadCtx); }
