'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { getToken, apiFetch } from '../../lib/auth';
import { useUnread } from '../unread-provider';

const API = 'http://localhost:3001/api/v1';

/* ── Types ────────────────────────────────────────────────── */
type NType = 'like'|'follow'|'follow_request'|'follow_accept'|'reply'|'comment'|'mention'|'unknown';

interface Notif {
  id: string;
  type: NType;
  isRead: boolean;
  createdAt: string;
  fromUser: { id: string; username: string; avatarUrl?: string };
  postId?: string;
  commentId?: string;
  extra?: { postId?: string; commentId?: string };
  post?: { mediaUrls?: string[] };
}

interface FReq {
  id: string;
  username: string;
  avatarUrl?: string;
  followerCount?: number;
}

/* ── Helpers ──────────────────────────────────────────────── */
const GRAD = ['from-violet-500 to-purple-600','from-pink-500 to-rose-500',
              'from-amber-400 to-orange-500','from-emerald-500 to-teal-500',
              'from-blue-500 to-indigo-500'];
const avatarGrad = (n='A') => GRAD[n.charCodeAt(0) % GRAD.length];

function timeAgo(iso: string) {
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60)     return 'indi';
  if (s < 3600)   return `${~~(s/60)}dəq`;
  if (s < 86400)  return `${~~(s/3600)}s`;
  if (s < 604800) return `${~~(s/86400)}g`;
  return new Date(iso).toLocaleDateString('az');
}

function groupBy(iso: string) {
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 86400)   return 'Bugün';
  if (s < 604800)  return 'Bu həftə';
  if (s < 2592000) return 'Bu ay';
  return 'Əvvəllər';
}

const COPY: Record<NType, string> = {
  like:           'paylaşımını bəyəndi',
  follow:         'sizi izləməyə başladı',
  follow_request: 'izlə istəyi göndərdi',
  follow_accept:  'izlə sorğunuzu qəbul etdi',
  reply:          'şərhinizə cavab yazdı',
  comment:        'paylaşıma şərh yazdı',
  mention:        'sizi qeyd etdi',
  unknown:        'bildiriş göndərdi',
};

const ICON: Record<NType, JSX.Element> = {
  like:           <svg className="w-3 h-3" viewBox="0 0 24 24" fill="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>,
  follow:         <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  follow_request: <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/><line x1="18" y1="11" x2="18" y2="17"/><line x1="15" y1="14" x2="21" y2="14"/></svg>,
  follow_accept:  <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>,
  reply:          <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
  comment:        <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
  mention:        <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"/></svg>,
  unknown:        <svg className="w-3 h-3" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="4"/></svg>,
};

const BADGE_CLS: Record<NType, string> = {
  like:           'bg-rose-500',
  follow:         'bg-indigo-500',
  follow_request: 'bg-indigo-500',
  follow_accept:  'bg-emerald-500',
  reply:          'bg-teal-500',
  comment:        'bg-teal-500',
  mention:        'bg-amber-500',
  unknown:        'bg-slate-400',
};

function getRoute(n: Notif): string | null {
  const postId    = n.postId    ?? n.extra?.postId;
  const commentId = n.commentId ?? n.extra?.commentId;
  switch (n.type) {
    case 'follow':
    case 'follow_request':
    case 'follow_accept':
      return n.fromUser?.username ? `/profile/${n.fromUser.username}` : null;
    case 'mention':
      if (postId && commentId) return `/post/${postId}?comment=${commentId}`;
      return postId ? `/post/${postId}` : null;
    default:
      return postId ? `/post/${postId}` : null;
  }
}

/* ── Avatar ───────────────────────────────────────────────── */
function Avatar({ src, name, size = 'md' }: { src?: string; name: string; size?: 'sm'|'md' }) {
  const dim = size === 'sm' ? 'w-10 h-10 text-base' : 'w-11 h-11 text-lg';
  return (
    <div className={`${dim} rounded-full flex-shrink-0 overflow-hidden flex items-center justify-center font-bold text-white bg-gradient-to-br ${avatarGrad(name)}`}>
      {src ? <img src={src} className="w-full h-full object-cover" alt={name} /> : name[0]?.toUpperCase()}
    </div>
  );
}

/* ── Follow-back (self-contained state) ──────────────────── */
function FollowBackBtn({ username }: { username: string }) {
  const [st, setSt] = useState<'idle'|'busy'|'done'>('idle');
  async function handle(e: React.MouseEvent) {
    e.stopPropagation();
    if (st !== 'idle') return;
    setSt('busy');
    const res = await apiFetch(`${API}/users/${username}/follow`, { method: 'POST' }).catch(() => null);
    setSt(res?.ok ? 'done' : 'idle');
  }
  if (st === 'done') return <span className="text-xs font-bold text-emerald-600 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-1.5 whitespace-nowrap">İzlənilir ✓</span>;
  return (
    <button onClick={handle} disabled={st === 'busy'}
      className={`text-xs font-bold rounded-lg px-3 py-1.5 whitespace-nowrap transition-all ${st === 'busy' ? 'bg-slate-200 text-slate-400 cursor-wait' : 'bg-slate-900 text-white hover:bg-slate-700 active:scale-95'}`}>
      {st === 'busy' ? '...' : 'Geri izlə'}
    </button>
  );
}

/* ── Skeleton ─────────────────────────────────────────────── */
function SkeletonRow() {
  return (
    <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-100">
      <div className="w-11 h-11 rounded-full bg-slate-200 animate-pulse flex-shrink-0" />
      <div className="flex-1 space-y-2">
        <div className="h-3 bg-slate-200 rounded-full w-2/3 animate-pulse" />
        <div className="h-2.5 bg-slate-100 rounded-full w-1/3 animate-pulse" />
      </div>
    </div>
  );
}

/* ── Notification Item ───────────────────────────────────── */
function NotificationItem({ n, onClick }: { n: Notif; onClick: (n: Notif) => void }) {
  const type  = (n.type ?? 'unknown') as NType;
  const thumb = n.post?.mediaUrls?.[0];
  return (
    <div
      onClick={() => onClick(n)}
      className={`flex items-center gap-3 px-4 py-3 border-b border-slate-100 cursor-pointer transition-colors relative ${n.isRead ? 'bg-white hover:bg-slate-50' : 'bg-indigo-50/40 hover:bg-indigo-50/70'}`}>

      {/* Unread indicator */}
      {!n.isRead && <div className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-indigo-500" />}

      {/* Avatar + badge */}
      <div className="relative flex-shrink-0">
        <Avatar src={n.fromUser?.avatarUrl} name={n.fromUser?.username ?? 'U'} />
        <span className={`absolute -bottom-0.5 -right-0.5 w-5 h-5 ${BADGE_CLS[type]} rounded-full border-2 border-white flex items-center justify-center text-white`}>
          {ICON[type]}
        </span>
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <p className="text-sm text-slate-800 leading-snug">
          <span className="font-bold">{n.fromUser?.username}</span>
          {' '}
          <span className="text-slate-500">{COPY[type]}</span>
        </p>
        <p className="text-xs text-slate-400 mt-0.5">{timeAgo(n.createdAt)}</p>
      </div>

      {/* Post thumbnail */}
      {thumb && (
        <div className="w-11 h-11 rounded-lg overflow-hidden flex-shrink-0 border border-slate-100">
          <img src={thumb} className="w-full h-full object-cover" alt="" />
        </div>
      )}

      {/* CTA — stopPropagation inside FollowBackBtn */}
      {type === 'follow' && n.fromUser?.username && (
        <div onClick={e => e.stopPropagation()}>
          <FollowBackBtn username={n.fromUser.username} />
        </div>
      )}
      {type === 'follow_accept' && (
        <span className="text-xs font-bold text-emerald-600 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-1.5 whitespace-nowrap flex-shrink-0">
          Qarşılıqlı ✓
        </span>
      )}
    </div>
  );
}

/* ── Notification List ───────────────────────────────────── */
function NotificationList({ items, onClickItem }: { items: Notif[]; onClickItem: (n: Notif) => void }) {
  const groups: Record<string, Notif[]> = {};
  items.forEach(n => {
    const g = groupBy(n.createdAt);
    (groups[g] ??= []).push(n);
  });
  const ORDER = ['Bugün', 'Bu həftə', 'Bu ay', 'Əvvəllər'];

  return (
    <>
      {ORDER.filter(g => groups[g]?.length).map(g => (
        <div key={g}>
          <div className="px-4 py-2 text-[10px] font-bold tracking-widest uppercase text-slate-400 bg-slate-50 border-b border-slate-100">
            {g}
          </div>
          {groups[g].map(n => <NotificationItem key={n.id} n={n} onClick={onClickItem} />)}
        </div>
      ))}
    </>
  );
}

/* ── Follow Request Card ─────────────────────────────────── */
function RequestCard({ req, onRespond }: { req: FReq; onRespond: (u: string, a: boolean) => void }) {
  const router = useRouter();
  return (
    <div className="flex items-center gap-3 px-4 py-3 border-t border-slate-100">
      <div className="cursor-pointer" onClick={() => router.push(`/profile/${req.username}`)}>
        <Avatar src={req.avatarUrl} name={req.username} size="sm" />
      </div>
      <div className="flex-1 min-w-0 cursor-pointer" onClick={() => router.push(`/profile/${req.username}`)}>
        <p className="text-sm font-bold text-slate-900 truncate">{req.username}</p>
        {req.followerCount != null && (
          <p className="text-xs text-slate-400">{req.followerCount.toLocaleString()} izləyici</p>
        )}
      </div>
      <div className="flex gap-2 flex-shrink-0">
        <button onClick={() => onRespond(req.username, true)}
          className="text-xs font-bold bg-slate-900 text-white rounded-lg px-3.5 py-1.5 hover:bg-slate-700 transition-colors active:scale-95">
          Qəbul
        </button>
        <button onClick={() => onRespond(req.username, false)}
          className="text-xs font-bold bg-slate-100 text-slate-600 rounded-lg px-3 py-1.5 hover:bg-slate-200 transition-colors">
          Rədd
        </button>
      </div>
    </div>
  );
}

/* ── Page ─────────────────────────────────────────────────── */
export default function NotificationsPage() {
  const router = useRouter();
  const { refresh: refreshUnread, clearNotifBadge } = useUnread() as any;

  const [notifs,   setNotifs]   = useState<Notif[]>([]);
  const [requests, setRequests] = useState<FReq[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [tab,      setTab]      = useState<'all'|'unread'>('all');
  const didMark = useRef(false);

  const load = useCallback(async () => {
    if (!getToken()) { router.replace('/'); return; }
    try {
      const [nr, rr] = await Promise.all([
        apiFetch(`${API}/notifications`),
        apiFetch(`${API}/users/requests`),
      ]);
      const [nd, rd] = await Promise.all([nr.json(), rr.json()]);
      if (nd.success) setNotifs(nd.data ?? []);
      if (rd.success) setRequests(rd.data ?? []);
    } catch {}
    setLoading(false);
    if (!didMark.current) {
      didMark.current = true;
      apiFetch(`${API}/notifications/read`, { method: 'POST' })
        .then(() => { clearNotifBadge?.(); refreshUnread?.(); })
        .catch(() => {});
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { load(); }, [load]);

  function handleClick(n: Notif) {
    setNotifs(p => p.map(x => x.id === n.id ? { ...x, isRead: true } : x));
    apiFetch(`${API}/notifications/${n.id}/read`, { method: 'POST' }).catch(() => {});
    const route = getRoute(n);
    if (route) router.push(route);
  }

  async function handleRequest(username: string, accept: boolean) {
    setRequests(p => p.filter(r => r.username !== username));
    const ep = accept ? 'accept' : 'reject';
    await apiFetch(`${API}/users/requests/${username}/${ep}`, { method: 'POST' }).catch(() => {});
  }

  async function markAllRead() {
    setNotifs(p => p.map(n => ({ ...n, isRead: true })));
    await apiFetch(`${API}/notifications/read`, { method: 'POST' }).catch(() => {});
    clearNotifBadge?.();
  }

  const displayed  = tab === 'unread' ? notifs.filter(n => !n.isRead) : notifs;
  const unreadCnt  = notifs.filter(n => !n.isRead).length;

  return (
    <div className="min-h-screen bg-slate-50 pb-24 font-sans">

      {/* ── Sticky header ── */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-slate-200">
        <div className="flex items-center justify-between px-4 pt-4 pb-0">
          <h1 className="text-xl font-extrabold text-slate-900">Bildirişlər</h1>
          {unreadCnt > 0 && (
            <button onClick={markAllRead}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors">
              Hamısını oxu
            </button>
          )}
        </div>

        {/* Tabs */}
        <div className="flex mt-3">
          {(['all','unread'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-1 pb-3 text-sm font-bold border-b-2 transition-all ${tab === t ? 'text-indigo-600 border-indigo-600' : 'text-slate-400 border-transparent hover:text-slate-600'}`}>
              {t === 'all' ? 'Hamısı' : `Oxunmamış${unreadCnt > 0 ? ` · ${unreadCnt}` : ''}`}
            </button>
          ))}
        </div>
      </div>

      {/* ── Follow Requests ── */}
      {requests.length > 0 && (
        <div className="bg-white border-b-8 border-slate-100 mb-2">
          <div className="flex items-center gap-2 px-4 pt-4 pb-2">
            <span className="text-base font-extrabold text-slate-900">Təqib İstəkləri</span>
            <span className="text-xs font-bold text-indigo-600 bg-indigo-50 rounded-full px-2 py-0.5">{requests.length}</span>
          </div>
          {requests.map(r => <RequestCard key={r.id} req={r} onRespond={handleRequest} />)}
        </div>
      )}

      {/* ── Notifications ── */}
      <div className="bg-white rounded-none">
        {loading ? (
          <>{[...Array(6)].map((_, i) => <SkeletonRow key={i} />)}</>
        ) : displayed.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 gap-4 px-8 text-center">
            <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center text-4xl">
              🔔
            </div>
            <div>
              <p className="font-bold text-lg text-slate-700 mb-1">
                {tab === 'unread' ? 'Oxunmamış bildiriş yoxdur' : 'Bildiriş yoxdur'}
              </p>
              <p className="text-sm text-slate-400">
                {tab === 'unread' ? 'Bütün bildirişlər oxunub' : 'Yeni bildirişlər burada görünəcək'}
              </p>
            </div>
            {tab === 'unread' && (
              <button onClick={() => setTab('all')}
                className="mt-2 bg-slate-900 text-white text-sm font-bold rounded-xl px-6 py-2.5 hover:bg-slate-700 transition-colors active:scale-95">
                Hamısına bax
              </button>
            )}
          </div>
        ) : (
          <NotificationList items={displayed} onClickItem={handleClick} />
        )}
      </div>
    </div>
  );
}
