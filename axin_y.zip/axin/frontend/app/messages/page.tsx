'use client';
import { getToken, apiFetch } from '../../lib/auth';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

const API = 'http://localhost:3001/api/v1';
const WS  = 'http://localhost:3001';

const PAL: [string, string][] = [
  ['#6366f1','#a5b4fc'],['#ec4899','#fbcfe8'],
  ['#10b981','#a7f3d0'],['#f59e0b','#fde68a'],
  ['#3b82f6','#bfdbfe'],['#8b5cf6','#ddd6fe'],
];
const grad = (name = 'A') => {
  const [a, b] = PAL[name.charCodeAt(0) % PAL.length];
  return `linear-gradient(135deg, ${a}, ${b})`;
};

function Avatar({ name, url, size, online }: { name: string; url?: string; size: number; online?: boolean }) {
  return (
    <div style={{ position: 'relative', flexShrink: 0 }}>
      <div style={{ width: size, height: size, borderRadius: '50%', overflow: 'hidden', background: grad(name), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size * 0.38, fontWeight: 700, color: '#fff' }}>
        {url ? <img src={url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : name?.[0]?.toUpperCase()}
      </div>
      {online && <div style={{ position: 'absolute', bottom: 1, right: 1, width: 11, height: 11, borderRadius: '50%', background: '#10b981', border: '2px solid #fff' }} />}
    </div>
  );
}

function timeAgo(iso: string) {
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60)    return 'İndi';
  if (s < 3600)  return `${~~(s / 60)} dəq`;
  if (s < 86400) return `${~~(s / 3600)} saat`;
  if (s < 604800)return `${~~(s / 86400)} gün`;
  return new Date(iso).toLocaleDateString('az-AZ', { day: 'numeric', month: 'short' });
}

export default function Messages() {
  const router = useRouter();
  const [inbox, setInbox] = useState<any[]>([]);
  const [me, setMe] = useState<any>(null);
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState('');

  useEffect(() => {
        if (!getToken()) { router.push('/'); return; }

    apiFetch(`${API}/auth/me`)
      .then(r => r.json()).then(d => { if (d.success) setMe(d.data); });

    apiFetch(`${API}/messages/inbox`)
      .then(r => r.json()).then(d => { if (d.success) setInbox(d.data || []); });

    // WebSocket — online status + yeni mesaj
    let socket: any = null;
    import('socket.io-client').then(({ io }) => {
      socket = io(`${WS}/messages`, { auth: { token: getToken() }, transports: ['websocket'] });

      socket.on('user_online', ({ userId }: any) => {
        setOnlineUsers(prev => new Set([...prev, userId]));
      });
      socket.on('user_offline', ({ userId }: any) => {
        setOnlineUsers(prev => { const s = new Set(prev); s.delete(userId); return s; });
      });
      socket.on('new_message', (msg: any) => {
        setInbox(prev => {
          const other = msg.fromId === me?.id ? msg.to : msg.from;
          const exists = prev.find(m => {
            const o = m.fromId === me?.id ? m.to : m.from;
            return o?.id === other?.id;
          });
          if (exists) {
            return [{ ...msg }, ...prev.filter(m => m.id !== exists.id)];
          }
          return [msg, ...prev];
        });
      });
    }).catch(() => {});

    return () => { if (socket) socket.disconnect(); };
  }, [me?.id]);

  function getOther(msg: any) {
    return msg.fromId === me?.id ? msg.to : msg.from;
  }

  const filtered = inbox.filter(msg => {
    if (!search) return true;
    const other = getOther(msg);
    return (
      other?.username?.toLowerCase().includes(search.toLowerCase()) ||
      other?.displayName?.toLowerCase().includes(search.toLowerCase()) ||
      msg.content?.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: "-apple-system,'Segoe UI',system-ui,sans-serif", display: 'flex', justifyContent: 'center' }}>
      <style>{`* { box-sizing:border-box; margin:0; padding:0; } body{background:#f8fafc;} button{font-family:inherit;} input{font-family:inherit;}`}</style>

      <div style={{ width: '100%', maxWidth: 500, paddingBottom: 100 }}>

        {/* Header */}
        <header style={{ position: 'sticky', top: 0, zIndex: 50, background: 'rgba(248,250,252,0.95)', backdropFilter: 'blur(12px)', padding: '14px 16px 10px', borderBottom: '1px solid #f1f5f9' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <span style={{ fontSize: 20, fontWeight: 800, color: '#0f172a', letterSpacing: '-0.5px' }}>Mesajlar</span>
            <button onClick={() => router.push('/search')}
              style={{ background: 'linear-gradient(135deg, #6366f1, #818cf8)', border: 'none', borderRadius: 99, padding: '7px 14px', fontSize: 12, fontWeight: 700, color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, boxShadow: '0 4px 12px rgba(99,102,241,0.25)' }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              Yeni mesaj
            </button>
          </div>
          {/* Axtarış */}
          <div style={{ position: 'relative' }}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.5" strokeLinecap="round" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }}>
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
            <input type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Söhbət axtar..."
              style={{ width: '100%', background: '#fff', border: '1.5px solid #e2e8f0', borderRadius: 12, padding: '10px 12px 10px 36px', fontSize: 14, color: '#0f172a', outline: 'none' }}
              onFocus={e => (e.currentTarget.style.borderColor = '#6366f1')}
              onBlur={e => (e.currentTarget.style.borderColor = '#e2e8f0')} />
          </div>
        </header>

        {/* Boş vəziyyət */}
        {inbox.length === 0 && (
          <div style={{ textAlign: 'center', padding: '80px 20px', color: '#94a3b8' }}>
            <div style={{ fontSize: 52, marginBottom: 14 }}>💬</div>
            <div style={{ fontSize: 16, fontWeight: 600, color: '#475569', marginBottom: 6 }}>Hələ mesaj yoxdur</div>
            <div style={{ fontSize: 14, marginBottom: 20 }}>Kiminsə profilinə gir, Mesaj düyməsinə bas</div>
            <button onClick={() => router.push('/search')}
              style={{ background: 'linear-gradient(135deg, #6366f1, #818cf8)', color: '#fff', border: 'none', borderRadius: 99, padding: '10px 24px', fontSize: 14, fontWeight: 700, cursor: 'pointer', boxShadow: '0 4px 14px rgba(99,102,241,0.3)' }}>
              İstifadəçi axtar
            </button>
          </div>
        )}

        {/* Söhbət siyahısı */}
        {filtered.length > 0 && (
          <div style={{ padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 6 }}>
            {filtered.map((msg: any) => {
              const other = getOther(msg);
              const isUnread = !msg.isRead && msg.toId === me?.id;
              const isOnline = onlineUsers.has(other?.id);
              const isMe = msg.fromId === me?.id;

              return (
                <div key={msg.id}
                  onClick={() => router.push(`/messages/${other?.id}`)}
                  style={{ background: '#fff', borderRadius: 18, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', border: isUnread ? '1px solid #e0e7ff' : '1px solid #f1f5f9', boxShadow: '0 1px 3px rgba(15,23,42,0.04)', transition: 'all 0.15s', position: 'relative' }}
                  onMouseEnter={e => (e.currentTarget.style.boxShadow = '0 4px 16px rgba(99,102,241,0.08)')}
                  onMouseLeave={e => (e.currentTarget.style.boxShadow = '0 1px 3px rgba(15,23,42,0.04)')}>

                  <Avatar name={other?.username || '?'} url={other?.avatarUrl} size={52} online={isOnline} />

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                      <span style={{ fontWeight: isUnread ? 800 : 600, fontSize: 15, color: '#0f172a' }}>
                        {other?.displayName || other?.username}
                      </span>
                      <span style={{ fontSize: 11, color: isUnread ? '#6366f1' : '#94a3b8', fontWeight: isUnread ? 700 : 400 }}>
                        {timeAgo(msg.createdAt)}
                      </span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      {isMe && (
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={msg.isRead ? '#6366f1' : '#94a3b8'} strokeWidth="2.5" strokeLinecap="round">
                          <polyline points="20 6 9 17 4 12"/>
                          {msg.isRead && <polyline points="20 6 9 17 4 12" transform="translate(4, 0)"/>}
                        </svg>
                      )}
                      <span style={{ fontSize: 13, color: isUnread ? '#0f172a' : '#94a3b8', fontWeight: isUnread ? 600 : 400, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', flex: 1 }}>
                        {isMe ? 'Sən: ' : ''}{msg.content}
                      </span>
                    </div>
                  </div>

                  {isUnread && (
                    <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#6366f1', flexShrink: 0, boxShadow: '0 0 6px rgba(99,102,241,0.5)' }} />
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Axtarış nəticəsi yox */}
        {search && filtered.length === 0 && inbox.length > 0 && (
          <div style={{ textAlign: 'center', padding: '60px 20px', color: '#94a3b8' }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>🔍</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#475569' }}>"{search}" tapılmadı</div>
          </div>
        )}
      </div>
    </div>
  );
}
