'use client';
import { getToken, apiFetch } from '../../../lib/auth';
import { useState, useEffect, useRef } from 'react';
import { useRouter, useParams } from 'next/navigation';

const API = 'http://localhost:3001/api/v1';
const WS  = 'http://localhost:3001';

const PAL: [string, string][] = [
  ['#6366f1','#a5b4fc'],['#ec4899','#fbcfe8'],
  ['#10b981','#a7f3d0'],['#f59e0b','#fde68a'],
  ['#3b82f6','#bfdbfe'],['#8b5cf6','#ddd6fe'],
];
const grad = (name = 'A') => {
  const [a, b] = PAL[name.charCodeAt(0) % PAL.length];
  return `linear-gradient(135deg, ${a}, ${b})`;
};

function Avatar({ name, url, size }: { name: string; url?: string; size: number }) {
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', overflow: 'hidden', background: grad(name), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size * 0.38, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
      {url ? <img src={url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : name?.[0]?.toUpperCase()}
    </div>
  );
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString('az-AZ', { hour: '2-digit', minute: '2-digit' });
}

function formatDate(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return 'Bu gün';
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return 'Dünən';
  return d.toLocaleDateString('az-AZ', { day: 'numeric', month: 'long' });
}

// Xət işarəsi komponenti
function Ticks({ isTemp, isDelivered, isRead }: { isTemp: boolean; isDelivered: boolean; isRead: boolean }) {
  // isTemp: hələ göndərilməyib → heç nə göstərmə
  if (isTemp) return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round">
      <circle cx="12" cy="12" r="8" strokeDasharray="4 2"/>
    </svg>
  );

  // 2 yaşıl = oxundu
  if (isRead) return (
    <svg width="18" height="11" viewBox="0 0 18 11" fill="none">
      <polyline points="1,6 4,9 10,1"  stroke="#4ade80" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <polyline points="7,6 10,9 16,1" stroke="#4ade80" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );

  // 2 boz = çatdırıldı (online idi)
  if (isDelivered) return (
    <svg width="18" height="11" viewBox="0 0 18 11" fill="none">
      <polyline points="1,6 4,9 10,1"  stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <polyline points="7,6 10,9 16,1" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );

  // 1 boz = göndərildi (offline idi)
  return (
    <svg width="11" height="11" viewBox="0 0 11 11" fill="none">
      <polyline points="1,6 4,9 10,1" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

export default function Conversation() {
  const router = useRouter();
  const { userId: otherId } = useParams() as { userId: string };
  const [messages, setMessages] = useState<any[]>([]);
  const [other, setOther] = useState<any>(null);
  const [me, setMe] = useState<any>(null);
  const [content, setContent] = useState('');
  const [sending, setSending] = useState(false);
  const [isOnline, setIsOnline] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<any>(null);
  const typingTimer = useRef<any>(null);
  const meRef = useRef<any>(null);

  useEffect(() => {
        if (!getToken()) { router.push('/'); return; }

    apiFetch(`${API}/auth/me`)
      .then(r => r.json()).then(d => {
        if (d.success) { setMe(d.data); meRef.current = d.data; }
      });

    apiFetch(`${API}/users/by-id/${otherId}`)
      .then(r => r.json()).then(d => { if (d.success) setOther(d.data); });

    // Söhbəti yüklə + oxunmuş et
    apiFetch(`${API}/messages/${otherId}`)
      .then(r => r.json()).then(d => {
        if (d.success) setMessages(d.data || []);
      });

    // WebSocket
    import('socket.io-client').then(({ io }) => {
      const socket = io(`${WS}/messages`, { auth: { token: getToken() }, transports: ['websocket'] });
      socketRef.current = socket;

      socket.on('user_online',  ({ userId }: any) => { if (userId === otherId) setIsOnline(true);  });
      socket.on('user_offline', ({ userId }: any) => { if (userId === otherId) setIsOnline(false); });

      socket.on('new_message', (msg: any) => {
        if (msg.fromId === otherId || msg.toId === otherId) {
          setMessages(prev => [...prev, msg]);
          setIsTyping(false);
          // Gələn mesajı oxunmuş et
          if (msg.fromId === otherId) {
            apiFetch(`${API}/messages/${otherId}`);
          }
        }
      });

      // Qarşı tərəf oxudu → bütün mesajları yaşıl et
      socket.on('messages_read', ({ fromUserId }: any) => {
        if (fromUserId === otherId) {
          setMessages(prev => prev.map(m =>
            m.fromId === meRef.current?.id ? { ...m, isRead: true } : m
          ));
        }
      });

      socket.on('typing', ({ userId }: any) => {
        if (userId === otherId) {
          setIsTyping(true);
          clearTimeout(typingTimer.current);
          typingTimer.current = setTimeout(() => setIsTyping(false), 2500);
        }
      });
    }).catch(() => {});

    return () => {
      if (socketRef.current) socketRef.current.disconnect();
      clearTimeout(typingTimer.current);
    };
  }, [otherId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  function handleTyping() {
    if (socketRef.current) socketRef.current.emit('typing', { toId: otherId });
  }

  async function sendMessage() {
    if (!content.trim() || sending) return;
    setSending(true);
        const tempId = `temp-${Date.now()}`;
    const optimistic = {
      id: tempId,
      fromId: me?.id,
      toId: otherId,
      content: content.trim(),
      isRead: false,
      isDelivered: false,
      createdAt: new Date().toISOString(),
      from: me,
    };
    setMessages(prev => [...prev, optimistic]);
    setContent('');

    const res = await apiFetch(`${API}/messages`, { method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` },
      body: JSON.stringify({ toId: otherId, content: optimistic.content }),
    });
    const data = await res.json();
    if (data.success) {
      setMessages(prev => prev.map(m => m.id === tempId ? { ...data.data } : m));
    }
    setSending(false);
  }

  function groupByDate(msgs: any[]) {
    const groups: { date: string; msgs: any[] }[] = [];
    for (const m of msgs) {
      const d = formatDate(m.createdAt);
      const last = groups[groups.length - 1];
      if (last && last.date === d) last.msgs.push(m);
      else groups.push({ date: d, msgs: [m] });
    }
    return groups;
  }

  const grouped = groupByDate(messages);
  const otherName = other?.username || otherId;

  return (
    <div style={{
      position: 'fixed', inset: 0,
      display: 'flex', flexDirection: 'column',
      background: '#f8fafc',
      fontFamily: "-apple-system,'Segoe UI',system-ui,sans-serif",
      maxWidth: 500, margin: '0 auto',
    }}>
      <style>{`
        * { box-sizing:border-box; margin:0; padding:0; }
        body { background:#f8fafc; }
        button { font-family:inherit; }
        textarea { font-family:inherit; resize:none; }
        @keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-4px)} }
      `}</style>

      {/* ── SABİT BAŞLIQ ── */}
      <div style={{
        background: '#fff',
        borderBottom: '1px solid #f1f5f9',
        padding: '10px 16px',
        display: 'flex', alignItems: 'center', gap: 12,
        flexShrink: 0,
        boxShadow: '0 1px 4px rgba(15,23,42,0.06)',
        zIndex: 10,
      }}>
        <button onClick={() => router.push('/messages')}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b', display: 'flex', padding: 4, borderRadius: 8 }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>

        <div style={{ position: 'relative', cursor: 'pointer' }} onClick={() => router.push(`/profile/${otherName}`)}>
          <Avatar name={otherName} url={other?.avatarUrl} size={42} />
          {isOnline && (
            <div style={{ position: 'absolute', bottom: 1, right: 1, width: 11, height: 11, borderRadius: '50%', background: '#10b981', border: '2px solid #fff' }} />
          )}
        </div>

        <div style={{ flex: 1, cursor: 'pointer' }} onClick={() => router.push(`/profile/${otherName}`)}>
          <div style={{ fontWeight: 700, fontSize: 15, color: '#0f172a' }}>{other?.displayName || otherName}</div>
          <div style={{ fontSize: 12, color: isOnline ? '#10b981' : '#94a3b8', fontWeight: isOnline ? 600 : 400 }}>
            {isTyping ? 'Yazır...' : isOnline ? '● Online' : `@${otherName}`}
          </div>
        </div>
      </div>

      {/* ── MESAJLAR (sürüşən) ── */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '12px 12px 8px' }}>
        {messages.length === 0 && (
          <div style={{ textAlign: 'center', padding: '60px 20px', color: '#94a3b8' }}>
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 12 }}>
              <Avatar name={otherName} url={other?.avatarUrl} size={64} />
            </div>
            <div style={{ fontSize: 15, fontWeight: 600, color: '#475569' }}>{other?.displayName || otherName}</div>
            <div style={{ fontSize: 13, marginTop: 4 }}>@{otherName}</div>
            <div style={{ fontSize: 13, marginTop: 16 }}>Söhbətinizi başladın! 👋</div>
          </div>
        )}

        {grouped.map(({ date, msgs }) => (
          <div key={date}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '14px 0 10px' }}>
              <div style={{ flex: 1, height: 1, background: '#e2e8f0' }} />
              <span style={{ fontSize: 11, color: '#94a3b8', fontWeight: 600 }}>{date}</span>
              <div style={{ flex: 1, height: 1, background: '#e2e8f0' }} />
            </div>

            {msgs.map((msg: any, idx: number) => {
              const isMine = msg.fromId === me?.id;
              const prevMsg = msgs[idx - 1];
              const nextMsg = msgs[idx + 1];
              const isFirst = !prevMsg || prevMsg.fromId !== msg.fromId;
              const isLast  = !nextMsg || nextMsg.fromId !== msg.fromId;
              const isTemp  = msg.id?.startsWith('temp-');

              return (
                <div key={msg.id} style={{
                  display: 'flex',
                  flexDirection: isMine ? 'row-reverse' : 'row',
                  gap: 8, marginBottom: isLast ? 8 : 2,
                  alignItems: 'flex-end',
                }}>
                  {/* Qarşı tərəf avatarı */}
                  {!isMine && (
                    <div style={{ width: 32, flexShrink: 0 }}>
                      {isLast && <Avatar name={otherName} url={other?.avatarUrl} size={32} />}
                    </div>
                  )}

                  <div style={{ maxWidth: '72%', display: 'flex', flexDirection: 'column', alignItems: isMine ? 'flex-end' : 'flex-start' }}>
                    <div style={{
                      background: isMine ? 'linear-gradient(135deg, #6366f1, #818cf8)' : '#fff',
                      color: isMine ? '#fff' : '#1e293b',
                      padding: '9px 13px',
                      borderRadius: isMine
                        ? `${isFirst ? 18 : 6}px 18px 6px ${isLast ? 18 : 6}px`
                        : `18px ${isFirst ? 18 : 6}px ${isLast ? 18 : 6}px 6px`,
                      fontSize: 14, lineHeight: 1.5,
                      boxShadow: isMine ? '0 2px 8px rgba(99,102,241,0.2)' : '0 1px 3px rgba(15,23,42,0.06)',
                      border: isMine ? 'none' : '1px solid #f1f5f9',
                      wordBreak: 'break-word',
                    }}>
                      {msg.content}
                    </div>

                    {/* Vaxt + xət işarəsi */}
                    {isLast && (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 3, padding: '0 3px' }}>
                        <span style={{ fontSize: 10, color: '#94a3b8' }}>{formatTime(msg.createdAt)}</span>
                        {isMine && (
                          <Ticks
                            isTemp={isTemp}
                            isDelivered={!!msg.isDelivered}
                            isRead={!!msg.isRead}
                          />
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ))}

        {/* Yazır animasiyası */}
        {isTyping && (
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, marginBottom: 8 }}>
            <Avatar name={otherName} url={other?.avatarUrl} size={32} />
            <div style={{ background: '#fff', border: '1px solid #f1f5f9', borderRadius: '18px 18px 18px 6px', padding: '12px 16px', boxShadow: '0 1px 3px rgba(15,23,42,0.06)', display: 'flex', gap: 5, alignItems: 'center' }}>
              {[0, 1, 2].map(i => (
                <div key={i} style={{ width: 7, height: 7, borderRadius: '50%', background: '#94a3b8', animation: `bounce 1.2s ${i * 0.2}s infinite` }} />
              ))}
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* ── SABİT MESAJ YAZMA SAHƏSİ ── */}
      <div style={{
        background: '#fff',
        borderTop: '1px solid #f1f5f9',
        padding: '10px 12px',
        flexShrink: 0,
        boxShadow: '0 -1px 4px rgba(15,23,42,0.04)',
        zIndex: 10,
      }}>
        <div style={{
          display: 'flex', alignItems: 'flex-end', gap: 10,
          background: '#f8fafc', borderRadius: 22,
          padding: '8px 8px 8px 16px',
          border: '1.5px solid #e2e8f0',
          transition: 'border-color 0.15s',
        }}
          onFocusCapture={e => (e.currentTarget.style.borderColor = '#6366f1')}
          onBlurCapture={e => (e.currentTarget.style.borderColor = '#e2e8f0')}>
          <textarea
            value={content}
            onChange={e => { setContent(e.target.value); handleTyping(); }}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            placeholder="Mesaj yaz..."
            rows={1}
            style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 15, color: '#0f172a', lineHeight: 1.5, maxHeight: 100, overflowY: 'auto', paddingTop: 2 }}
            onInput={e => {
              const t = e.currentTarget;
              t.style.height = 'auto';
              t.style.height = Math.min(t.scrollHeight, 100) + 'px';
            }}
          />
          <button onClick={sendMessage} disabled={!content.trim() || sending}
            style={{
              width: 38, height: 38, borderRadius: '50%',
              background: content.trim() ? 'linear-gradient(135deg, #6366f1, #818cf8)' : '#e2e8f0',
              border: 'none', cursor: content.trim() ? 'pointer' : 'default',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0, transition: 'all 0.2s',
              boxShadow: content.trim() ? '0 4px 12px rgba(99,102,241,0.3)' : 'none',
            }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
              stroke={content.trim() ? '#fff' : '#94a3b8'}
              strokeWidth="2.5" strokeLinecap="round">
              <line x1="22" y1="2" x2="11" y2="13"/>
              <polygon points="22 2 15 22 11 13 2 9 22 2"/>
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
