'use client';
export default function ReelsPage() {
  return (
    <iframe
      src="/reels.html"
      style={{
        position: 'fixed',
        inset: 0,
        width: '100%',
        height: '100%',
        border: 'none',
        zIndex: 9999,
      }}
      allow="autoplay"
    />
  );
}
