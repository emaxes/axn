'use client';
import { useRouter, usePathname } from 'next/navigation';
import { useUnread } from './unread-provider';
import { useState, useEffect } from 'react';

const API = 'http://localhost:3001/api/v1';

const IH = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>;
const IS = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>;
const IB = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>;
const IM = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>;
const IU = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;

export default function NavBar() {
  const router = useRouter();
  const pathname = usePathname();
  const { unread, unreadMsg } = useUnread();
  const [username, setUsername] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return;
    fetch(`${API}/auth/me`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(d => { if (d.success) setUsername(d.data.username); });
  }, []);

  const hidden = ['/', '/login', '/register'];
  const isMessages = pathname.startsWith('/messages/') && pathname !== '/messages';
  if (hidden.includes(pathname) || isMessages) return null;

  const nav = [
    { label: 'Ana',      Icon: IH, path: '/feed' },
    { label: 'Axtarış',  Icon: IS, path: '/search' },
    { label: 'Bildiriş', Icon: IB, path: '/notifications', badge: unread },
    { label: 'Mesaj',    Icon: IM, path: '/messages',      badge: unreadMsg },
    { label: 'Profil',   Icon: IU, path: username ? `/profile/${username}` : '#' },
  ];

  return (
    <nav style={{ position: 'fixed', bottom: 12, left: '50%', transform: 'translateX(-50%)', width: 'calc(100% - 24px)', maxWidth: 476, background: '#fff', borderRadius: 20, display: 'flex', zIndex: 1000, boxShadow: '0 4px 20px rgba(15,23,42,0.08)', padding: 6 }}>
      {nav.map(({ label, Icon, path, badge }) => {
        const isActive = pathname === path || (path !== '/feed' && pathname.startsWith(path));
        return (
          <button key={label} onClick={() => router.push(path)}
            style={{ flex: 1, background: isActive ? 'linear-gradient(135deg, #6366f1, #818cf8)' : 'none', border: 'none', cursor: 'pointer', padding: '8px 4px', display: 'flex', flexDirection: 'column' as any, alignItems: 'center', gap: 2, color: isActive ? '#fff' : '#94a3b8', transition: 'all 0.2s', borderRadius: 14, boxShadow: isActive ? '0 4px 12px rgba(99,102,241,0.3)' : 'none' }}>
            <div style={{ position: 'relative' }}>
              <Icon />
              {badge !== undefined && badge > 0 && (
                <span style={{ position: 'absolute', top: -4, right: -6, background: '#f43f5e', color: '#fff', fontSize: 9, fontWeight: 800, borderRadius: 99, minWidth: 16, height: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 3px', border: '2px solid #fff' }}>
                  {badge > 9 ? '9+' : badge}
                </span>
              )}
            </div>
            <span style={{ fontSize: 9.5, fontWeight: isActive ? 700 : 500 }}>{label}</span>
          </button>
        );
      })}
    </nav>
  );
}
