'use client';
import { useState, useTransition } from 'react';

const API = 'http://localhost:3001/api/v1';

type Status = 'none' | 'pending' | 'following' | 'mutual';

interface Props {
  username: string;
  initialStatus?: Status;
  followsYou?: boolean;
  size?: 'sm' | 'md';
  onChanged?: (following: boolean, mutual: boolean) => void;
}

export default function FollowButton({ username, initialStatus = 'none', followsYou = false, size = 'md', onChanged }: Props) {
  const [status, setStatus] = useState<Status>(initialStatus);
  const [isPending, startTransition] = useTransition();

  const isMutual  = status === 'mutual' || (status === 'following' && followsYou);
  const isPending_ = status === 'pending';
  const isFollowing = status === 'following' || status === 'mutual';

  async function toggle() {
    const token = localStorage.getItem('token');
    if (!token) { window.location.href = '/login'; return; }

    const prev = status;
    // Optimistic
    const next: Status = isFollowing || isPending_
      ? 'none'
      : followsYou ? 'mutual' : 'following';
    setStatus(next);

    startTransition(async () => {
      try {
        const res = await fetch(`${API}/users/${username}/follow`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        if (!res.ok) throw new Error();
        const s: Status = !data.data?.following
          ? 'none'
          : data.data?.status === 'pending'
            ? 'pending'
            : followsYou ? 'mutual' : 'following';
        setStatus(s);
        onChanged?.(s !== 'none', s === 'mutual');
      } catch {
        setStatus(prev);
      }
    });
  }

  type StyleDef = { bg: string; color: string; border: string; label: string };
  const styles: Record<string, StyleDef> = {
    none:      { bg: 'linear-gradient(135deg,#6366f1,#8b5cf6)', color:'#fff',   border:'none',                           label: followsYou ? 'Geri izlə' : 'İzlə' },
    pending:   { bg: 'transparent',                              color:'#6366f1', border:'1.5px solid #6366f1',          label: 'Gözləyir...' },
    following: { bg: '#f4f4f5',                                  color:'#111',    border:'1.5px solid rgba(0,0,0,0.08)', label: 'İzləyirsən' },
    mutual:    { bg: '#f0fdf4',                                  color:'#16a34a', border:'1.5px solid #22c55e',          label: '✓ Qarşılıqlı' },
  };

  const key = isMutual ? 'mutual' : status;
  const { bg, color, border, label } = styles[key] || styles.none;
  const pad = size === 'sm' ? '5px 14px' : '8px 22px';
  const fs  = size === 'sm' ? 12 : 14;

  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-start', gap:4 }}>
      {/* "Səni izləyir" badge — yalnız follow etməyəndə */}
      {followsYou && !isFollowing && !isPending_ && (
        <div style={{ display:'inline-flex', alignItems:'center', gap:3, background:'#f1f5f9', borderRadius:99, padding:'2px 8px' }}>
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          <span style={{ fontSize:10, fontWeight:700, color:'#6366f1', fontFamily:"'Outfit',sans-serif", whiteSpace:'nowrap' }}>Səni izləyir</span>
        </div>
      )}
      <button
        onClick={toggle}
        disabled={isPending}
        style={{ background:bg, color, border, borderRadius:99, padding:pad, fontSize:fs, fontWeight:700, cursor:isPending?'wait':'pointer', fontFamily:"'Outfit',sans-serif", transition:'all .2s', opacity:isPending?0.7:1, whiteSpace:'nowrap' }}
      >
        {isPending ? '...' : label}
      </button>
    </div>
  );
}
