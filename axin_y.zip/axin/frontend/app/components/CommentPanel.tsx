'use client';
import {
  useState, useEffect, useRef, useCallback, memo,
} from 'react';
import { io, Socket } from 'socket.io-client';

const API = 'http://localhost:3001/api/v1';
const WS  = 'http://localhost:3001';

/* ── utils ─────────────────────────────────────────────── */
function timeAgo(d: string) {
  const s = (Date.now() - new Date(d).getTime()) / 1000;
  if (s < 60) return 'indi';
  if (s < 3600) return `${~~(s/60)}dəq`;
  if (s < 86400) return `${~~(s/3600)}saat`;
  if (s < 604800) return `${~~(s/86400)}gün`;
  return new Date(d).toLocaleDateString('az');
}

function parseMentions(text: string) {
  return text.split(/(@[a-zA-Z0-9_.]+)/g).map((part, i) =>
    part.startsWith('@')
      ? <span key={i} style={{color:'#6366f1',fontWeight:700}}>{part}</span>
      : part
  );
}

/* ── Avatar ─────────────────────────────────────────────── */
function Avatar({ user, size = 36 }: { user: any; size?: number }) {
  const colors = ['#6366f1','#ec4899','#10b981','#f59e0b','#3b82f6','#8b5cf6'];
  const bg = colors[(user?.username || '').charCodeAt(0) % colors.length];
  return (
    <div style={{width:size,height:size,borderRadius:'50%',flexShrink:0,overflow:'hidden',background:bg,display:'flex',alignItems:'center',justifyContent:'center',fontSize:size*0.4,fontWeight:800,color:'#fff'}}>
      {user?.avatarUrl
        ? <img src={user.avatarUrl} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
        : user?.username?.[0]?.toUpperCase()}
    </div>
  );
}

/* ── Follow badge ────────────────────────────────────────── */
function FollowBadge({ user }: { user: any }) {
  if (!user) return null;
  if (user.isMutual)    return <span style={{fontSize:10,color:'#22c55e',fontWeight:700,background:'#f0fdf4',borderRadius:99,padding:'1px 7px'}}>✓ Qarşılıqlı</span>;
  if (user.followsYou)  return <span style={{fontSize:10,color:'#6366f1',fontWeight:700,background:'#f5f3ff',borderRadius:99,padding:'1px 7px'}}>Səni izləyir</span>;
  return null;
}

/* ── Comment Item ────────────────────────────────────────── */
const CommentItem = memo(function CommentItem({
  comment, me, postOwnerId, onReply, onNavigate, depth = 0,
}: {
  comment: any; me: any; postOwnerId?: string;
  onReply: (c: any) => void; onNavigate: (u: string) => void;
  depth?: number;
}) {
  const [liked,     setLiked]     = useState(comment.isLiked ?? false);
  const [likeCount, setLikeCount] = useState(comment.likeCount ?? 0);
  const [likeAnim,  setLikeAnim]  = useState(false);
  const [expanded,  setExpanded]  = useState(comment.content?.length < 120);
  const [replies,   setReplies]   = useState<any[]>([]);
  const [showReplies, setShowReplies] = useState(false);
  const [replyCursor, setReplyCursor] = useState<string|null>(null);
  const [loadingReplies, setLoadingReplies] = useState(false);
  const [editing,   setEditing]   = useState(false);
  const [editVal,   setEditVal]   = useState(comment.content);
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;

  async function toggleLike() {
    if (!token) return;
    const prev = liked;
    setLiked(!prev); setLikeCount(c => prev ? c-1 : c+1);
    setLikeAnim(true); setTimeout(() => setLikeAnim(false), 400);
    try {
      await fetch(`${API}/comments/${comment.id}/like`, {
        method: 'POST', headers: { Authorization: `Bearer ${token}` },
      });
    } catch { setLiked(prev); setLikeCount(c => prev ? c+1 : c-1); }
  }

  async function doDelete() {
    if (!confirm('Silinsin?')) return;
    await fetch(`${API}/comments/${comment.id}`, {
      method: 'DELETE', headers: { Authorization: `Bearer ${token}` },
    });
  }

  async function doEdit() {
    if (!editVal.trim() || editVal === comment.content) { setEditing(false); return; }
    await fetch(`${API}/comments/${comment.id}`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: editVal }),
    });
    setEditing(false);
  }

  async function loadReplies(cursor?: string) {
    if (loadingReplies) return;
    setLoadingReplies(true);
    const res = await fetch(
      `${API}/comments/${comment.id}/replies?limit=15${cursor ? `&cursor=${cursor}` : ''}`,
      { headers: token ? { Authorization: `Bearer ${token}` } : {} }
    );
    const data = await res.json();
    if (data.replies) {
      setReplies(p => cursor ? [...p, ...data.replies] : data.replies);
      setReplyCursor(data.nextCursor);
      setShowReplies(true);
    }
    setLoadingReplies(false);
  }

  const isOwn = comment.isOwn || comment.userId === me?.id;
  const canPin = me?.id === postOwnerId;
  const isDeleted = comment.isDeleted;
  const text = comment.content || '';

  if (isDeleted) return (
    <div style={{padding:`8px ${depth > 0 ? 0 : 16}px`,opacity:.45,fontSize:13,fontStyle:'italic',color:'#94a3b8',paddingLeft:depth>0?48:16}}>
      Bu şərh silindi
    </div>
  );

  return (
    <div style={{paddingLeft: depth > 0 ? 48 : 0}}>
      <div style={{display:'flex',gap:10,padding:'10px 16px',position:'relative'}}>
        {/* Pinned indicator */}
        {comment.isPinned && (
          <div style={{position:'absolute',top:6,right:16,fontSize:10,color:'#f59e0b',fontWeight:700,display:'flex',alignItems:'center',gap:3}}>
            <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6z"/></svg>
            Sabitlənib
          </div>
        )}

        <div onClick={() => onNavigate(comment.user?.username)} style={{cursor:'pointer',flexShrink:0}}>
          <Avatar user={comment.user} size={depth > 0 ? 30 : 36}/>
        </div>

        <div style={{flex:1,minWidth:0}}>
          {/* Header */}
          <div style={{display:'flex',alignItems:'center',gap:6,flexWrap:'wrap',marginBottom:2}}>
            <span onClick={()=>onNavigate(comment.user?.username)}
              style={{fontWeight:700,fontSize:13,color:'#0f172a',cursor:'pointer'}}>
              {comment.user?.username}
            </span>
            {comment.user?.isVerified && (
              <svg width="13" height="13" viewBox="0 0 24 24" fill="#6366f1"><path d="M9 12l2 2 4-4M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            )}
            <FollowBadge user={comment.user}/>
            {comment.isEdited && <span style={{fontSize:10,color:'#94a3b8'}}>(redaktə edildi)</span>}
          </div>

          {/* Content */}
          {editing ? (
            <div style={{display:'flex',gap:6,alignItems:'flex-end',marginBottom:4}}>
              <textarea value={editVal} onChange={e=>setEditVal(e.target.value)}
                rows={2}
                style={{flex:1,border:'1px solid #e2e8f0',borderRadius:8,padding:'6px 8px',fontSize:13,resize:'none',fontFamily:'inherit',outline:'none'}}/>
              <div style={{display:'flex',flexDirection:'column',gap:4}}>
                <button onClick={doEdit} style={{background:'#6366f1',color:'#fff',border:'none',borderRadius:6,padding:'4px 10px',fontSize:12,fontWeight:700,cursor:'pointer'}}>Saxla</button>
                <button onClick={()=>setEditing(false)} style={{background:'#f1f5f9',color:'#64748b',border:'none',borderRadius:6,padding:'4px 10px',fontSize:12,cursor:'pointer'}}>Ləğv</button>
              </div>
            </div>
          ) : (
            <p style={{fontSize:13,color:'#1e293b',lineHeight:1.55,margin:'0 0 4px',wordBreak:'break-word'}}>
              {expanded ? parseMentions(text) : parseMentions(text.slice(0,120))}
              {!expanded && text.length > 120 && (
                <span onClick={()=>setExpanded(true)} style={{color:'#6366f1',cursor:'pointer',fontWeight:600}}> ...daha çox</span>
              )}
            </p>
          )}

          {/* Actions row */}
          <div style={{display:'flex',alignItems:'center',gap:14}}>
            <span style={{fontSize:11,color:'#94a3b8'}}>{timeAgo(comment.createdAt)}</span>

            {/* Like */}
            <button onClick={toggleLike} style={{display:'flex',alignItems:'center',gap:3,background:'none',border:'none',cursor:'pointer',color:liked?'#f43f5e':'#64748b',transform:likeAnim?'scale(1.35)':'scale(1)',transition:'transform .15s',padding:0}}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill={liked?'currentColor':'none'} stroke="currentColor" strokeWidth="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" strokeLinecap="round"/>
              </svg>
              {likeCount > 0 && <span style={{fontSize:11,fontWeight:600}}>{likeCount}</span>}
            </button>

            {/* Reply */}
            {depth === 0 && (
              <button onClick={()=>onReply(comment)} style={{fontSize:11,fontWeight:600,color:'#64748b',background:'none',border:'none',cursor:'pointer',padding:0}}>
                Cavabla
              </button>
            )}

            {/* Edit / Delete */}
            {isOwn && (
              <>
                <button onClick={()=>setEditing(true)} style={{fontSize:11,color:'#64748b',background:'none',border:'none',cursor:'pointer',padding:0}}>Redaktə</button>
                <button onClick={doDelete} style={{fontSize:11,color:'#ef4444',background:'none',border:'none',cursor:'pointer',padding:0}}>Sil</button>
              </>
            )}

            {/* Pin (post owner) */}
            {canPin && depth === 0 && (
              <button onClick={async()=>{
                await fetch(`${API}/comments/${comment.id}/pin`,{method:'POST',headers:{Authorization:`Bearer ${token}`}});
              }} style={{fontSize:11,color:'#f59e0b',background:'none',border:'none',cursor:'pointer',padding:0}}>
                {comment.isPinned ? 'Sabiti aç' : 'Sabitlə'}
              </button>
            )}
          </div>

          {/* Show replies toggle */}
          {depth === 0 && comment.replyCount > 0 && (
            <button
              onClick={() => showReplies ? setShowReplies(false) : loadReplies()}
              style={{display:'flex',alignItems:'center',gap:6,marginTop:8,background:'none',border:'none',cursor:'pointer',padding:0,color:'#6366f1',fontSize:12,fontWeight:700}}>
              <div style={{width:20,height:1,background:'#e2e8f0'}}/>
              {showReplies ? 'Cavabları gizlə' : `${comment.replyCount} cavabı gör`}
            </button>
          )}
        </div>
      </div>

      {/* Replies */}
      {showReplies && replies.map(r => (
        <CommentItem key={r.id} comment={r} me={me} postOwnerId={postOwnerId}
          onReply={onReply} onNavigate={onNavigate} depth={depth+1}/>
      ))}
      {showReplies && replyCursor && (
        <button onClick={()=>loadReplies(replyCursor)}
          disabled={loadingReplies}
          style={{marginLeft:60,marginBottom:8,background:'none',border:'none',cursor:'pointer',color:'#6366f1',fontSize:12,fontWeight:700}}>
          {loadingReplies ? '...' : 'Daha çox cavab'}
        </button>
      )}
    </div>
  );
});

/* ══════════════════════════════════════
   MAIN CommentPanel
══════════════════════════════════════ */
interface Props {
  post: any;
  me: any;
  onClose: () => void;
  onNavigate?: (path: string) => void;
  onCountChange?: (count: number) => void;
}

export default function CommentPanel({ post, me, onClose, onNavigate, onCountChange }: Props) {
  const [comments,   setComments]   = useState<any[]>([]);
  const [cursor,     setCursor]     = useState<string|null>(null);
  const [total,      setTotal]      = useState(0);
  const [loading,    setLoading]    = useState(false);
  const [loadingMore,setLoadingMore]= useState(false);
  const [replyTo,    setReplyTo]    = useState<any>(null);
  const [input,      setInput]      = useState('');
  const [sending,    setSending]    = useState(false);
  const [dragY,      setDragY]      = useState(0);
  const inputRef   = useRef<HTMLTextAreaElement>(null);
  const listRef    = useRef<HTMLDivElement>(null);
  const socketRef  = useRef<Socket|null>(null);
  const dragStart  = useRef(0);
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : '';

  // ── Load ──
  const load = useCallback(async (reset = false) => {
    if (loading || loadingMore) return;
    reset ? setLoading(true) : setLoadingMore(true);
    try {
      const c = reset ? '' : cursor;
      const res = await fetch(
        `${API}/comments/post/${post.id}?limit=20${c ? `&cursor=${c}` : ''}`,
        { headers: token ? { Authorization: `Bearer ${token}` } : {} }
      );
      const data = await res.json();
      if (data.comments) {
        setComments(p => reset ? data.comments : [...p, ...data.comments]);
        setCursor(data.nextCursor);
        setTotal(data.total);
        onCountChange?.(data.total);
      }
    } finally { setLoading(false); setLoadingMore(false); }
  }, [post.id, cursor, loading, loadingMore, token]);

  useEffect(() => { load(true); }, [post.id]);

  // ── Socket.io ──
  useEffect(() => {
    const sock = io(`${WS}/comments`, { auth: { token } });
    socketRef.current = sock;
    sock.emit('join:post', post.id);

    sock.on('comment:new', (c: any) => {
      setComments(p => {
        if (p.find(x => x.id === c.id)) return p;
        return c.parentId
          ? p.map(x => x.id === c.parentId ? { ...x, replyCount: (x.replyCount||0)+1 } : x)
          : [c, ...p];
      });
      setTotal(n => n + 1);
    });
    sock.on('comment:edit',   (c: any) => setComments(p => p.map(x => x.id===c.id ? {...x,...c} : x)));
    sock.on('comment:delete', ({id}: any) => setComments(p => p.map(x => x.id===id ? {...x,isDeleted:true} : x)));
    sock.on('comment:like',   ({id, userId}: any) => {
      if (userId === me?.id) return;
      setComments(p => p.map(x => x.id===id ? {...x,likeCount:x.likeCount+1} : x));
    });
    sock.on('comment:unlike', ({id, userId}: any) => {
      if (userId === me?.id) return;
      setComments(p => p.map(x => x.id===id ? {...x,likeCount:Math.max(0,x.likeCount-1)} : x));
    });
    sock.on('comment:pin', ({id,isPinned}: any) => {
      setComments(p => p.map(x => ({...x, isPinned: x.id===id ? isPinned : false})));
    });

    return () => { sock.emit('leave:post', post.id); sock.disconnect(); };
  }, [post.id]);

  // ── Send ──
  async function send() {
    if (!input.trim() || sending) return;
    setSending(true);
    const content = replyTo
      ? `@${replyTo.user?.username} ${input.trim()}`
      : input.trim();
    try {
      const res = await fetch(`${API}/comments/post/${post.id}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, parentId: replyTo?.id }),
      });
      const data = await res.json();
      if (data.id) {
        if (!replyTo) {
          setComments(p => [data, ...p]);
          setTotal(n => n+1);
        }
        setInput('');
        setReplyTo(null);
        if (!replyTo) listRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } finally { setSending(false); }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
  }

  // Reply başlayanda @username input-a avtomatik yazılsın
  useEffect(() => {
    if (replyTo) {
      setInput('');
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [replyTo]);

  // ── Bottom sheet drag to close ──
  function onDragStart(e: React.TouchEvent) { dragStart.current = e.touches[0].clientY; }
  function onDragMove(e: React.TouchEvent) {
    const dy = e.touches[0].clientY - dragStart.current;
    if (dy > 0) setDragY(dy);
  }
  function onDragEnd() {
    if (dragY > 120) onClose();
    else setDragY(0);
  }

  // ── Infinite scroll ──
  const bottomRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const obs = new IntersectionObserver(e => {
      if (e[0].isIntersecting && cursor && !loadingMore) load();
    }, { threshold: 0.5 });
    if (bottomRef.current) obs.observe(bottomRef.current);
    return () => obs.disconnect();
  }, [cursor, loadingMore, load]);

  function navigate(username: string) {
    onClose();
    onNavigate?.(`/profile/${username}`);
  }

  return (
    <>
      {/* Backdrop */}
      <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.45)',zIndex:1999,backdropFilter:'blur(2px)'}}
        onClick={onClose}/>

      {/* Panel */}
      <div style={{
        position:'fixed', left:0, right:0, bottom:0, zIndex:2000,
        background:'#fff',
        borderRadius:'20px 20px 0 0',
        maxHeight:'90vh',
        display:'flex', flexDirection:'column',
        transform:`translateY(${dragY}px)`,
        transition: dragY === 0 ? 'transform .35s cubic-bezier(.25,.46,.45,.94)' : 'none',
        boxShadow:'0 -4px 40px rgba(0,0,0,0.15)',
      }}>

        {/* Drag handle */}
        <div onTouchStart={onDragStart} onTouchMove={onDragMove} onTouchEnd={onDragEnd}
          style={{padding:'10px 0 4px',display:'flex',justifyContent:'center',flexShrink:0,cursor:'grab'}}>
          <div style={{width:40,height:4,borderRadius:99,background:'#e2e8f0'}}/>
        </div>

        {/* Header */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'4px 16px 12px',flexShrink:0,borderBottom:'1px solid #f1f5f9'}}>
          <span style={{fontWeight:800,fontSize:16,fontFamily:"'Outfit',sans-serif",color:'#0f172a'}}>
            Şərhlər {total > 0 && <span style={{color:'#94a3b8',fontWeight:500,fontSize:14}}>({total})</span>}
          </span>
          <button onClick={onClose} style={{background:'#f1f5f9',border:'none',borderRadius:'50%',width:32,height:32,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2.2" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>

        {/* Comments list */}
        <div ref={listRef} style={{flex:1,overflowY:'auto',WebkitOverflowScrolling:'touch' as any}}>
          {loading ? (
            <div style={{display:'flex',justifyContent:'center',padding:40,gap:6}}>
              {[0,1,2].map(i=><div key={i} style={{width:8,height:8,borderRadius:'50%',background:'#6366f1',animation:`bounce 1s ${i*0.15}s infinite`}}/>)}
            </div>
          ) : comments.length === 0 ? (
            <div style={{textAlign:'center',padding:'60px 20px',color:'#94a3b8'}}>
              <div style={{fontSize:40,marginBottom:12}}>💬</div>
              <div style={{fontWeight:700,fontSize:15,fontFamily:"'Outfit',sans-serif",marginBottom:4}}>Hələ şərh yoxdur</div>
              <div style={{fontSize:13}}>İlk şərhi sən yaz!</div>
            </div>
          ) : (
            <>
              {comments.map(c => (
                <CommentItem key={c.id} comment={c} me={me}
                  postOwnerId={post.user?.id || post.userId}
                  onReply={setReplyTo} onNavigate={navigate}/>
              ))}
              <div ref={bottomRef} style={{height:20}}/>
              {loadingMore && (
                <div style={{display:'flex',justifyContent:'center',padding:16,gap:6}}>
                  {[0,1,2].map(i=><div key={i} style={{width:6,height:6,borderRadius:'50%',background:'#6366f1',animation:`bounce 1s ${i*0.15}s infinite`}}/>)}
                </div>
              )}
            </>
          )}
        </div>

        {/* Input area */}
        <div style={{borderTop:'1px solid #f1f5f9',padding:'10px 12px',paddingBottom:'calc(10px + env(safe-area-inset-bottom))',flexShrink:0,background:'#fff'}}>
          {/* Reply indicator */}
          {replyTo && (
            <div style={{display:'flex',alignItems:'center',gap:8,background:'#f8fafc',borderRadius:8,padding:'6px 10px',marginBottom:8}}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#6366f1" strokeWidth="2.5"><polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/></svg>
              <span style={{fontSize:12,color:'#6366f1',fontWeight:600,flex:1}}>@{replyTo.user?.username}-ə cavab</span>
              <button onClick={()=>setReplyTo(null)} style={{background:'none',border:'none',cursor:'pointer',color:'#94a3b8',padding:0,lineHeight:1,fontSize:16}}>×</button>
            </div>
          )}

          <div style={{display:'flex',alignItems:'flex-end',gap:10}}>
            <Avatar user={me} size={34}/>
            <div style={{flex:1,background:'#f8fafc',borderRadius:20,padding:'8px 14px',display:'flex',alignItems:'flex-end',gap:8,border:'1.5px solid #e2e8f0',transition:'border-color .2s'}}>
              <textarea
                ref={inputRef}
                value={input}
                onChange={e=>setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={replyTo ? `@${replyTo.user?.username} cavabla...` : 'Şərh yaz...'}
                rows={1}
                style={{
                  flex:1, border:'none', background:'none', outline:'none',
                  fontSize:14, fontFamily:"'Outfit',sans-serif", color:'#0f172a',
                  resize:'none', maxHeight:80, lineHeight:1.5,
                }}
                onInput={e => {
                  const t = e.target as HTMLTextAreaElement;
                  t.style.height = 'auto';
                  t.style.height = t.scrollHeight + 'px';
                }}
              />
              <button
                onClick={send}
                disabled={!input.trim() || sending}
                style={{
                  background: input.trim() ? 'linear-gradient(135deg,#6366f1,#8b5cf6)' : '#e2e8f0',
                  border:'none', borderRadius:'50%', width:32, height:32,
                  display:'flex', alignItems:'center', justifyContent:'center',
                  cursor: input.trim() ? 'pointer' : 'default',
                  flexShrink:0, transition:'background .2s',
                }}>
                {sending
                  ? <div style={{width:14,height:14,borderRadius:'50%',border:'2px solid #fff',borderTopColor:'transparent',animation:'spin .6s linear infinite'}}/>
                  : <svg width="14" height="14" viewBox="0 0 24 24" fill={input.trim()?'#fff':'#94a3b8'}><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                }
              </button>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
        @keyframes spin{to{transform:rotate(360deg)}}
      `}</style>
    </>
  );
}
EOSX
echo "✅ CommentPanel.tsx"