'use client';
import { useState, useEffect } from 'react';

const API = 'http://localhost:3001/api/v1';

export default function FollowRequests() {
  const [reqs, setReqs]     = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return;
    fetch(`${API}/users/requests`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r=>r.json()).then(d => { if (d.success) setReqs(d.data||[]); })
      .finally(() => setLoading(false));
  }, []);

  async function respond(username: string, accept: boolean) {
    const token = localStorage.getItem('token');
    const ep = accept ? 'accept' : 'reject';
    await fetch(`${API}/users/requests/${username}/${ep}`, {
      method: 'POST', headers: { Authorization: `Bearer ${token}` },
    });
    setReqs(r => r.filter(x => x.username !== username));
  }

  if (loading || reqs.length === 0) return null;

  return (
    <div style={{ background:'#fff', borderRadius:16, margin:'8px 12px', overflow:'hidden', boxShadow:'0 1px 4px rgba(0,0,0,0.06)' }}>
      <div style={{ padding:'14px 16px', fontWeight:800, fontSize:14, fontFamily:"'Outfit',sans-serif", borderBottom:'1px solid #f5f5f5' }}>
        İzlə sorğuları ({reqs.length})
      </div>
      {reqs.map(u => (
        <div key={u.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderBottom:'1px solid #fafafa' }}>
          <div style={{ width:44, height:44, borderRadius:'50%', background:'linear-gradient(135deg,#6366f1,#8b5cf6)', flexShrink:0, overflow:'hidden', display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, fontWeight:800, color:'#fff' }}>
            {u.avatarUrl ? <img src={u.avatarUrl} style={{ width:'100%', height:'100%', objectFit:'cover' }}/> : u.username?.[0]?.toUpperCase()}
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:700, fontSize:13, fontFamily:"'Outfit',sans-serif" }}>{u.username}</div>
            <div style={{ fontSize:11, color:'#999' }}>{u.followerCount?.toLocaleString()} izləyici</div>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <button onClick={()=>respond(u.username, true)} style={{ background:'linear-gradient(135deg,#6366f1,#8b5cf6)', color:'#fff', border:'none', borderRadius:99, padding:'7px 16px', fontSize:12, fontWeight:700, cursor:'pointer', fontFamily:"'Outfit',sans-serif" }}>Qəbul et</button>
            <button onClick={()=>respond(u.username, false)} style={{ background:'#f4f4f5', color:'#555', border:'none', borderRadius:99, padding:'7px 14px', fontSize:12, fontWeight:600, cursor:'pointer', fontFamily:"'Outfit',sans-serif" }}>Rədd et</button>
          </div>
        </div>
      ))}
    </div>
  );
}
