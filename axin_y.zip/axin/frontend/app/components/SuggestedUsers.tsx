'use client';
import { useState, useEffect } from 'react';
import FollowButton from './FollowButton';

const API = 'http://localhost:3001/api/v1';

export default function SuggestedUsers() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return;
    fetch(`${API}/users/suggested?limit=10`, {
      headers: { Authorization: `Bearer ${token}` },
    }).then(r=>r.json()).then(d => {
      if (d.success) setUsers(d.data || []);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return null;
  if (users.length === 0) return null;

  return (
    <div style={{ background:'#fff', borderRadius:16, padding:'16px 0', margin:'8px 12px', boxShadow:'0 1px 4px rgba(0,0,0,0.06)' }}>
      <div style={{ padding:'0 16px 12px', fontWeight:800, fontSize:14, fontFamily:"'Outfit',sans-serif", color:'#111' }}>
        Tanıya bilərsən
      </div>
      <div style={{ display:'flex', gap:12, overflowX:'auto', padding:'0 16px', scrollbarWidth:'none' }}>
        {users.map(u => (
          <div key={u.id} style={{ flexShrink:0, width:130, display:'flex', flexDirection:'column', alignItems:'center', gap:8, background:'#fafafa', borderRadius:14, padding:'14px 10px', border:'1px solid #f0f0f0' }}>
            <div style={{ width:56, height:56, borderRadius:'50%', background:'linear-gradient(135deg,#6366f1,#8b5cf6)', overflow:'hidden', display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, fontWeight:800, color:'#fff' }}>
              {u.avatarUrl
                ? <img src={u.avatarUrl} style={{ width:'100%', height:'100%', objectFit:'cover' }}/>
                : u.username?.[0]?.toUpperCase()
              }
            </div>
            <div style={{ textAlign:'center' }}>
              <div style={{ fontWeight:700, fontSize:12, fontFamily:"'Outfit',sans-serif", color:'#111', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', maxWidth:110 }}>{u.username}</div>
              <div style={{ fontSize:11, color:'#888', marginTop:2 }}>{u.followerCount?.toLocaleString()} izləyici</div>
            </div>
            <FollowButton username={u.username} size="sm" onChanged={(f)=>{
              if (!f) setUsers(prev => prev.filter(x => x.id !== u.id));
            }}/>
          </div>
        ))}
      </div>
    </div>
  );
}
