'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import FollowButton from './FollowButton';

const API = 'http://localhost:3001/api/v1';

interface Props {
  username: string;
  type: 'followers' | 'following';
  onClose: () => void;
}

export default function FollowListModal({ username, type, onClose }: Props) {
  const [items, setItems] = useState<any[]>([]);
  const [page, setPage]   = useState(1);
  const [pages, setPages] = useState(1);
  const [q, setQ]         = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const searchTimer = useRef<any>(null);

  const load = useCallback(async (pg: number, search: string, reset = false) => {
    setLoading(true);
    const token = localStorage.getItem('token') || '';
    const res = await fetch(
      `${API}/users/${username}/${type}?page=${pg}&limit=30${search ? `&q=${encodeURIComponent(search)}` : ''}`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    const data = await res.json();
    if (data.success) {
      setItems(prev => reset ? data.data.items : [...prev, ...data.data.items]);
      setPages(data.data.pages);
    }
    setLoading(false);
  }, [username, type]);

  useEffect(() => { load(1, '', true); }, []);

  // Infinite scroll
  useEffect(() => {
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && page < pages && !loading) {
        const next = page + 1;
        setPage(next);
        load(next, q);
      }
    }, { threshold: 0.5 });
    if (bottomRef.current) obs.observe(bottomRef.current);
    return () => obs.disconnect();
  }, [page, pages, loading, q]);

  // Search debounce
  function onSearch(val: string) {
    setQ(val);
    clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => {
      setPage(1);
      load(1, val, true);
    }, 350);
  }

  return (
    <div style={{ position:'fixed', inset:0, zIndex:2000, background:'rgba(0,0,0,0.5)', display:'flex', alignItems:'flex-end' }}
      onClick={onClose}>
      <div style={{ width:'100%', maxHeight:'80vh', background:'#fff', borderRadius:'20px 20px 0 0', display:'flex', flexDirection:'column', overflow:'hidden' }}
        onClick={e=>e.stopPropagation()}>

        {/* Header */}
        <div style={{ padding:'16px 20px 12px', borderBottom:'1px solid #f0f0f0', display:'flex', alignItems:'center', gap:12 }}>
          <button onClick={onClose} style={{ background:'none', border:'none', cursor:'pointer', padding:4 }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#333" strokeWidth="2.2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <span style={{ fontWeight:800, fontSize:16, fontFamily:"'Outfit',sans-serif" }}>
            {type === 'followers' ? 'İzləyicilər' : 'İzlənilənlər'}
          </span>
        </div>

        {/* Search */}
        <div style={{ padding:'10px 16px', borderBottom:'1px solid #f5f5f5' }}>
          <div style={{ background:'#f4f4f5', borderRadius:12, padding:'9px 14px', display:'flex', alignItems:'center', gap:8 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#888" strokeWidth="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35" strokeLinecap="round"/></svg>
            <input
              value={q}
              onChange={e=>onSearch(e.target.value)}
              placeholder="Axtar..."
              style={{ flex:1, border:'none', background:'none', outline:'none', fontSize:14, fontFamily:"'Outfit',sans-serif", color:'#111' }}
            />
          </div>
        </div>

        {/* List */}
        <div style={{ overflowY:'auto', flex:1 }}>
          {items.map(user => (
            <div key={user.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderBottom:'1px solid #fafafa' }}>
              <div style={{ width:46, height:46, borderRadius:'50%', background:'linear-gradient(135deg,#6366f1,#8b5cf6)', flexShrink:0, overflow:'hidden', display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, fontWeight:800, color:'#fff' }}>
                {user.avatarUrl
                  ? <img src={user.avatarUrl} style={{ width:'100%', height:'100%', objectFit:'cover' }}/>
                  : user.username?.[0]?.toUpperCase()
                }
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontWeight:700, fontSize:14, fontFamily:"'Outfit',sans-serif", color:'#111' }}>{user.username}</div>
                {user.displayName && <div style={{ fontSize:12, color:'#888', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{user.displayName}</div>}
                {user.isMutual && <div style={{ fontSize:11, color:'#6366f1', fontWeight:600 }}>Qarşılıqlı izləyici</div>}
              </div>
              <FollowButton
                username={user.username}
                initialStatus={user.isFollowing ? 'following' : 'none'}
                size="sm"
              />
            </div>
          ))}

          {loading && (
            <div style={{ display:'flex', justifyContent:'center', padding:20, gap:6 }}>
              {[0,1,2].map(i => <div key={i} style={{ width:8, height:8, borderRadius:'50%', background:'#6366f1', animation:`bounce 1s ${i*0.15}s infinite` }}/>)}
            </div>
          )}

          {!loading && items.length === 0 && (
            <div style={{ textAlign:'center', padding:40, color:'#aaa', fontFamily:"'Outfit',sans-serif", fontSize:14 }}>
              {q ? 'Nəticə tapılmadı' : type === 'followers' ? 'Hələ izləyici yoxdur' : 'Hələ heç kəsi izləmir'}
            </div>
          )}

          <div ref={bottomRef} style={{ height:20 }}/>
        </div>
      </div>
      <style>{`@keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}`}</style>
    </div>
  );
}
