'use client';
import { getToken, apiFetch } from '../../lib/auth';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';

const API = 'http://localhost:3001/api/v1';

const PAL: [string, string][] = [
  ['#6366f1','#a5b4fc'],['#ec4899','#fbcfe8'],
  ['#10b981','#a7f3d0'],['#f59e0b','#fde68a'],
  ['#3b82f6','#bfdbfe'],['#8b5cf6','#ddd6fe'],
];
const grad = (name = 'A') => {
  const [a, b] = PAL[name.charCodeAt(0) % PAL.length];
  return `linear-gradient(135deg, ${a}, ${b})`;
};

function Avatar({ name, url, size }: { name: string; url?: string; size: number }) {
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', overflow: 'hidden', background: grad(name), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size * 0.38, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
      {url ? <img src={url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : name?.[0]?.toUpperCase()}
    </div>
  );
}

// Debounce hook
function useDebounce(value: string, delay: number) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

type Tab = 'users' | 'posts';

export default function Search() {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [tab, setTab] = useState<Tab>('users');
  const [users, setUsers] = useState<any[]>([]);
  const [posts, setPosts] = useState<any[]>([]);
  const [trending, setTrending] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [me, setMe] = useState<any>(null);
  const [followMap, setFollowMap] = useState<Record<string, boolean>>({});
  const inputRef = useRef<HTMLInputElement>(null);
  const debouncedQuery = useDebounce(query, 350);

  useEffect(() => {
        if (!getToken()) { router.push('/'); return; }
    apiFetch(`${API}/auth/me`)
      .then(r => r.json()).then(d => { if (d.success) setMe(d.data); });
    // Trend istifadəçiləri yüklə
    fetchTrending();
  }, []);

  async function fetchTrending() {
    const res = await apiFetch(`${API}/users/search?q=`);
    const data = await res.json();
    if (data.success) setTrending((data.data || []).slice(0, 8));
  }

  useEffect(() => {
    if (!debouncedQuery.trim()) {
      setUsers([]); setPosts([]); return;
    }
    doSearch(debouncedQuery);
  }, [debouncedQuery]);

  async function doSearch(q: string) {
    setLoading(true);

    const [uRes, pRes] = await Promise.all([
      apiFetch(`${API}/users/search?q=${encodeURIComponent(q)}`),
      apiFetch(`${API}/feed?page=1`),
    ]);

    const [uData, pData] = await Promise.all([uRes.json(), pRes.json()]);

    if (uData.success) setUsers(uData.data || []);
    if (pData.success) {
      // Postları query-ə görə filtrləyirik
      const filtered = (pData.data || []).filter((p: any) =>
        p.content?.toLowerCase().includes(q.toLowerCase())
      );
      setPosts(filtered);
    }
    setLoading(false);
  }

  async function toggleFollow(username: string, userId: string) {
        const res = await apiFetch(`${API}/users/${username}/follow`, { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      setFollowMap(m => ({ ...m, [userId]: data.data.following }));
      setUsers(prev => prev.map(u => u.id === userId
        ? { ...u, followerCount: data.data.following ? u.followerCount + 1 : u.followerCount - 1 }
        : u
      ));
      setTrending(prev => prev.map(u => u.id === userId
        ? { ...u, followerCount: data.data.following ? u.followerCount + 1 : u.followerCount - 1 }
        : u
      ));
    }
  }

  const fmt = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : String(n || 0);
  const isEmpty = query.trim() === '';
  const noResult = !loading && !isEmpty && (tab === 'users' ? users.length === 0 : posts.length === 0);

  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: "-apple-system,'Segoe UI',system-ui,sans-serif", display: 'flex', justifyContent: 'center' }}>
      <style>{`* { box-sizing:border-box; margin:0; padding:0; } body{background:#f8fafc;} button{font-family:inherit;} input{font-family:inherit;} @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>

      <div style={{ width: '100%', maxWidth: 500, paddingBottom: 100 }}>

        {/* ── Header + axtarış ── */}
        <header style={{ position: 'sticky', top: 0, zIndex: 50, background: 'rgba(248,250,252,0.95)', backdropFilter: 'blur(12px)', padding: '14px 16px 10px', borderBottom: '1px solid #f1f5f9' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ flex: 1, position: 'relative' }}>
              {/* Axtarış ikonu */}
              <div style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', pointerEvents: 'none' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                  <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
                </svg>
              </div>
              <input ref={inputRef} type="text" value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="İstifadəçi, post axtar..."
                style={{ width: '100%', background: '#fff', border: '1.5px solid #e2e8f0', borderRadius: 14, padding: '11px 40px 11px 40px', fontSize: 15, color: '#0f172a', outline: 'none', transition: 'border-color 0.15s' }}
                onFocus={e => (e.currentTarget.style.borderColor = '#6366f1')}
                onBlur={e => (e.currentTarget.style.borderColor = '#e2e8f0')}
              />
              {/* Yükləmə / Təmizlə */}
              {loading && (
                <div style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', color: '#6366f1' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" style={{ animation: 'spin 0.8s linear infinite' }}>
                    <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
                  </svg>
                </div>
              )}
              {!loading && query && (
                <button onClick={() => setQuery('')}
                  style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', background: '#e2e8f0', border: 'none', borderRadius: '50%', width: 22, height: 22, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#64748b' }}>
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
              )}
            </div>
          </div>

          {/* Tablar — yalnız axtarış edəndə görünür */}
          {!isEmpty && (
            <div style={{ display: 'flex', marginTop: 10, gap: 6 }}>
              {(['users', 'posts'] as Tab[]).map(t => (
                <button key={t} onClick={() => setTab(t)}
                  style={{ flex: 1, background: tab === t ? '#6366f1' : '#fff', border: tab === t ? 'none' : '1px solid #e2e8f0', borderRadius: 10, padding: '8px 0', fontSize: 13, fontWeight: tab === t ? 700 : 500, color: tab === t ? '#fff' : '#64748b', cursor: 'pointer', transition: 'all 0.15s', boxShadow: tab === t ? '0 4px 12px rgba(99,102,241,0.25)' : 'none' }}>
                  {t === 'users' ? `👤 İstifadəçilər${users.length ? ` (${users.length})` : ''}` : `📝 Postlar${posts.length ? ` (${posts.length})` : ''}`}
                </button>
              ))}
            </div>
          )}
        </header>

        <div style={{ padding: '12px' }}>

          {/* ── BOŞ VƏZİYYƏT: Trend istifadəçilər ── */}
          {isEmpty && (
            <>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#64748b', textTransform: 'uppercase' as any, letterSpacing: '0.5px', marginBottom: 10, paddingLeft: 4 }}>
                🔥 Trend istifadəçilər
              </div>
              <div style={{ display: 'flex', flexDirection: 'column' as any, gap: 8 }}>
                {trending.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '40px 20px', color: '#94a3b8' }}>
                    <div style={{ fontSize: 36, marginBottom: 8 }}>👥</div>
                    <div style={{ fontSize: 14 }}>İstifadəçi tapılmadı</div>
                  </div>
                ) : trending.map((user: any) => (
                  <UserCard key={user.id} user={user} me={me} following={followMap[user.id]} onFollow={toggleFollow} onNavigate={p => router.push(p)} fmt={fmt} />
                ))}
              </div>
            </>
          )}

          {/* ── NƏTİCƏ YOX ── */}
          {noResult && (
            <div style={{ textAlign: 'center', padding: '60px 20px', color: '#94a3b8' }}>
              <div style={{ fontSize: 44, marginBottom: 12 }}>🔍</div>
              <div style={{ fontSize: 16, fontWeight: 600, color: '#475569', marginBottom: 6 }}>Nəticə tapılmadı</div>
              <div style={{ fontSize: 14 }}>"{query}" üçün {tab === 'users' ? 'istifadəçi' : 'post'} yoxdur</div>
            </div>
          )}

          {/* ── İSTİFADƏÇİLƏR ── */}
          {!isEmpty && tab === 'users' && users.length > 0 && (
            <div style={{ display: 'flex', flexDirection: 'column' as any, gap: 8 }}>
              {users.map((user: any) => (
                <UserCard key={user.id} user={user} me={me} following={followMap[user.id]} onFollow={toggleFollow} onNavigate={p => router.push(p)} fmt={fmt} />
              ))}
            </div>
          )}

          {/* ── POSTLAR ── */}
          {!isEmpty && tab === 'posts' && posts.length > 0 && (
            <div style={{ display: 'flex', flexDirection: 'column' as any, gap: 10 }}>
              {posts.map((post: any) => (
                <PostCard key={post.id} post={post} query={query} onNavigate={p => router.push(p)} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── İstifadəçi kartı ──────────────────────────────
function UserCard({ user, me, following, onFollow, onNavigate, fmt }: any) {
  const isMe = me?.id === user.id;
  const isFollowing = following !== undefined ? following : user.isFollowing;

  return (
    <div style={{ background: '#fff', borderRadius: 18, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12, boxShadow: '0 1px 3px rgba(15,23,42,0.04)', border: '1px solid #f1f5f9', cursor: 'pointer' }}
      onClick={() => onNavigate(`/profile/${user.username}`)}>
      <Avatar name={user.username || '?'} url={user.avatarUrl} size={50} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 700, fontSize: 15, color: '#0f172a', letterSpacing: '-0.2px' }}>
          {user.displayName || user.username}
        </div>
        <div style={{ fontSize: 13, color: '#94a3b8' }}>@{user.username}</div>
        <div style={{ fontSize: 12, color: '#cbd5e1', marginTop: 2 }}>
          {fmt(user.followerCount || 0)} izləyici
        </div>
      </div>
      {!isMe && (
        <button
          onClick={e => { e.stopPropagation(); onFollow(user.username, user.id); }}
          style={{ background: isFollowing ? '#fff' : 'linear-gradient(135deg, #6366f1, #818cf8)', border: isFollowing ? '1.5px solid #e2e8f0' : 'none', borderRadius: 99, padding: '7px 16px', fontSize: 12, fontWeight: 700, cursor: 'pointer', color: isFollowing ? '#64748b' : '#fff', flexShrink: 0, transition: 'all 0.15s', boxShadow: isFollowing ? 'none' : '0 4px 10px rgba(99,102,241,0.25)' }}>
          {isFollowing ? 'İzləyirsən' : 'İzlə'}
        </button>
      )}
    </div>
  );
}

// ── Post kartı ────────────────────────────────────
function PostCard({ post, query, onNavigate }: any) {
  const name = post.user?.username || '?';

  // Query sözlərini vurğula
  function highlight(text: string) {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((p: string, i: number) =>
      p.toLowerCase() === query.toLowerCase()
        ? <mark key={i} style={{ background: '#fef9c3', color: '#854d0e', borderRadius: 3, padding: '0 2px' }}>{p}</mark>
        : p
    );
  }

  return (
    <div onClick={() => onNavigate(`/post/${post.id}`)}
      style={{ background: '#fff', borderRadius: 18, padding: 16, boxShadow: '0 1px 3px rgba(15,23,42,0.04)', border: '1px solid #f1f5f9', cursor: 'pointer', transition: 'box-shadow 0.15s' }}
      onMouseEnter={e => (e.currentTarget.style.boxShadow = '0 4px 16px rgba(99,102,241,0.08)')}
      onMouseLeave={e => (e.currentTarget.style.boxShadow = '0 1px 3px rgba(15,23,42,0.04)')}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
        <Avatar name={name} url={post.user?.avatarUrl} size={36} />
        <div>
          <div style={{ fontWeight: 700, fontSize: 14, color: '#0f172a' }}>{post.user?.displayName || name}</div>
          <div style={{ fontSize: 12, color: '#94a3b8' }}>@{name}</div>
        </div>
      </div>
      <p style={{ fontSize: 14, lineHeight: 1.6, color: '#334155', whiteSpace: 'pre-wrap' as any, wordBreak: 'break-word' as any }}>
        {highlight(post.content)}
      </p>
      {post.mediaUrls?.length > 0 && (
        <img src={post.mediaUrls[0]} alt="" style={{ width: '100%', borderRadius: 12, maxHeight: 200, objectFit: 'cover' as any, marginTop: 10 }} />
      )}
      <div style={{ display: 'flex', gap: 16, marginTop: 10, color: '#94a3b8', fontSize: 13 }}>
        <span>♥ {post.likeCount || 0}</span>
        <span>💬 {post.replyCount || 0}</span>
      </div>
    </div>
  );
}
