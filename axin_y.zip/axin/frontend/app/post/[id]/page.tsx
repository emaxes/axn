'use client';
import { getToken, apiFetch } from '../../../lib/auth';
import { useState, useEffect, useRef } from 'react';
import { useRouter, useParams } from 'next/navigation';

const API = 'http://localhost:3001/api/v1';
const PAL: [string,string][] = [['#6366f1','#a5b4fc'],['#ec4899','#fbcfe8'],['#10b981','#a7f3d0'],['#f59e0b','#fde68a']];
const grad = (n='A') => { const [a,b]=PAL[n.charCodeAt(0)%PAL.length]; return `linear-gradient(135deg,${a},${b})`; };

function Avatar({ name, url, size=40 }: { name: string; url?: string; size?: number }) {
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', overflow: 'hidden', background: grad(name), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size*0.38, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
      {url ? <img src={url} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : name?.[0]?.toUpperCase()}
    </div>
  );
}

export default function PostDetail() {
  const router = useRouter();
  const params = useParams();
  const postId = params.id as string;
  const [post, setPost] = useState<any>(null);
  const [replies, setReplies] = useState<any[]>([]);
  const [content, setContent] = useState('');
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
        if (!getToken()) { router.push('/'); return; }
    apiFetch(`${API}/auth/me`)
      .then(r => r.json()).then(d => { if (d.success) setUser(d.data); });
    apiFetch(`${API}/posts/${postId}`)
      .then(r => r.json()).then(d => { if (d.success) setPost(d.data); });
    fetch(`${API}/posts/${postId}/replies`)
      .then(r => r.json()).then(d => { if (d.success) setReplies(d.data?.replies || []); });
  }, [postId]);

  async function toggleLike() {
    if (!post) return;
        const res = await apiFetch(`${API}/posts/${postId}/like`, { method: 'POST' });
    const data = await res.json();
    if (data.success) setPost((p: any) => ({ ...p, likeCount: data.data.liked ? p.likeCount + 1 : Math.max(0, p.likeCount - 1), isLiked: data.data.liked }));
  }

  async function sendReply() {
    if (!content.trim()) return;
    setLoading(true);
        const res = await apiFetch(`${API}/posts`, { method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` },
      body: JSON.stringify({ content, parentId: postId }),
    });
    const data = await res.json();
    if (data.success) {
      setContent('');
      setReplies(prev => [...prev, { ...data.data, user }]);
      setPost((p: any) => ({ ...p, replyCount: p.replyCount + 1 }));
    }
    setLoading(false);
  }

  function timeAgo(iso: string) {
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 60) return `${~~s}s`;
    if (s < 3600) return `${~~(s/60)}dəq`;
    if (s < 86400) return `${~~(s/3600)}saat`;
    return new Date(iso).toLocaleDateString('az-AZ', { day: 'numeric', month: 'short' });
  }

  const isVideo = (url: string) => /\.(mp4|mov|webm)$/i.test(url);

  if (!post) return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontFamily: 'inherit' }}>
      Yüklənir...
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: "-apple-system,'Segoe UI',system-ui,sans-serif", paddingBottom: 100 }}>

      {/* Header */}
      <div style={{ position: 'sticky', top: 0, zIndex: 50, background: '#fff', borderBottom: '1px solid #f1f5f9', padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 14 }}>
        <button onClick={() => router.back()} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', color: '#0f172a' }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <span style={{ fontSize: 17, fontWeight: 800, color: '#0f172a' }}>Post</span>
      </div>

      {/* Əsas Post */}
      <div style={{ background: '#fff', borderBottom: '1px solid #f1f5f9', marginBottom: 8 }}>
        {/* Header */}
        <div style={{ padding: '14px 16px 10px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div onClick={() => router.push(`/profile/${post.user?.username}`)} style={{ cursor: 'pointer' }}>
            <Avatar name={post.user?.username || 'A'} url={post.user?.avatarUrl} size={46} />
          </div>
          <div onClick={() => router.push(`/profile/${post.user?.username}`)} style={{ flex: 1, cursor: 'pointer' }}>
            <div style={{ fontWeight: 700, fontSize: 15, color: '#0f172a' }}>{post.user?.displayName || post.user?.username}</div>
            <div style={{ fontSize: 12, color: '#94a3b8' }}>@{post.user?.username} · {timeAgo(post.createdAt)}</div>
          </div>
        </div>

        {/* Media */}
        {post.mediaUrls?.length > 0 && (
          <div>
            {isVideo(post.mediaUrls[0])
              ? <video src={post.mediaUrls[0]} controls style={{ width: '100%', maxHeight: 420, display: 'block' }} />
              : <img src={post.mediaUrls[0]} style={{ width: '100%', maxHeight: 420, objectFit: 'cover', display: 'block' }} />
            }
          </div>
        )}

        {/* Mətn */}
        {post.content && (
          <div style={{ padding: '12px 16px', fontSize: 16, lineHeight: 1.7, color: '#0f172a', whiteSpace: 'pre-wrap' }}>
            {post.content}
          </div>
        )}

        {/* Yer */}
        {post.location && (
          <div style={{ padding: '0 16px 10px', display: 'flex', alignItems: 'center', gap: 4, color: '#10b981', fontSize: 13, fontWeight: 600 }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            {post.location}
          </div>
        )}

        {/* Vaxt */}
        <div style={{ padding: '8px 16px', fontSize: 12, color: '#94a3b8', borderTop: '1px solid #f8fafc' }}>
          {new Date(post.createdAt).toLocaleString('az-AZ', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
        </div>

        {/* Aksiyalar */}
        <div style={{ padding: '10px 16px', display: 'flex', gap: 24, borderTop: '1px solid #f1f5f9' }}>
          <button onClick={toggleLike}
            style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer', color: post.isLiked ? '#f43f5e' : '#94a3b8', fontWeight: 600, fontSize: 14, fontFamily: 'inherit' }}>
            {post.isLiked
              ? <svg width="20" height="20" viewBox="0 0 24 24" fill="#f43f5e"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
              : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
            }
            {post.likeCount || 0} bəyənmə
          </button>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#94a3b8', fontSize: 14 }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            {post.replyCount || 0} şərh
          </span>
        </div>
      </div>

      {/* Şərhlər */}
      {replies.map((reply: any) => (
        <div key={reply.id} style={{ background: '#fff', marginBottom: 2, padding: '14px 16px' }}>
          <div style={{ display: 'flex', gap: 10 }}>
            <div onClick={() => router.push(`/profile/${reply.user?.username}`)} style={{ cursor: 'pointer' }}>
              <Avatar name={reply.user?.username || 'A'} url={reply.user?.avatarUrl} size={38} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <span style={{ fontWeight: 700, fontSize: 14, color: '#0f172a' }}>{reply.user?.displayName || reply.user?.username}</span>
                <span style={{ fontSize: 12, color: '#94a3b8' }}>· {timeAgo(reply.createdAt)}</span>
              </div>
              <div style={{ fontSize: 14, lineHeight: 1.6, color: '#334155' }}>{reply.content}</div>
            </div>
          </div>
        </div>
      ))}

      {replies.length === 0 && (
        <div style={{ textAlign: 'center', padding: '40px 20px', color: '#94a3b8' }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>💬</div>
          <div style={{ fontSize: 14 }}>Hələ şərh yoxdur. İlk sən yaz!</div>
        </div>
      )}

      {/* Şərh yaz — fixed aşağıda */}
      <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderTop: '1px solid #f1f5f9', padding: '10px 16px', paddingBottom: 'calc(10px + env(safe-area-inset-bottom))', display: 'flex', gap: 10, alignItems: 'flex-end', zIndex: 100 }}>
        <Avatar name={user?.username || 'A'} url={user?.avatarUrl} size={36} />
        <div style={{ flex: 1, background: '#f8fafc', borderRadius: 20, padding: '8px 14px', display: 'flex', alignItems: 'flex-end', gap: 8 }}>
          <textarea ref={inputRef} value={content} onChange={e => setContent(e.target.value)}
            placeholder="Şərh yaz..." maxLength={500} rows={1}
            onInput={e => { const t = e.target as HTMLTextAreaElement; t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 120) + 'px'; }}
            style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 14, color: '#0f172a', fontFamily: 'inherit', resize: 'none', lineHeight: 1.5, maxHeight: 120 }}
          />
          <button onClick={sendReply} disabled={!content.trim() || loading}
            style={{ background: content.trim() ? '#6366f1' : '#e2e8f0', border: 'none', borderRadius: '50%', width: 32, height: 32, cursor: content.trim() ? 'pointer' : 'default', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'all 0.2s' }}>
            {loading
              ? <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" style={{ animation: 'spin 0.8s linear infinite' }}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
              : <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={content.trim() ? '#fff' : '#94a3b8'} strokeWidth="2.5" strokeLinecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            }
          </button>
        </div>
        <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
      </div>
    </div>
  );
}
