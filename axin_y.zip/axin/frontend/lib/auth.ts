/**
 * Axın Auth — Stable, loop-free implementation
 * - No setState calls during token operations
 * - Singleton refresh (no parallel calls)
 * - Dispatches events instead of direct navigation
 */
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';

const K = {
  ACCESS:  'axin_at',
  REFRESH: 'axin_rt',
  USER:    'axin_user',
  EXP:     'axin_exp',
} as const;

/* ── Storage helpers ─────────────────────────────────── */
export const getToken   = () => (typeof window !== 'undefined' ? localStorage.getItem(K.ACCESS)  : null);
export const getRefresh = () => (typeof window !== 'undefined' ? localStorage.getItem(K.REFRESH) : null);

export function getCachedUser(): any | null {
  if (typeof window === 'undefined') return null;
  try { return JSON.parse(localStorage.getItem(K.USER) || 'null'); } catch { return null; }
}

export function saveSession(accessToken: string, refreshToken: string, user?: any) {
  localStorage.setItem(K.ACCESS,  accessToken);
  localStorage.setItem(K.REFRESH, refreshToken);
  if (user) localStorage.setItem(K.USER, JSON.stringify(user));
  // Parse expiry from JWT
  try {
    const payload = JSON.parse(atob(accessToken.split('.')[1]));
    localStorage.setItem(K.EXP, String(payload.exp * 1000));
  } catch {}
}

export function clearSession() {
  Object.values(K).forEach(k => localStorage.removeItem(k));
}

export function isExpired(): boolean {
  const exp = localStorage.getItem(K.EXP);
  if (!exp) return true;
  // Expire 1 min early
  return Date.now() > Number(exp) - 60_000;
}

/* ── Singleton refresh ───────────────────────────────── */
let _pending: Promise<string | null> | null = null;

export async function refreshToken(): Promise<string | null> {
  // Already refreshing — wait for same promise
  if (_pending) return _pending;

  _pending = (async (): Promise<string | null> => {
    const rt = getRefresh();
    if (!rt) { clearSession(); return null; }
    try {
      const res = await fetch(`${API}/auth/refresh`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${rt}`, 'Content-Type': 'application/json' },
      });
      if (!res.ok) { clearSession(); return null; }
      const data = await res.json();
      const at  = data.data?.accessToken  || data.accessToken;
      const nrt = data.data?.refreshToken || data.refreshToken || rt;
      if (!at) { clearSession(); return null; }
      saveSession(at, nrt);
      return at;
    } catch {
      clearSession();
      return null;
    } finally {
      _pending = null;
    }
  })();

  return _pending;
}

/* ── Authenticated fetch ─────────────────────────────── */
export async function apiFetch(url: string, init: RequestInit = {}): Promise<Response> {
  let token = getToken();

  // Refresh before request if needed (but only once)
  if (token && isExpired()) {
    token = await refreshToken();
    if (!token) {
      window.dispatchEvent(new Event('axin:logout'));
      throw new Error('SESSION_EXPIRED');
    }
  }

  const makeHeaders = (t: string | null) => ({
    ...(init.headers as Record<string, string>),
    ...(t ? { Authorization: `Bearer ${t}` } : {}),
  });

  const res = await fetch(url, { ...init, headers: makeHeaders(token) });

  // Handle 401 — try refresh once
  if (res.status === 401 && token) {
    const newToken = await refreshToken();
    if (!newToken) {
      window.dispatchEvent(new Event('axin:logout'));
      throw new Error('SESSION_EXPIRED');
    }
    return fetch(url, { ...init, headers: makeHeaders(newToken) });
  }

  return res;
}

/* ── Auth operations ─────────────────────────────────── */
export async function login(email: string, password: string): Promise<any> {
  const res = await fetch(`${API}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const d = await res.json();
  if (!res.ok) throw new Error(d.message || 'Giriş uğursuz oldu');
  const payload = d.data || d;
  saveSession(payload.accessToken, payload.refreshToken, payload.user);
  return payload.user;
}

export async function register(data: {
  email: string; username: string; password: string; displayName?: string;
}): Promise<any> {
  const res = await fetch(`${API}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const d = await res.json();
  if (!res.ok) throw new Error(d.message || 'Qeydiyyat uğursuz oldu');
  const payload = d.data || d;
  saveSession(payload.accessToken, payload.refreshToken, payload.user);
  return payload.user;
}

export async function logout(): Promise<void> {
  const token = getToken();
  clearSession(); // clear first — prevent retry loops
  try {
    if (token) {
      await fetch(`${API}/auth/logout`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
    }
  } catch {} // ignore network errors on logout
  // Event dispatched by caller (AuthProvider)
}

/* ── Session restore (called once on app start) ──────── */
export async function restoreSession(): Promise<any | null> {
  const token = getToken();
  const rt    = getRefresh();

  // Nothing stored
  if (!token && !rt) return null;

  // Token valid — fetch fresh user data
  if (token && !isExpired()) {
    try {
      const res = await fetch(`${API}/auth/me`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const d = await res.json();
        const user = d.data || d.user || d;
        if (user?.id) {
          localStorage.setItem(K.USER, JSON.stringify(user));
          return user;
        }
      }
      // me failed — fall through to cached user
    } catch {}
    return getCachedUser();
  }

  // Token expired — try refresh
  if (rt) {
    const newToken = await refreshToken();
    if (newToken) {
      try {
        const res = await fetch(`${API}/auth/me`, {
          headers: { Authorization: `Bearer ${newToken}` },
        });
        if (res.ok) {
          const d = await res.json();
          const user = d.data || d.user || d;
          if (user?.id) {
            localStorage.setItem(K.USER, JSON.stringify(user));
            return user;
          }
        }
      } catch {}
      return getCachedUser();
    }
  }

  return null;
}
