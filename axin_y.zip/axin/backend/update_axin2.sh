#!/bin/bash
BASE=~/axin-backend/src

# ── 1. notifications.processor.ts (YENİ FAYL) ──────────────────
cat > $BASE/modules/notifications/notifications.processor.ts << 'EOF'
import { Process, Processor } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';
import { NotificationsService } from './notifications.service';
import { NotificationType } from './notification.entity';

interface LikeJob   { userId: string; fromUserId: string; postId: string }
interface ReplyJob  { userId: string; fromUserId: string; postId: string }
interface FollowJob { userId: string; fromUserId: string }
interface RepostJob { userId: string; fromUserId: string; postId: string }

@Processor('notifications')
export class NotificationsProcessor {
  private readonly logger = new Logger(NotificationsProcessor.name);
  constructor(private readonly notificationsService: NotificationsService) {}

  @Process('like')
  async handleLike(job: Job<LikeJob>) {
    const { userId, fromUserId, postId } = job.data;
    await this.notificationsService.create(userId, fromUserId, NotificationType.LIKE, postId);
  }

  @Process('reply')
  async handleReply(job: Job<ReplyJob>) {
    const { userId, fromUserId, postId } = job.data;
    await this.notificationsService.create(userId, fromUserId, NotificationType.REPLY, postId);
  }

  @Process('follow')
  async handleFollow(job: Job<FollowJob>) {
    const { userId, fromUserId } = job.data;
    await this.notificationsService.create(userId, fromUserId, NotificationType.FOLLOW);
  }

  @Process('repost')
  async handleRepost(job: Job<RepostJob>) {
    const { userId, fromUserId, postId } = job.data;
    await this.notificationsService.create(userId, fromUserId, NotificationType.REPOST, postId);
  }
}
EOF

# ── 2. notification.entity.ts ───────────────────────────────────
cat > $BASE/modules/notifications/notification.entity.ts << 'EOF'
import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  ManyToOne, JoinColumn, Index,
} from 'typeorm';
import { User } from '../users/user.entity';

export enum NotificationType {
  LIKE    = 'like',
  FOLLOW  = 'follow',
  REPLY   = 'reply',
  MENTION = 'mention',
  REPOST  = 'repost',
}

@Entity('notifications')
export class Notification {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Index()
  @Column({ name: 'user_id' })
  userId: string;

  @Column({ name: 'from_user_id' })
  fromUserId: string;

  @Column({ type: 'enum', enum: NotificationType })
  type: NotificationType;

  @Column({ name: 'post_id', nullable: true })
  postId: string;

  @Column({ name: 'is_read', default: false })
  isRead: boolean;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: User;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'from_user_id' })
  fromUser: User;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
}
EOF

# ── 3. notifications.module.ts ──────────────────────────────────
cat > $BASE/modules/notifications/notifications.module.ts << 'EOF'
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule } from '@nestjs/config';
import { Notification } from './notification.entity';
import { NotificationsService } from './notifications.service';
import { NotificationsController } from './notifications.controller';
import { NotificationsGateway } from './notifications.gateway';
import { NotificationsProcessor } from './notifications.processor';

@Module({
  imports: [
    TypeOrmModule.forFeature([Notification]),
    BullModule.registerQueue({ name: 'notifications' }),
    JwtModule.register({}),
    ConfigModule,
  ],
  controllers: [NotificationsController],
  providers: [NotificationsService, NotificationsGateway, NotificationsProcessor],
  exports: [NotificationsService, NotificationsGateway],
})
export class NotificationsModule {}
EOF

# ── 4. posts.service.ts ─────────────────────────────────────────
cat > $BASE/modules/posts/posts.service.ts << 'EOF'
import { Injectable, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { Post } from './post.entity';
import { Like } from './like.entity';
import { CreatePostDto } from './dto/create-post.dto';
import { CacheService } from '../feed/cache.service';

@Injectable()
export class PostsService {
  constructor(
    @InjectRepository(Post) private readonly postRepo: Repository<Post>,
    @InjectRepository(Like) private readonly likeRepo: Repository<Like>,
    @InjectQueue('feed')          private readonly feedQueue: Queue,
    @InjectQueue('notifications') private readonly notifQueue: Queue,
    private readonly cache: CacheService,
  ) {}

  async create(userId: string, dto: CreatePostDto): Promise<Post> {
    const post = this.postRepo.create({
      userId, content: dto.content,
      mediaUrls: dto.mediaUrls || [],
      parentId: dto.parentId || null,
    });
    const saved = await this.postRepo.save(post);
    if (dto.parentId) {
      const parent = await this.postRepo.findOne({ where: { id: dto.parentId } });
      if (parent && parent.userId !== userId) {
        await this.notifQueue.add('reply', { userId: parent.userId, fromUserId: userId, postId: saved.id });
      }
      await this.postRepo.increment({ id: dto.parentId }, 'replyCount', 1);
    } else {
      await this.feedQueue.add('distribute-post', { postId: saved.id, userId });
    }
    return saved;
  }

  async repost(originalPostId: string, userId: string): Promise<Post> {
    const original = await this.postRepo.findOne({
      where: { id: originalPostId, isDeleted: false },
      relations: ['user'],
    });
    if (!original) throw new NotFoundException('Post tapılmadı');
    const alreadyReposted = await this.postRepo.findOne({
      where: { userId, repostOf: originalPostId, isDeleted: false },
    });
    if (alreadyReposted) throw new BadRequestException('Bu postu artıq repost etmisiniz');
    const repost = this.postRepo.create({ userId, content: '', mediaUrls: [], repostOf: originalPostId });
    const saved = await this.postRepo.save(repost);
    await this.postRepo.increment({ id: originalPostId }, 'repostCount', 1);
    await this.feedQueue.add('distribute-post', { postId: saved.id, userId });
    if (original.userId !== userId) {
      await this.notifQueue.add('repost', { userId: original.userId, fromUserId: userId, postId: originalPostId });
    }
    return { ...saved, repostedPost: original } as any;
  }

  async undoRepost(originalPostId: string, userId: string): Promise<void> {
    const repost = await this.postRepo.findOne({
      where: { userId, repostOf: originalPostId, isDeleted: false },
    });
    if (!repost) throw new NotFoundException('Repost tapılmadı');
    await this.postRepo.update(repost.id, { isDeleted: true });
    await this.postRepo.decrement({ id: originalPostId }, 'repostCount', 1);
    await this.cache.del(`post:${repost.id}`);
  }

  async findById(postId: string, currentUserId?: string): Promise<any> {
    const post = await this.postRepo.findOne({
      where: { id: postId, isDeleted: false },
      relations: ['user'],
    });
    if (!post) throw new NotFoundException('Post tapılmadı');
    let isLiked = false;
    let isReposted = false;
    if (currentUserId) {
      const [like, repost] = await Promise.all([
        this.likeRepo.findOne({ where: { postId, userId: currentUserId } }),
        post.repostOf ? null : this.postRepo.findOne({
          where: { userId: currentUserId, repostOf: postId, isDeleted: false },
        }),
      ]);
      isLiked = !!like;
      isReposted = !!repost;
    }
    let repostedPost = null;
    if (post.repostOf) {
      repostedPost = await this.postRepo.findOne({ where: { id: post.repostOf }, relations: ['user'] });
    }
    return { ...post, isLiked, isReposted, repostedPost };
  }

  async delete(postId: string, userId: string): Promise<void> {
    const post = await this.postRepo.findOne({ where: { id: postId } });
    if (!post) throw new NotFoundException('Post tapılmadı');
    if (post.userId !== userId) throw new ForbiddenException('İcazəniz yoxdur');
    await this.postRepo.update(postId, { isDeleted: true });
    if (post.repostOf) await this.postRepo.decrement({ id: post.repostOf }, 'repostCount', 1);
    await this.cache.del(`post:${postId}`);
  }

  async getReplies(postId: string, page = 1, limit = 20) {
    const [replies, total] = await this.postRepo
      .createQueryBuilder('post')
      .innerJoinAndSelect('post.user', 'user')
      .where('post.parentId = :postId', { postId })
      .andWhere('post.isDeleted = false')
      .orderBy('post.createdAt', 'ASC')
      .skip((page - 1) * limit).take(limit)
      .getManyAndCount();
    return { replies, total };
  }

  async toggleLike(postId: string, userId: string) {
    const post = await this.postRepo.findOne({ where: { id: postId } });
    if (!post) throw new NotFoundException('Post tapılmadı');
    const existing = await this.likeRepo.findOne({ where: { postId, userId } });
    if (existing) {
      await this.likeRepo.delete({ postId, userId });
      await this.postRepo.decrement({ id: postId }, 'likeCount', 1);
      return { liked: false };
    } else {
      await this.likeRepo.save(this.likeRepo.create({ postId, userId }));
      await this.postRepo.increment({ id: postId }, 'likeCount', 1);
      if (post.userId !== userId) {
        await this.notifQueue.add('like', { userId: post.userId, fromUserId: userId, postId });
      }
      return { liked: true };
    }
  }
}
EOF

# ── 5. posts.controller.ts ──────────────────────────────────────
cat > $BASE/modules/posts/posts.controller.ts << 'EOF'
import { Controller, Get, Post, Delete, Body, Param, Query, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { PostsService } from './posts.service';
import { CreatePostDto } from './dto/create-post.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { GetUser } from '../../common/decorators/get-user.decorator';

@Controller({ path: 'posts', version: '1' })
export class PostsController {
  constructor(private readonly postsService: PostsService) {}

  @Post()
  @UseGuards(JwtAuthGuard)
  create(@GetUser('id') userId: string, @Body() dto: CreatePostDto) {
    return this.postsService.create(userId, dto);
  }

  @Get(':id')
  findOne(@Param('id') id: string, @GetUser('id') userId: string) {
    return this.postsService.findById(id, userId);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id') id: string, @GetUser('id') userId: string) {
    return this.postsService.delete(id, userId);
  }

  @Get(':id/replies')
  getReplies(@Param('id') id: string, @Query('page') page = 1) {
    return this.postsService.getReplies(id, +page);
  }

  @Post(':id/like')
  @UseGuards(JwtAuthGuard)
  like(@Param('id') postId: string, @GetUser('id') userId: string) {
    return this.postsService.toggleLike(postId, userId);
  }

  @Post(':id/repost')
  @UseGuards(JwtAuthGuard)
  repost(@Param('id') postId: string, @GetUser('id') userId: string) {
    return this.postsService.repost(postId, userId);
  }

  @Delete(':id/repost')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.NO_CONTENT)
  undoRepost(@Param('id') postId: string, @GetUser('id') userId: string) {
    return this.postsService.undoRepost(postId, userId);
  }
}
EOF

# ── 6. users.service.ts ─────────────────────────────────────────
cat > $BASE/modules/users/users.service.ts << 'EOF'
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { User } from './user.entity';
import { Follow } from './follow.entity';
import { Post } from '../posts/post.entity';
import { UpdateProfileDto } from './dto/update-profile.dto';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)   private readonly userRepo: Repository<User>,
    @InjectRepository(Follow) private readonly followRepo: Repository<Follow>,
    @InjectRepository(Post)   private readonly postRepo: Repository<Post>,
    @InjectQueue('notifications') private readonly notifQueue: Queue,
  ) {}

  async findByUsername(username: string) {
    const user = await this.userRepo.findOne({ where: { username } });
    if (!user) throw new NotFoundException('İstifadəçi tapılmadı');
    const { password, refreshToken, ...safe } = user as any;
    return safe;
  }

  async search(q: string) {
    if (!q || q.trim().length < 2) return [];
    const users = await this.userRepo.find({
      where: [
        { username: Like(`%${q.toLowerCase()}%`) },
        { displayName: Like(`%${q}%`) },
      ],
      take: 20,
    });
    return users.map(({ password, refreshToken, ...safe }: any) => safe);
  }

  async updateProfile(userId: string, dto: UpdateProfileDto) {
    await this.userRepo.update(userId, dto);
    const user = await this.userRepo.findOne({ where: { id: userId } });
    const { password, refreshToken, ...safe } = user as any;
    return safe;
  }

  async toggleFollow(followerId: string, targetUsername: string) {
    const target = await this.userRepo.findOne({ where: { username: targetUsername } });
    if (!target) throw new NotFoundException('İstifadəçi tapılmadı');
    if (target.id === followerId) throw new BadRequestException('Özünüzü follow edə bilməzsiniz');
    const existing = await this.followRepo.findOne({ where: { followerId, followingId: target.id } });
    if (existing) {
      await this.followRepo.delete({ followerId, followingId: target.id });
      await this.userRepo.decrement({ id: followerId }, 'followingCount', 1);
      await this.userRepo.decrement({ id: target.id }, 'followerCount', 1);
      return { following: false };
    } else {
      await this.followRepo.save(this.followRepo.create({ followerId, followingId: target.id }));
      await this.userRepo.increment({ id: followerId }, 'followingCount', 1);
      await this.userRepo.increment({ id: target.id }, 'followerCount', 1);
      await this.notifQueue.add('follow', { userId: target.id, fromUserId: followerId });
      return { following: true };
    }
  }

  async getUserPosts(username: string, page = 1, limit = 20) {
    const [posts, total] = await this.postRepo
      .createQueryBuilder('post')
      .innerJoinAndSelect('post.user', 'user')
      .where('user.username = :username', { username })
      .andWhere('post.isDeleted = false')
      .orderBy('post.createdAt', 'DESC')
      .skip((page - 1) * limit).take(limit)
      .getManyAndCount();
    return { posts, total };
  }

  async getFollowers(username: string) {
    const user = await this.userRepo.findOne({ where: { username } });
    if (!user) throw new NotFoundException('İstifadəçi tapılmadı');
    const follows = await this.followRepo.find({ where: { followingId: user.id }, relations: ['follower'] });
    return follows.map(f => { const { password, refreshToken, ...safe } = f.follower as any; return safe; });
  }

  async getFollowing(username: string) {
    const user = await this.userRepo.findOne({ where: { username } });
    if (!user) throw new NotFoundException('İstifadəçi tapılmadı');
    const follows = await this.followRepo.find({ where: { followerId: user.id }, relations: ['following'] });
    return follows.map(f => { const { password, refreshToken, ...safe } = f.following as any; return safe; });
  }
}
EOF

# ── 7. users.module.ts ──────────────────────────────────────────
cat > $BASE/modules/users/users.module.ts << 'EOF'
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { User } from './user.entity';
import { Follow } from './follow.entity';
import { Post } from '../posts/post.entity';
import { UsersService } from './users.service';
import { UsersController } from './users.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([User, Follow, Post]),
    BullModule.registerQueue({ name: 'notifications' }),
  ],
  controllers: [UsersController],
  providers: [UsersService],
  exports: [TypeOrmModule],
})
export class UsersModule {}
EOF

# ── 8. users.controller.ts ──────────────────────────────────────
cat > $BASE/modules/users/users.controller.ts << 'EOF'
import { Controller, Get, Post, Patch, Param, Query, Body, UseGuards } from '@nestjs/common';
import { UsersService } from './users.service';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { GetUser } from '../../common/decorators/get-user.decorator';

@Controller({ path: 'users', version: '1' })
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get('search')
  search(@Query('q') q: string) { return this.usersService.search(q); }

  @Patch('me')
  @UseGuards(JwtAuthGuard)
  updateProfile(@GetUser('id') userId: string, @Body() dto: UpdateProfileDto) {
    return this.usersService.updateProfile(userId, dto);
  }

  @Get(':username')
  getProfile(@Param('username') username: string) { return this.usersService.findByUsername(username); }

  @Post(':username/follow')
  @UseGuards(JwtAuthGuard)
  follow(@Param('username') username: string, @GetUser('id') userId: string) {
    return this.usersService.toggleFollow(userId, username);
  }

  @Get(':username/posts')
  getPosts(@Param('username') username: string, @Query('page') page = 1) {
    return this.usersService.getUserPosts(username, +page);
  }

  @Get(':username/followers')
  getFollowers(@Param('username') username: string) { return this.usersService.getFollowers(username); }

  @Get(':username/following')
  getFollowing(@Param('username') username: string) { return this.usersService.getFollowing(username); }
}
EOF

echo "✅ Bütün fayllar yeniləndi!"
pm2 restart all
