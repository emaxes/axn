import { registerAs } from '@nestjs/config';

export default registerAs('storage', () => ({
  accountId: process.env.CF_ACCOUNT_ID,
  accessKeyId: process.env.R2_ACCESS_KEY_ID,
  secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
  bucketName: process.env.R2_BUCKET_NAME || 'axin-media',
  publicUrl: process.env.R2_PUBLIC_URL,   // https://media.axin.az
  endpoint: `https://${process.env.CF_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  maxFileSize: {
    image: 10 * 1024 * 1024,  // 10MB
    video: 100 * 1024 * 1024, // 100MB
  },
  allowedMimeTypes: {
    image: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
    video: ['video/mp4', 'video/webm'],
  },
}));
