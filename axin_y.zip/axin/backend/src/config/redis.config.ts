import { registerAs } from '@nestjs/config';

export default registerAs('redis', () => ({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT, 10) || 6379,
  password: process.env.REDIS_PASSWORD || '',
  url: process.env.REDIS_URL || 'redis://localhost:6379',
  ttl: {
    feed: 300,           // Feed 5 dəqiqə cache-lənir
    user: 600,           // User profil 10 dəqiqə
    trending: 3600,      // Trending 1 saat
    session: 604800,     // Session 7 gün
  },
}));
