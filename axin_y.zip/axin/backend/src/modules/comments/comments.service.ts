import {
  Injectable, NotFoundException, ForbiddenException, BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, IsNull, MoreThan } from 'typeorm';
import { Comment } from './comment.entity';
import { CommentLike } from './comment-like.entity';
import { Post } from '../posts/post.entity';
import { Follow } from '../users/follow.entity';
import { FollowStatus } from '../users/follow.entity';
import { CommentsGateway } from './comments.gateway';
import { NotificationsService } from '../notifications/notifications.service';

const SAFE_USER = (u: any) => {
  if (!u) return null;
  const { password, refreshToken, ...s } = u;
  return s;
};

// @mention regex
const MENTION_RE = /@([a-zA-Z0-9_.]+)/g;

@Injectable()
export class CommentsService {
  constructor(
    @InjectRepository(Comment)     private commentRepo:     Repository<Comment>,
    @InjectRepository(CommentLike) private likeRepo:        Repository<CommentLike>,
    @InjectRepository(Post)        private postRepo:         Repository<Post>,
    @InjectRepository(Follow)      private followRepo:       Repository<Follow>,
    private readonly gateway:      CommentsGateway,
    private readonly notifSvc:     NotificationsService,
  ) {}

  // ─── Enrich (isLiked, isOwn, follow state) ─────────────────────
  private async enrich(comments: Comment[], viewerId?: string): Promise<Comment[]> {
    if (!viewerId || comments.length === 0) return comments;

    const ids = comments.map(c => c.id);
    const likes = await this.likeRepo
      .createQueryBuilder('l')
      .where('l.commentId IN (:...ids)', { ids })
      .andWhere('l.userId = :uid', { uid: viewerId })
      .getMany();
    const likedSet = new Set(likes.map(l => l.commentId));

    // Follow states for unique user ids in comments
    const userIds = [...new Set(comments.map(c => c.userId))];
    const follows = userIds.length > 0 ? await this.followRepo
      .createQueryBuilder('f')
      .where('f.followerId = :vid', { vid: viewerId })
      .andWhere('f.followingId IN (:...uids)', { uids: userIds })
      .andWhere('f.status = :s', { s: FollowStatus.ACCEPTED })
      .getMany() : [];
    const followingSet = new Set(follows.map(f => f.followingId));

    const revFollows = userIds.length > 0 ? await this.followRepo
      .createQueryBuilder('f')
      .where('f.followingId = :vid', { vid: viewerId })
      .andWhere('f.followerId IN (:...uids)', { uids: userIds })
      .andWhere('f.status = :s', { s: FollowStatus.ACCEPTED })
      .getMany() : [];
    const followsYouSet = new Set(revFollows.map(f => f.followerId));

    return comments.map(c => ({
      ...c,
      isLiked: likedSet.has(c.id),
      isOwn: c.userId === viewerId,
      user: c.user ? {
        ...SAFE_USER(c.user),
        isFollowing: followingSet.has(c.userId),
        followsYou: followsYouSet.has(c.userId),
        isMutual: followingSet.has(c.userId) && followsYouSet.has(c.userId),
      } : null,
    }));
  }

  // ─── GET: top-level comments (cursor pagination) ────────────────
  async getComments(postId: string, cursor?: string, limit = 20, viewerId?: string) {
    const post = await this.postRepo.findOne({ where: { id: postId } });
    if (!post) throw new NotFoundException('Post tapılmadı');

    let qb = this.commentRepo.createQueryBuilder('c')
      .innerJoinAndSelect('c.user', 'u')
      .where('c.postId = :postId', { postId })
      .andWhere('c.parentId IS NULL')
      .andWhere('c.isDeleted = false');

    if (cursor) {
      // Pinned-lar hər zaman yuxarıda, sonra cursor-dan davam et
      qb = qb.andWhere('(c.isPinned = false AND c.createdAt < :cursor)', { cursor: new Date(cursor) });
    }

    // Pinned-lar əvvəl, sonra tarix sırası
    const pinnedQb = this.commentRepo.createQueryBuilder('c')
      .innerJoinAndSelect('c.user', 'u')
      .where('c.postId = :postId', { postId })
      .andWhere('c.parentId IS NULL')
      .andWhere('c.isDeleted = false')
      .andWhere('c.isPinned = true')
      .orderBy('c.createdAt', 'DESC');

    const [pinned, regular, total] = await Promise.all([
      cursor ? [] : pinnedQb.getMany(),
      qb.orderBy('c.isPinned', 'DESC').addOrderBy('c.createdAt', 'DESC').take(limit).getMany(),
      this.commentRepo.count({ where: { postId, parentId: IsNull(), isDeleted: false } }),
    ]);

    const all = cursor ? regular : [...pinned, ...regular.filter(r => !r.isPinned)];
    const enriched = await this.enrich(all, viewerId);
    const nextCursor = enriched.length === limit ? enriched[enriched.length - 1].createdAt.toISOString() : null;

    return { comments: enriched, nextCursor, total };
  }

  // ─── GET: replies ───────────────────────────────────────────────
  async getReplies(commentId: string, cursor?: string, limit = 15, viewerId?: string) {
    let qb = this.commentRepo.createQueryBuilder('c')
      .innerJoinAndSelect('c.user', 'u')
      .where('c.parentId = :commentId', { commentId })
      .andWhere('c.isDeleted = false');

    if (cursor) qb = qb.andWhere('c.createdAt > :cursor', { cursor: new Date(cursor) });

    const replies = await qb.orderBy('c.createdAt', 'ASC').take(limit).getMany();
    const enriched = await this.enrich(replies, viewerId);
    const nextCursor = enriched.length === limit ? enriched[enriched.length - 1].createdAt.toISOString() : null;

    return { replies: enriched, nextCursor };
  }

  // ─── ADD comment ────────────────────────────────────────────────
  async addComment(postId: string, userId: string, content: string, parentId?: string) {
    if (!content?.trim()) throw new BadRequestException('Şərh boş ola bilməz');
    if (content.length > 1000) throw new BadRequestException('Şərh çox uzundur');

    const post = await this.postRepo.findOne({ where: { id: postId } });
    if (!post) throw new NotFoundException('Post tapılmadı');

    // Mention extract
    const mentions = [...content.matchAll(MENTION_RE)].map(m => m[1]);

    const comment = this.commentRepo.create({
      postId, userId, content: content.trim(), parentId: parentId || null, mentions,
    });
    const saved = await this.commentRepo.save(comment);

    // Count update
    if (parentId) {
      await this.commentRepo.increment({ id: parentId }, 'replyCount', 1);
    } else {
      await this.postRepo.increment({ id: postId }, 'replyCount', 1);
    }

    // Load with user
    const full = await this.commentRepo.findOne({
      where: { id: saved.id }, relations: ['user'],
    });
    const enriched = (await this.enrich([full!], userId))[0];

    // Real-time
    this.gateway.emitToPost(postId, 'comment:new', enriched);

    // Notifications
    if (post.userId !== userId) {
      await this.notifSvc.create(post.userId, userId, 'reply' as any, { postId });
    }
    // Mention notifications
    for (const mention of mentions) {
      await this.notifSvc.createMention(mention, userId, postId, saved.id);
    }

    return enriched;
  }

  // ─── EDIT ───────────────────────────────────────────────────────
  async editComment(commentId: string, userId: string, content: string) {
    if (!content?.trim()) throw new BadRequestException('Boş ola bilməz');
    const c = await this.commentRepo.findOne({ where: { id: commentId } });
    if (!c) throw new NotFoundException('Şərh tapılmadı');
    if (c.userId !== userId) throw new ForbiddenException('İcazəniz yoxdur');

    const mentions = [...content.matchAll(MENTION_RE)].map(m => m[1]);
    await this.commentRepo.update(commentId, { content: content.trim(), isEdited: true, mentions });

    const updated = await this.commentRepo.findOne({ where: { id: commentId }, relations: ['user'] });
    const enriched = (await this.enrich([updated!], userId))[0];
    this.gateway.emitToPost(c.postId, 'comment:edit', enriched);
    return enriched;
  }

  // ─── DELETE ─────────────────────────────────────────────────────
  async deleteComment(commentId: string, userId: string) {
    const c = await this.commentRepo.findOne({ where: { id: commentId } });
    if (!c) throw new NotFoundException('Şərh tapılmadı');

    const post = await this.postRepo.findOne({ where: { id: c.postId } });
    const isOwner = c.userId === userId || post?.userId === userId;
    if (!isOwner) throw new ForbiddenException('İcazəniz yoxdur');

    await this.commentRepo.update(commentId, { isDeleted: true });

    if (c.parentId) {
      await this.commentRepo.decrement({ id: c.parentId }, 'replyCount', 1);
    } else {
      await this.postRepo.decrement({ id: c.postId }, 'replyCount', 1);
    }

    this.gateway.emitToPost(c.postId, 'comment:delete', { id: commentId, postId: c.postId });
    return { deleted: true };
  }

  // ─── LIKE / UNLIKE ──────────────────────────────────────────────
  async toggleLike(commentId: string, userId: string) {
    const c = await this.commentRepo.findOne({ where: { id: commentId } });
    if (!c) throw new NotFoundException('Şərh tapılmadı');

    const existing = await this.likeRepo.findOne({ where: { commentId, userId } });
    if (existing) {
      await this.likeRepo.delete({ commentId, userId });
      await this.commentRepo.decrement({ id: commentId }, 'likeCount', 1);
      this.gateway.emitToPost(c.postId, 'comment:unlike', { id: commentId, userId });
      return { liked: false, likeCount: Math.max(0, c.likeCount - 1) };
    }

    await this.likeRepo.save(this.likeRepo.create({ commentId, userId }));
    await this.commentRepo.increment({ id: commentId }, 'likeCount', 1);
    this.gateway.emitToPost(c.postId, 'comment:like', { id: commentId, userId });
    return { liked: true, likeCount: c.likeCount + 1 };
  }

  // ─── PIN (post owner only) ──────────────────────────────────────
  async pinComment(commentId: string, userId: string) {
    const c = await this.commentRepo.findOne({ where: { id: commentId } });
    if (!c) throw new NotFoundException();
    const post = await this.postRepo.findOne({ where: { id: c.postId } });
    if (post?.userId !== userId) throw new ForbiddenException();

    // Unpin others first
    await this.commentRepo.update({ postId: c.postId, isPinned: true }, { isPinned: false });
    const next = !c.isPinned;
    await this.commentRepo.update(commentId, { isPinned: next });
    this.gateway.emitToPost(c.postId, 'comment:pin', { id: commentId, isPinned: next });
    return { pinned: next };
  }
}
