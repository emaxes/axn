import {
  WebSocketGateway, WebSocketServer, SubscribeMessage,
  OnGatewayConnection, OnGatewayDisconnect, ConnectedSocket, MessageBody,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';

@WebSocketGateway({ cors: { origin: '*' }, namespace: '/comments' })
export class CommentsGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;

  constructor(
    private jwtService: JwtService,
    private config: ConfigService,
  ) {}

  async handleConnection(client: Socket) {
    try {
      const token = client.handshake.auth?.token;
      if (token) {
        const p = this.jwtService.verify(token, { secret: this.config.get('app.jwtSecret') });
        client.data.userId = p.sub;
      }
    } catch {}
  }

  handleDisconnect(client: Socket) {
    // Leave all rooms
    client.rooms.forEach(r => client.leave(r));
  }

  @SubscribeMessage('join:post')
  joinPost(@ConnectedSocket() client: Socket, @MessageBody() postId: string) {
    client.join(`post:${postId}`);
    return { joined: postId };
  }

  @SubscribeMessage('leave:post')
  leavePost(@ConnectedSocket() client: Socket, @MessageBody() postId: string) {
    client.leave(`post:${postId}`);
  }

  // Emit to all clients watching a post
  emitToPost(postId: string, event: string, data: any) {
    this.server.to(`post:${postId}`).emit(event, data);
  }
}
