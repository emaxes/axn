import {
  Controller, Get, Post, Patch, Delete, Param, Body,
  Query, UseGuards, DefaultValuePipe, ParseIntPipe,
} from '@nestjs/common';
import { CommentsService } from './comments.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { OptionalJwtGuard } from '../auth/guards/optional-jwt.guard';
import { GetUser } from '../../common/decorators/get-user.decorator';

@Controller({ path: 'comments', version: '1' })
export class CommentsController {
  constructor(private svc: CommentsService) {}

  @Get('post/:postId')
  @UseGuards(OptionalJwtGuard)
  getComments(
    @Param('postId') postId: string,
    @Query('cursor') cursor: string,
    @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number,
    @GetUser('id') uid?: string,
  ) {
    return this.svc.getComments(postId, cursor, limit, uid);
  }

  @Get(':commentId/replies')
  @UseGuards(OptionalJwtGuard)
  getReplies(
    @Param('commentId') commentId: string,
    @Query('cursor') cursor: string,
    @Query('limit', new DefaultValuePipe(15), ParseIntPipe) limit: number,
    @GetUser('id') uid?: string,
  ) {
    return this.svc.getReplies(commentId, cursor, limit, uid);
  }

  @Post('post/:postId')
  @UseGuards(JwtAuthGuard)
  add(
    @Param('postId') postId: string,
    @GetUser('id') uid: string,
    @Body('content') content: string,
    @Body('parentId') parentId?: string,
  ) {
    return this.svc.addComment(postId, uid, content, parentId);
  }

  @Patch(':commentId')
  @UseGuards(JwtAuthGuard)
  edit(
    @Param('commentId') commentId: string,
    @GetUser('id') uid: string,
    @Body('content') content: string,
  ) {
    return this.svc.editComment(commentId, uid, content);
  }

  @Delete(':commentId')
  @UseGuards(JwtAuthGuard)
  delete(@Param('commentId') commentId: string, @GetUser('id') uid: string) {
    return this.svc.deleteComment(commentId, uid);
  }

  @Post(':commentId/like')
  @UseGuards(JwtAuthGuard)
  like(@Param('commentId') commentId: string, @GetUser('id') uid: string) {
    return this.svc.toggleLike(commentId, uid);
  }

  @Post(':commentId/pin')
  @UseGuards(JwtAuthGuard)
  pin(@Param('commentId') commentId: string, @GetUser('id') uid: string) {
    return this.svc.pinComment(commentId, uid);
  }
}
