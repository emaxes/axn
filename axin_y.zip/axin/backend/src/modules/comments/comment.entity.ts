import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, ManyToOne, OneToMany, JoinColumn, Index,
} from 'typeorm';
import { User } from '../users/user.entity';
import { Post } from '../posts/post.entity';

@Entity('comments')
@Index(['postId', 'parentId', 'createdAt'])
@Index(['postId', 'isPinned', 'createdAt'])
@Index(['userId'])
export class Comment {
  @PrimaryGeneratedColumn('uuid') id: string;

  @Index()
  @Column({ name: 'post_id' }) postId: string;

  @Column({ name: 'user_id' }) userId: string;

  @Column({ name: 'parent_id', nullable: true }) parentId: string | null;

  @Column({ type: 'text' }) content: string;

  @Column({ name: 'like_count', default: 0 }) likeCount: number;

  @Column({ name: 'reply_count', default: 0 }) replyCount: number;

  @Column({ name: 'is_edited', default: false }) isEdited: boolean;

  @Column({ name: 'is_pinned', default: false }) isPinned: boolean;

  @Column({ name: 'is_deleted', default: false }) isDeleted: boolean;

  @Column({ name: 'mentions', type: 'text', array: true, default: [] }) mentions: string[];

  // Cursor pagination için
  @Index()
  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;

  // Relations
  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: User;

  @ManyToOne(() => Post, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'post_id' })
  post: Post;

  @ManyToOne(() => Comment, c => c.replies, { nullable: true, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'parent_id' })
  parent: Comment;

  @OneToMany(() => Comment, c => c.parent)
  replies: Comment[];

  // Virtual fields
  isLiked?: boolean;
  isOwn?: boolean;
}
