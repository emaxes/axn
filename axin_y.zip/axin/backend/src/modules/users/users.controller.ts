import {
  Controller, Get, Post, Patch, Delete, Param,
  Query, Body, UseGuards, ParseIntPipe, DefaultValuePipe,
} from '@nestjs/common';
import { UsersService } from './users.service';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { OptionalJwtGuard } from '../auth/guards/optional-jwt.guard';
import { GetUser } from '../../common/decorators/get-user.decorator';

@Controller({ path: 'users', version: '1' })
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  // ─── Search ──────────────────────────────────────────────
  @Get('search')
  @UseGuards(OptionalJwtGuard)
  search(@Query('q') q: string, @GetUser('id') uid?: string) {
    return this.usersService.search(q, uid);
  }

  // ─── Current user ─────────────────────────────────────────
  @Patch('me')
  @UseGuards(JwtAuthGuard)
  updateProfile(@GetUser('id') uid: string, @Body() dto: UpdateProfileDto) {
    return this.usersService.updateProfile(uid, dto);
  }

  @Get('by-id/:id')
  @UseGuards(JwtAuthGuard)
  findById(@Param('id') id: string) {
    return this.usersService.findById(id);
  }

  // ─── Suggested ────────────────────────────────────────────
  @Get('suggested')
  @UseGuards(JwtAuthGuard)
  getSuggested(
    @GetUser('id') uid: string,
    @Query('limit', new DefaultValuePipe(10), ParseIntPipe) limit: number,
  ) {
    return this.usersService.getSuggested(uid, limit);
  }

  // ─── Follow requests ──────────────────────────────────────
  @Get('requests')
  @UseGuards(JwtAuthGuard)
  getPendingRequests(@GetUser('id') uid: string) {
    return this.usersService.getPendingRequests(uid);
  }

  @Post('requests/:username/accept')
  @UseGuards(JwtAuthGuard)
  acceptRequest(@GetUser('id') uid: string, @Param('username') username: string) {
    return this.usersService.respondToRequest(uid, username, true);
  }

  @Post('requests/:username/reject')
  @UseGuards(JwtAuthGuard)
  rejectRequest(@GetUser('id') uid: string, @Param('username') username: string) {
    return this.usersService.respondToRequest(uid, username, false);
  }

  // ─── Profile (username) ───────────────────────────────────
  @Get(':username')
  @UseGuards(OptionalJwtGuard)
  getProfile(@Param('username') username: string, @GetUser('id') uid?: string) {
    return this.usersService.findByUsername(username, uid);
  }

  // ─── Follow / Unfollow ────────────────────────────────────
  @Post(':username/follow')
  @UseGuards(JwtAuthGuard)
  follow(@Param('username') username: string, @GetUser('id') uid: string) {
    return this.usersService.toggleFollow(uid, username);
  }

  // ─── Block / Unblock ──────────────────────────────────────
  @Post(':username/block')
  @UseGuards(JwtAuthGuard)
  block(@Param('username') username: string, @GetUser('id') uid: string) {
    return this.usersService.toggleBlock(uid, username);
  }

  // ─── Followers / Following ────────────────────────────────
  @Get(':username/followers')
  @UseGuards(OptionalJwtGuard)
  getFollowers(
    @Param('username') username: string,
    @GetUser('id') uid: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(30), ParseIntPipe) limit: number,
    @Query('q') q?: string,
  ) {
    return this.usersService.getFollowers(username, page, limit, q, uid);
  }

  @Get(':username/following')
  @UseGuards(OptionalJwtGuard)
  getFollowing(
    @Param('username') username: string,
    @GetUser('id') uid: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(30), ParseIntPipe) limit: number,
    @Query('q') q?: string,
  ) {
    return this.usersService.getFollowing(username, page, limit, q, uid);
  }

  // ─── Posts / Likes ────────────────────────────────────────
  @Get(':username/posts')
  @UseGuards(OptionalJwtGuard)
  getPosts(@Param('username') username: string, @GetUser('id') uid?: string) {
    return this.usersService.getUserPosts(username, uid);
  }

  @Get(':username/likes')
  getLikes(@Param('username') username: string) {
    return this.usersService.getUserLikes(username);
  }
}
