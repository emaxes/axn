import { Entity, ManyToOne, JoinColumn, CreateDateColumn, PrimaryColumn, Index, Column } from 'typeorm';
import { User } from './user.entity';

export enum FollowStatus {
  PENDING  = 'pending',
  ACCEPTED = 'accepted',
  BLOCKED  = 'blocked',
}

@Entity('follows')
@Index(['followerId', 'followingId'], { unique: true })
@Index(['followingId', 'status'])
@Index(['followerId', 'status'])
export class Follow {
  @PrimaryColumn({ name: 'follower_id' })  followerId:  string;
  @PrimaryColumn({ name: 'following_id' }) followingId: string;

  @Column({ type: 'enum', enum: FollowStatus, default: FollowStatus.ACCEPTED })
  status: FollowStatus;

  @Column({ name: 'is_mutual', default: false }) isMutual: boolean;

  @ManyToOne(() => User, u => u.following, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'follower_id' }) follower: User;

  @ManyToOne(() => User, u => u.followers, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'following_id' }) following: User;

  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @Column({ name: 'accepted_at', nullable: true }) acceptedAt: Date;
}
