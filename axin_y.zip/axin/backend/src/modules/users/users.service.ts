import {
  Injectable, NotFoundException, BadRequestException, ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like, In } from 'typeorm';
import { User } from './user.entity';
import { Follow, FollowStatus } from './follow.entity';
import { Post } from '../posts/post.entity';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationType } from '../notifications/notification.entity';

type SafeUser = Omit<User, 'password' | 'refreshToken'>;

function safe(u: User | null): SafeUser | null {
  if (!u) return null;
  const { password, refreshToken, ...rest } = u as User & { password: string; refreshToken: string };
  return rest;
}

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)   private readonly userRepo:   Repository<User>,
    @InjectRepository(Follow) private readonly followRepo: Repository<Follow>,
    @InjectRepository(Post)   private readonly postRepo:   Repository<Post>,
    private readonly notifService: NotificationsService,
  ) {}

  // ── findById ──────────────────────────────────────────────
  async findById(id: string): Promise<SafeUser> {
    const u = await this.userRepo.findOne({ where: { id } });
    if (!u) throw new NotFoundException('İstifadəçi tapılmadı');
    return safe(u)!;
  }

  // ── findByUsername ────────────────────────────────────────
  async findByUsername(username: string, viewerId?: string) {
    const u = await this.userRepo.findOne({ where: { username } });
    if (!u) throw new NotFoundException('İstifadəçi tapılmadı');

    let isFollowing = false;
    let followsYou  = false;
    let isMutual    = false;
    let followStatus: string | null = null;
    let isBlocked   = false;

    if (viewerId && viewerId !== u.id) {
      const [fwd, rev] = await Promise.all([
        this.followRepo.findOne({ where: { followerId: viewerId, followingId: u.id } }),
        this.followRepo.findOne({ where: { followerId: u.id,      followingId: viewerId } }),
      ]);

      if (fwd) {
        followStatus = fwd.status;
        isFollowing  = fwd.status === FollowStatus.ACCEPTED;
        isBlocked    = fwd.status === FollowStatus.BLOCKED;
      }

      if (rev?.status === FollowStatus.BLOCKED) {
        return { id: u.id, username: u.username, isRestricted: true, blockedByTarget: true };
      }
      if (rev?.status === FollowStatus.ACCEPTED) followsYou = true;
      isMutual = isFollowing && followsYou;
    }

    if (isBlocked) {
      return { id: u.id, username: u.username, isRestricted: true, blockedByViewer: true };
    }

    return { ...safe(u)!, isFollowing, followsYou, isMutual, followStatus, isBlocked };
  }

  // ── updateProfile ─────────────────────────────────────────
  async updateProfile(userId: string, dto: UpdateProfileDto): Promise<SafeUser | null> {
    await this.userRepo.update(userId, dto);
    const updated = await this.userRepo.findOne({ where: { id: userId } });
    return safe(updated);
  }

  // ── search ────────────────────────────────────────────────
  async search(q: string, viewerId?: string): Promise<(SafeUser | null)[]> {
    if (!q || q.trim().length < 2) return [];

    const users = await this.userRepo.find({
      where: [
        { username:    Like(`%${q.toLowerCase()}%`) },
        { displayName: Like(`%${q}%`) },
      ],
      take: 30,
    });

    if (!viewerId) return users.map(u => safe(u));

    const blocked = await this.followRepo.find({
      where: [
        { followerId:  viewerId, status: FollowStatus.BLOCKED },
        { followingId: viewerId, status: FollowStatus.BLOCKED },
      ],
    });
    const blockedIds = new Set([
      ...blocked.map(b => b.followingId),
      ...blocked.map(b => b.followerId),
    ]);

    return users
      .filter(u => !blockedIds.has(u.id) && u.id !== viewerId)
      .map(u => safe(u));
  }

  // ── toggleFollow ──────────────────────────────────────────
  async toggleFollow(followerId: string, targetUsername: string) {
    const target = await this.userRepo.findOne({ where: { username: targetUsername } });
    if (!target) throw new NotFoundException('İstifadəçi tapılmadı');
    if (target.id === followerId) throw new BadRequestException('Özünüzü follow edə bilməzsiniz');

    const block = await this.followRepo.findOne({
      where: [
        { followerId: target.id, followingId: followerId, status: FollowStatus.BLOCKED },
        { followerId: followerId, followingId: target.id, status: FollowStatus.BLOCKED },
      ],
    });
    if (block) throw new ForbiddenException('Follow əməliyyatı mümkün deyil');

    const existing = await this.followRepo.findOne({
      where: { followerId, followingId: target.id },
    });

    if (existing) {
      await this.followRepo.delete({ followerId, followingId: target.id });
      if (existing.status === FollowStatus.ACCEPTED) {
        await this.userRepo.decrement({ id: followerId }, 'followingCount', 1);
        await this.userRepo.decrement({ id: target.id }, 'followerCount',  1);
        await this.followRepo.update(
          { followerId: target.id, followingId: followerId },
          { isMutual: false },
        );
      }
      return { following: false, status: null };
    }

    // isPrivate is a real column on User entity — no cast needed
    const status = target.isPrivate ? FollowStatus.PENDING : FollowStatus.ACCEPTED;
    await this.followRepo.save(
      this.followRepo.create({ followerId, followingId: target.id, status }),
    );

    if (status === FollowStatus.ACCEPTED) {
      await this.userRepo.increment({ id: followerId }, 'followingCount', 1);
      await this.userRepo.increment({ id: target.id }, 'followerCount',  1);

      const rev = await this.followRepo.findOne({
        where: { followerId: target.id, followingId: followerId, status: FollowStatus.ACCEPTED },
      });
      if (rev) {
        await this.followRepo.update({ followerId, followingId: target.id }, { isMutual: true });
        await this.followRepo.update({ followerId: target.id, followingId: followerId }, { isMutual: true });
      }
      await this.notifService.create(target.id, followerId, NotificationType.FOLLOW);
    } else {
      await this.notifService.create(target.id, followerId, NotificationType.FOLLOW_REQUEST);
    }

    return { following: status === FollowStatus.ACCEPTED, status };
  }

  // ── respondToRequest ──────────────────────────────────────
  async respondToRequest(userId: string, requesterUsername: string, accept: boolean) {
    const requester = await this.userRepo.findOne({ where: { username: requesterUsername } });
    if (!requester) throw new NotFoundException('İstifadəçi tapılmadı');

    const req = await this.followRepo.findOne({
      where: { followerId: requester.id, followingId: userId, status: FollowStatus.PENDING },
    });
    if (!req) throw new NotFoundException('Sorğu tapılmadı');

    if (!accept) {
      await this.followRepo.delete({ followerId: requester.id, followingId: userId });
      return { accepted: false };
    }

    await this.followRepo.update(
      { followerId: requester.id, followingId: userId },
      { status: FollowStatus.ACCEPTED, acceptedAt: new Date() },
    );
    await this.userRepo.increment({ id: requester.id }, 'followingCount', 1);
    await this.userRepo.increment({ id: userId },       'followerCount',  1);

    const rev = await this.followRepo.findOne({
      where: { followerId: userId, followingId: requester.id, status: FollowStatus.ACCEPTED },
    });
    if (rev) {
      await this.followRepo.update({ followerId: requester.id, followingId: userId }, { isMutual: true });
      await this.followRepo.update({ followerId: userId, followingId: requester.id }, { isMutual: true });
    }

    await this.notifService.create(requester.id, userId, NotificationType.FOLLOW_ACCEPT);
    return { accepted: true };
  }

  // ── toggleBlock ───────────────────────────────────────────
  async toggleBlock(blockerId: string, targetUsername: string) {
    const target = await this.userRepo.findOne({ where: { username: targetUsername } });
    if (!target) throw new NotFoundException('İstifadəçi tapılmadı');
    if (target.id === blockerId) throw new BadRequestException('Özünüzü bloklaya bilməzsiniz');

    const existing = await this.followRepo.findOne({
      where: { followerId: blockerId, followingId: target.id },
    });

    if (existing?.status === FollowStatus.BLOCKED) {
      await this.followRepo.delete({ followerId: blockerId, followingId: target.id });
      return { blocked: false };
    }

    if (existing?.status === FollowStatus.ACCEPTED) {
      await this.userRepo.decrement({ id: blockerId }, 'followingCount', 1);
      await this.userRepo.decrement({ id: target.id }, 'followerCount',  1);
    }
    // Remove reverse follow too
    const rev = await this.followRepo.findOne({
      where: { followerId: target.id, followingId: blockerId },
    });
    if (rev) {
      await this.followRepo.delete({ followerId: target.id, followingId: blockerId });
      if (rev.status === FollowStatus.ACCEPTED) {
        await this.userRepo.decrement({ id: target.id }, 'followingCount', 1);
        await this.userRepo.decrement({ id: blockerId }, 'followerCount',  1);
      }
    }

    await this.followRepo.save(
      this.followRepo.create({ followerId: blockerId, followingId: target.id, status: FollowStatus.BLOCKED }),
    );
    return { blocked: true };
  }

  // ── getPendingRequests ────────────────────────────────────
  async getPendingRequests(userId: string) {
    const reqs = await this.followRepo.find({
      where:     { followingId: userId, status: FollowStatus.PENDING },
      relations: ['follower'],
      order:     { createdAt: 'DESC' },
    });
    return reqs.map(r => ({ ...safe(r.follower)!, requestedAt: r.createdAt }));
  }

  // ── getSuggested ──────────────────────────────────────────
  async getSuggested(userId: string, limit = 10): Promise<(SafeUser | null)[]> {
    // IDs I already follow
    const following = await this.followRepo.find({
      where:  { followerId: userId, status: FollowStatus.ACCEPTED },
    });
    const myIds = following.map(f => f.followingId);

    // Blocked in either direction
    const blocked = await this.followRepo.find({
      where: [
        { followerId:  userId, status: FollowStatus.BLOCKED },
        { followingId: userId, status: FollowStatus.BLOCKED },
      ],
    });
    const exclude = new Set<string>([
      userId,
      ...myIds,
      ...blocked.map(b => b.followingId),
      ...blocked.map(b => b.followerId),
    ]);

    // Friends of friends
    let suggested: User[] = [];
    if (myIds.length > 0) {
      const fof = await this.followRepo.find({
        where:     { followerId: In(myIds), status: FollowStatus.ACCEPTED },
        relations: ['following'],
        take:      100,
      });
      const freq = new Map<string, { user: User; count: number }>();
      for (const f of fof) {
        if (!f.following || exclude.has(f.following.id)) continue;
        const entry = freq.get(f.following.id);
        if (entry) entry.count += 1;
        else freq.set(f.following.id, { user: f.following, count: 1 });
      }
      suggested = [...freq.values()]
        .sort((a, b) => b.count - a.count)
        .slice(0, limit)
        .map(e => e.user);
    }

    // Back-fill with popular users
    if (suggested.length < limit) {
      const extra = await this.userRepo.find({
        where: { isActive: true },
        order: { followerCount: 'DESC' },
        take:  limit * 3,
      });
      for (const u of extra) {
        if (!exclude.has(u.id) && !suggested.some(s => s.id === u.id)) {
          suggested.push(u);
        }
      }
    }

    return suggested.slice(0, limit).map(u => safe(u));
  }

  // ── getFollowers ──────────────────────────────────────────
  async getFollowers(username: string, page = 1, limit = 30, q?: string, viewerId?: string) {
    const user = await this.userRepo.findOne({ where: { username } });
    if (!user) throw new NotFoundException('İstifadəçi tapılmadı');

    let qb = this.followRepo.createQueryBuilder('f')
      .innerJoinAndSelect('f.follower', 'u')
      .where('f.followingId = :id', { id: user.id })
      .andWhere('f.status = :s', { s: FollowStatus.ACCEPTED });

    if (q) {
      qb = qb.andWhere('(u.username ILIKE :q OR u.displayName ILIKE :q)', { q: `%${q}%` });
    }

    const [rows, total] = await qb
      .orderBy('f.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    const items = await Promise.all(rows.map(async r => {
      const isFollowing = viewerId
        ? !!(await this.followRepo.findOne({
            where: { followerId: viewerId, followingId: r.follower.id, status: FollowStatus.ACCEPTED },
          }))
        : false;
      return { ...safe(r.follower)!, isFollowing };
    }));

    return { items, total, page, pages: Math.ceil(total / limit) };
  }

  // ── getFollowing ──────────────────────────────────────────
  async getFollowing(username: string, page = 1, limit = 30, q?: string, viewerId?: string) {
    const user = await this.userRepo.findOne({ where: { username } });
    if (!user) throw new NotFoundException('İstifadəçi tapılmadı');

    let qb = this.followRepo.createQueryBuilder('f')
      .innerJoinAndSelect('f.following', 'u')
      .where('f.followerId = :id', { id: user.id })
      .andWhere('f.status = :s', { s: FollowStatus.ACCEPTED });

    if (q) {
      qb = qb.andWhere('(u.username ILIKE :q OR u.displayName ILIKE :q)', { q: `%${q}%` });
    }

    const [rows, total] = await qb
      .orderBy('f.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    const items = await Promise.all(rows.map(async r => {
      const isFollowing = viewerId
        ? !!(await this.followRepo.findOne({
            where: { followerId: viewerId, followingId: r.following.id, status: FollowStatus.ACCEPTED },
          }))
        : false;
      return { ...safe(r.following)!, isFollowing };
    }));

    return { items, total, page, pages: Math.ceil(total / limit) };
  }

  // ── getUserPosts ──────────────────────────────────────────
  async getUserPosts(username: string, viewerId?: string): Promise<Post[]> {
    const user = await this.userRepo.findOne({ where: { username } });
    if (!user) return [];

    if (viewerId && viewerId !== user.id) {
      const block = await this.followRepo.findOne({
        where: [
          { followerId: viewerId, followingId: user.id, status: FollowStatus.BLOCKED },
          { followerId: user.id, followingId: viewerId, status: FollowStatus.BLOCKED },
        ],
      });
      if (block) return [];
    }

    return this.postRepo.createQueryBuilder('post')
      .innerJoinAndSelect('post.user', 'user')
      .where('user.username = :username', { username })
      .andWhere('post.isDeleted = false')
      .andWhere('post.parentId IS NULL')
      .orderBy('post.createdAt', 'DESC')
      .take(60)
      .getMany();
  }

  // ── getUserLikes ──────────────────────────────────────────
  async getUserLikes(username: string): Promise<Post[]> {
    const u = await this.userRepo.findOne({ where: { username } });
    if (!u) throw new NotFoundException('İstifadəçi tapılmadı');

    return this.postRepo.createQueryBuilder('post')
      .innerJoinAndSelect('post.user', 'user')
      .innerJoin('likes', 'l', 'l.post_id = post.id AND l.user_id = :uid', { uid: u.id })
      .where('post.isDeleted = false')
      .orderBy('post.createdAt', 'DESC')
      .take(60)
      .getMany();
  }
}
