import { Injectable, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Follow, FollowStatus } from '../users/follow.entity';

@Injectable()
export class BlockGuardService {
  constructor(
    @InjectRepository(Follow) private followRepo: Repository<Follow>,
  ) {}

  async assertNotBlocked(userA: string, userB: string): Promise<void> {
    if (!userA || !userB || userA === userB) return;
    const block = await this.followRepo.findOne({
      where: [
        { followerId: userA, followingId: userB, status: FollowStatus.BLOCKED },
        { followerId: userB, followingId: userA, status: FollowStatus.BLOCKED },
      ],
    });
    if (block) throw new ForbiddenException('Bu istifadəçi ilə əlaqə mümkün deyil');
  }

  async isBlocked(userA: string, userB: string): Promise<boolean> {
    if (!userA || !userB || userA === userB) return false;
    const block = await this.followRepo.findOne({
      where: [
        { followerId: userA, followingId: userB, status: FollowStatus.BLOCKED },
        { followerId: userB, followingId: userA, status: FollowStatus.BLOCKED },
      ],
    });
    return !!block;
  }
}
