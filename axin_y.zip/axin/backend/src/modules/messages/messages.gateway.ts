import {
  WebSocketGateway, WebSocketServer,
  OnGatewayConnection, OnGatewayDisconnect,
  SubscribeMessage, MessageBody, ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';

@WebSocketGateway({ cors: { origin: '*' }, namespace: '/messages' })
export class MessagesGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;
  private userSockets = new Map<string, string>();

  constructor(
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
  ) {}

  async handleConnection(client: Socket) {
    try {
      const token = client.handshake.auth?.token;
      if (!token) { client.disconnect(); return; }
      const payload = this.jwt.verify(token, { secret: this.config.get('app.jwtSecret') });
      this.userSockets.set(payload.sub, client.id);
      client.data.userId = payload.sub;
      // Online bildirişi
      this.server.emit('user_online', { userId: payload.sub });
    } catch { client.disconnect(); }
  }

  handleDisconnect(client: Socket) {
    if (client.data.userId) {
      this.userSockets.delete(client.data.userId);
      this.server.emit('user_offline', { userId: client.data.userId });
    }
  }

  sendMessage(toUserId: string, msg: any) {
    const sid = this.userSockets.get(toUserId);
    if (sid) this.server.to(sid).emit('new_message', msg);
  }

  sendRead(toUserId: string, fromUserId: string) {
    const sid = this.userSockets.get(toUserId);
    if (sid) this.server.to(sid).emit('messages_read', { fromUserId });
  }

  isOnline(userId: string): boolean {
    return this.userSockets.has(userId);
  }
}
