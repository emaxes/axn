import { Controller, Get, Post, Body, Param, UseGuards } from '@nestjs/common';
import { MessagesService } from './messages.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { GetUser } from '../../common/decorators/get-user.decorator';
import { IsString, MaxLength } from 'class-validator';

class SendMessageDto {
  @IsString()
  toId: string;

  @IsString()
  @MaxLength(1000)
  content: string;
}

@Controller({ path: 'messages', version: '1' })
export class MessagesController {
  constructor(private readonly messagesService: MessagesService) {}

  @Get('inbox')
  @UseGuards(JwtAuthGuard)
  getInbox(@GetUser('id') userId: string) {
    return this.messagesService.getInbox(userId);
  }

  @Get('unread')
  @UseGuards(JwtAuthGuard)
  getUnread(@GetUser('id') userId: string) {
    return this.messagesService.getUnreadCount(userId);
  }

  @Get(':userId')
  @UseGuards(JwtAuthGuard)
  getConversation(@GetUser('id') myId: string, @Param('userId') otherId: string) {
    this.messagesService.markRead(otherId, myId);
    return this.messagesService.getConversation(myId, otherId);
  }

  @Post()
  @UseGuards(JwtAuthGuard)
  send(@GetUser('id') fromId: string, @Body() dto: SendMessageDto) {
    return this.messagesService.sendMessage(fromId, dto.toId, dto.content);
  }
}
