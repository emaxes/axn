import { Injectable, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Message } from './message.entity';
import { Follow, FollowStatus } from '../users/follow.entity';
import { MessagesGateway } from './messages.gateway';

@Injectable()
export class MessagesService {
  constructor(
    @InjectRepository(Message)
    private readonly msgRepo: Repository<Message>,
    @InjectRepository(Follow)
    private readonly followRepo: Repository<Follow>,
    private readonly gateway: MessagesGateway,
  ) {}

  async sendMessage(fromId: string, toId: string, content: string) {
    // Block check — both directions
    const block = await this.followRepo.findOne({
      where: [
        { followerId: fromId, followingId: toId, status: FollowStatus.BLOCKED },
        { followerId: toId, followingId: fromId, status: FollowStatus.BLOCKED },
      ],
    });
    if (block) throw new ForbiddenException('Bu istifadəçiyə mesaj göndərmək mümkün deyil');

    const msg = this.msgRepo.create({ fromId, toId, content });
    const saved = await this.msgRepo.save(msg);
    const full = await this.msgRepo.findOne({
      where: { id: saved.id },
      relations: ['from', 'to'],
    });
    // Real-time göndər — qarşı tərəf onlinedırsa çatdırıldı
    const isDelivered = this.gateway.isOnline(toId);
    if (isDelivered) {
      await this.msgRepo.update(saved.id, { isDelivered: true });
      this.gateway.sendMessage(toId, { ...full, isDelivered: true });
    }
    return { ...full, isDelivered };
  }

  async getConversation(userId1: string, userId2: string) {
    // Block check
    const block = await this.followRepo.findOne({
      where: [
        { followerId: userId1, followingId: userId2, status: FollowStatus.BLOCKED },
        { followerId: userId2, followingId: userId1, status: FollowStatus.BLOCKED },
      ],
    });
    if (block) throw new ForbiddenException('Bu istifadəçi ilə söhbət mövcud deyil');

    return this.msgRepo
      .createQueryBuilder('msg')
      .innerJoinAndSelect('msg.from', 'from')
      .innerJoinAndSelect('msg.to', 'to')
      .where(
        '(msg.fromId = :u1 AND msg.toId = :u2) OR (msg.fromId = :u2 AND msg.toId = :u1)',
        { u1: userId1, u2: userId2 },
      )
      .orderBy('msg.createdAt', 'ASC')
      .getMany();
  }

  async getInbox(userId: string) {
    const msgs = await this.msgRepo
      .createQueryBuilder('msg')
      .innerJoinAndSelect('msg.from', 'from')
      .innerJoinAndSelect('msg.to', 'to')
      .where('msg.fromId = :userId OR msg.toId = :userId', { userId })
      .orderBy('msg.createdAt', 'DESC')
      .getMany();

    const seen = new Set<string>();
    return msgs.filter(m => {
      const key = [m.fromId, m.toId].sort().join('-');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  async markRead(fromId: string, toId: string) {
    await this.msgRepo.update({ fromId, toId, isRead: false }, { isRead: true });
    // Göründü bildirişi göndər
    this.gateway.sendRead(fromId, toId);
  }

  async getUnreadCount(userId: string) {
    const count = await this.msgRepo.count({ where: { toId: userId, isRead: false } });
    return { count };
  }
}
