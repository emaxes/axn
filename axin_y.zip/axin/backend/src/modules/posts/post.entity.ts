import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, ManyToOne, OneToMany, JoinColumn, Index,
} from 'typeorm';
import { User } from '../users/user.entity';

@Entity('posts')
export class Post {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column({ name: 'user_id' }) userId: string;
  @Column({ type: 'text' }) content: string;
  @Column({ name: 'media_urls', type: 'text', array: true, default: [] }) mediaUrls: string[];
  @Column({ name: 'parent_id', nullable: true }) parentId: string;
  @Column({ name: 'repost_of', nullable: true }) repostOf: string;
  @Column({ name: 'like_count', default: 0 }) likeCount: number;
  @Column({ name: 'reply_count', default: 0 }) replyCount: number;
  @Column({ name: 'repost_count', default: 0 }) repostCount: number;
  @Column({ name: 'is_reply', default: false })
  isReply: boolean;

  @Column({ name: 'is_deleted', default: false }) isDeleted: boolean;
  @Column({ nullable: true }) location: string;
  @Column({ name: 'music_url', nullable: true }) musicUrl: string;
  @Column({ name: 'music_name', nullable: true }) musicName: string;
  @ManyToOne(() => User, u => u.posts, { onDelete: 'CASCADE' }) @JoinColumn({ name: 'user_id' }) user: User;
  @ManyToOne(() => Post, p => p.replies, { nullable: true }) @JoinColumn({ name: 'parent_id' }) parent: Post;
  @OneToMany(() => Post, p => p.parent) replies: Post[];
  @Index() @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}
