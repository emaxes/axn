import { IsString, MaxLength, IsOptional, IsArray, IsUUID } from 'class-validator';

export class CreatePostDto {
  @IsString() @MaxLength(500) content: string;
  @IsOptional() @IsArray() mediaUrls?: string[];
  @IsOptional() @IsUUID() parentId?: string;
  @IsOptional() @IsString() @MaxLength(100) location?: string;
  @IsOptional() @IsString() audience?: string;
  @IsOptional() @IsString() musicUrl?: string;
  @IsOptional() @IsString() musicName?: string;
}
