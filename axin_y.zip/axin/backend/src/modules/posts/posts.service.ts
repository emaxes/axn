import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { Post } from './post.entity';
import { Like } from './like.entity';
import { CreatePostDto } from './dto/create-post.dto';
import { CacheService } from '../feed/cache.service';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationType } from '../notifications/notification.entity';

@Injectable()
export class PostsService {
  constructor(
    @InjectRepository(Post) private readonly postRepo: Repository<Post>,
    @InjectRepository(Like) private readonly likeRepo: Repository<Like>,
    @InjectQueue('feed') private readonly feedQueue: Queue,
    private readonly cache: CacheService,
    private readonly notifService: NotificationsService,
  ) {}

  async create(userId: string, dto: CreatePostDto): Promise<Post> {
    const isReply = !!dto.parentId && (dto.content?.startsWith('@') ?? false);
    const post = this.postRepo.create({
      userId,
      content: dto.content,
      mediaUrls: dto.mediaUrls ?? [],
      parentId: dto.parentId ?? null,
      location: dto.location ?? null,
      musicUrl: dto.musicUrl ?? null,
      musicName: dto.musicName ?? null,
      isReply,
    });
    const saved = await this.postRepo.save(post);

    if (dto.parentId) {
      const parent = await this.postRepo.findOne({ where: { id: dto.parentId } });
      if (parent) {
        if (parent.userId !== userId) {
          // Direct service call — no queue, no silent drop
          await this.notifService.create(
            parent.userId,
            userId,
            NotificationType.REPLY,
            { postId: saved.id },
          );
        }
        if (!isReply) {
          await this.postRepo.increment({ id: dto.parentId }, 'replyCount', 1);
        }
      }
    } else {
      await this.feedQueue.add('distribute-post', { postId: saved.id, userId });
    }

    return saved;
  }

  async findById(postId: string, currentUserId?: string): Promise<Post & { isLiked: boolean }> {
    const post = await this.postRepo.findOne({
      where: { id: postId, isDeleted: false },
      relations: ['user'],
    });
    if (!post) throw new NotFoundException('Post tapılmadı');

    let isLiked = false;
    if (currentUserId) {
      const like = await this.likeRepo.findOne({ where: { postId, userId: currentUserId } });
      isLiked = !!like;
    }
    return { ...post, isLiked };
  }

  async delete(postId: string, userId: string) {
    const post = await this.postRepo.findOne({ where: { id: postId } });
    if (!post) throw new NotFoundException('Post tapılmadı');
    if (post.userId !== userId) throw new ForbiddenException('İcazəniz yoxdur');
    await this.postRepo.delete(postId);
    try { await this.cache.del(`post:${postId}`); } catch { /* cache miss ok */ }
    return { success: true };
  }

  async deleteReply(postId: string, requestUserId: string) {
    const post = await this.postRepo.findOne({ where: { id: postId } });
    if (!post) throw new NotFoundException('Post tapılmadı');

    let canDelete = post.userId === requestUserId;
    if (!canDelete && post.parentId) {
      const parent = await this.postRepo.findOne({ where: { id: post.parentId } });
      if (parent?.userId === requestUserId) canDelete = true;
    }
    if (!canDelete) throw new ForbiddenException('İcazəniz yoxdur');

    const { parentId, isReply } = post;
    await this.postRepo.delete(postId);
    try { await this.cache.del(`post:${postId}`); } catch { /* ok */ }

    if (parentId && !isReply) {
      const realCount = await this.postRepo.count({
        where: { parentId, isDeleted: false },
      });
      await this.postRepo.update(parentId, { replyCount: realCount });
    }
    return { success: true };
  }

  async getReplies(postId: string, page = 1, limit = 50) {
    const [replies, total] = await this.postRepo
      .createQueryBuilder('post')
      .innerJoinAndSelect('post.user', 'user')
      .where('post.parentId = :postId', { postId })
      .andWhere('post.isDeleted = false')
      .orderBy('post.createdAt', 'ASC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return { replies, total };
  }

  async toggleLike(postId: string, userId: string) {
    const post = await this.postRepo.findOne({ where: { id: postId } });
    if (!post) throw new NotFoundException('Post tapılmadı');

    const existing = await this.likeRepo.findOne({ where: { postId, userId } });
    if (existing) {
      await this.likeRepo.delete({ postId, userId });
      await this.postRepo.decrement({ id: postId }, 'likeCount', 1);
      return { liked: false };
    }

    await this.likeRepo.save(this.likeRepo.create({ postId, userId }));
    await this.postRepo.increment({ id: postId }, 'likeCount', 1);

    if (post.userId !== userId) {
      await this.notifService.create(
        post.userId,
        userId,
        NotificationType.LIKE,
        { postId },
      );
    }
    return { liked: true };
  }

  async update(postId: string, userId: string, content: string) {
    const post = await this.postRepo.findOne({ where: { id: postId } });
    if (!post) throw new NotFoundException('Post tapılmadı');
    if (post.userId !== userId) throw new ForbiddenException('İcazəniz yoxdur');
    await this.postRepo.update(postId, { content });
    return { success: true };
  }

  async toggleRepost(_postId: string, _userId: string) {
    return { success: true, data: { reposted: false } };
  }

  async toggleBookmark(_postId: string, _userId: string) {
    return { success: true, data: { bookmarked: false } };
  }

  async getBookmarks(_userId: string) {
    return { success: true, data: [] };
  }
}
