import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { Post } from './post.entity';
import { Like } from './like.entity';
import { PostsService } from './posts.service';
import { PostsController } from './posts.controller';
import { FeedModule } from '../feed/feed.module';
import { forwardRef } from '@nestjs/common';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Post, Like]),
    BullModule.registerQueue({ name: 'feed' }),
    FeedModule,
    forwardRef(() => NotificationsModule)],
  controllers: [PostsController],
  providers: [PostsService],
  exports: [PostsService],
})
export class PostsModule {}
