import { Controller, Get, Post, Delete, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { PostsService } from './posts.service';
import { CreatePostDto } from './dto/create-post.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { GetUser } from '../../common/decorators/get-user.decorator';

@Controller({ path: 'posts', version: '1' })
export class PostsController {
  constructor(private readonly postsService: PostsService) {}

  @Post()
  @UseGuards(JwtAuthGuard)
  create(@GetUser('id') userId: string, @Body() dto: CreatePostDto) {
    return this.postsService.create(userId, dto);
  }

  @Get('bookmarks/me')
  @UseGuards(JwtAuthGuard)
  getBookmarks(@GetUser('id') userId: string) {
    return this.postsService.getBookmarks(userId);
  }

  @Get(':id')
  findOne(@Param('id') id: string, @GetUser('id') userId: string) {
    return this.postsService.findById(id, userId);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  remove(@Param('id') id: string, @GetUser('id') userId: string) {
    // deleteReply — həm şərh sahibi həm də post sahibi silə bilər
    return this.postsService.deleteReply(id, userId);
  }

  @Get(':id/replies')
  getReplies(@Param('id') id: string, @Query('page') page = 1) {
    return this.postsService.getReplies(id, +page);
  }

  @Post(':id/like')
  @UseGuards(JwtAuthGuard)
  like(@Param('id') postId: string, @GetUser('id') userId: string) {
    return this.postsService.toggleLike(postId, userId);
  }

  @Post(':id/repost')
  @UseGuards(JwtAuthGuard)
  repost(@Param('id') postId: string, @GetUser('id') userId: string) {
    return this.postsService.toggleRepost(postId, userId);
  }

  @Post(':id/bookmark')
  @UseGuards(JwtAuthGuard)
  bookmark(@Param('id') postId: string, @GetUser('id') userId: string) {
    return this.postsService.toggleBookmark(postId, userId);
  }

  @Patch(':id')
  @UseGuards(JwtAuthGuard)
  update(@Param('id') id: string, @GetUser('id') userId: string, @Body('content') content: string) {
    return this.postsService.update(id, userId, content);
  }
}
