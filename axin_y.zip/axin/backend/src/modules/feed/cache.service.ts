import { Injectable, OnModuleInit, OnModuleDestroy, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

@Injectable()
export class CacheService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(CacheService.name);
  private client: Redis;

  constructor(private readonly config: ConfigService) {}

  async onModuleInit() {
    this.client = new Redis({
      host: this.config.get<string>('redis.host'),
      port: this.config.get<number>('redis.port'),
      password: this.config.get<string>('redis.password') || undefined,
      maxRetriesPerRequest: 3,
      lazyConnect: true,
      retryStrategy(times) {
        if (times > 10) return null;  // 10 cəhddən sonra dayanır
        return Math.min(times * 100, 3000);
      },
    });

    this.client.on('error', (err) => this.logger.error('Redis xətası:', err));
    this.client.on('connect', () => this.logger.log('✅ Redis bağlandı'));
    await this.client.connect();
  }

  async onModuleDestroy() {
    await this.client?.quit();
  }

  // ─── Əsas Əməliyyatlar ─────────────────────────────────────────
  async get<T>(key: string): Promise<T | null> {
    const val = await this.client.get(key);
    return val ? JSON.parse(val) : null;
  }

  async set(key: string, value: any, ttlSeconds?: number): Promise<void> {
    const serialized = JSON.stringify(value);
    if (ttlSeconds) {
      await this.client.setex(key, ttlSeconds, serialized);
    } else {
      await this.client.set(key, serialized);
    }
  }

  async del(...keys: string[]): Promise<void> {
    if (keys.length) await this.client.del(...keys);
  }

  async exists(key: string): Promise<boolean> {
    return (await this.client.exists(key)) === 1;
  }

  // ─── Sorted Set (Feed üçün) ────────────────────────────────────
  async zadd(key: string, score: number, member: string): Promise<void> {
    await this.client.zadd(key, score, member);
  }

  async zaddMultiple(
    key: string,
    items: { score: number; value: string }[],
    ttlSeconds?: number,
  ): Promise<void> {
    if (!items.length) return;
    const args: (string | number)[] = items.flatMap((i) => [i.score, i.value]);
    await this.client.zadd(key, ...args);
    if (ttlSeconds) await this.client.expire(key, ttlSeconds);
  }

  async zrevrange(key: string, start: number, stop: number): Promise<string[]> {
    return this.client.zrevrange(key, start, stop);
  }

  async zremrangebyrank(key: string, start: number, stop: number): Promise<void> {
    await this.client.zremrangebyrank(key, start, stop);
  }

  // ─── Counter (Like/Repost sayı) ────────────────────────────────
  async incr(key: string): Promise<number> {
    return this.client.incr(key);
  }

  async decr(key: string): Promise<number> {
    return this.client.decr(key);
  }

  // ─── Set (Like deduplication) ──────────────────────────────────
  async sadd(key: string, member: string): Promise<number> {
    return this.client.sadd(key, member);
  }

  async srem(key: string, member: string): Promise<number> {
    return this.client.srem(key, member);
  }

  async sismember(key: string, member: string): Promise<boolean> {
    return (await this.client.sismember(key, member)) === 1;
  }
}
