import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, IsNull } from 'typeorm';
import { Process, Processor } from '@nestjs/bull';
import { Job } from 'bull';
import { Post } from '../posts/post.entity';
import { Follow } from '../users/follow.entity';
import { CacheService } from './cache.service';

const FEED_MAX_SIZE = 800;
const CANDIDATE_POOL = 200; // Skorlamaq üçün son 200 post götürürük

@Injectable()
@Processor('feed')
export class FeedService {
  constructor(
    @InjectRepository(Post)
    private readonly postRepo: Repository<Post>,
    @InjectRepository(Follow)
    private readonly followRepo: Repository<Follow>,
    private readonly cache: CacheService,
  ) {}

  // 🔥 SƏNİN ÜÇÜN — hamının postu, skora görə sıralanır
  async getForYou(userId: string, page = 1, limit = 20): Promise<any[]> {
    // Son 200 postu götür
    const candidates = await this.postRepo.find({
      where: { isDeleted: false, parentId: IsNull() },
      relations: ['user'],
      order: { createdAt: 'DESC' },
      take: CANDIDATE_POOL,
    });

    // JS-də skor hesabla və sırala
    const now = Date.now();
    const scored = candidates.map((p) => {
      const hoursOld = (now - p.createdAt.getTime()) / 3600000;
      const score =
        (p.likeCount || 0) +
        (p.replyCount || 0) * 2 +
        (p.repostCount || 0) * 3 -
        hoursOld * 0.5;
      return { post: p, score };
    });
    scored.sort((a, b) => b.score - a.score);

    const start = (page - 1) * limit;
    const posts = scored.slice(start, start + limit).map((s) => s.post);

    return this.attachIsLiked(posts, userId);
  }

  // 👥 İZLƏDİKLƏRİN — yalnız izlədiyin + öz postların
  async getFollowing(userId: string, page = 1, limit = 20): Promise<any[]> {
    const posts = await this.postRepo
      .createQueryBuilder('post')
      .leftJoin(
        'follows',
        'f',
        'f.following_id = post.user_id AND f.follower_id = :userId',
        { userId },
      )
      .innerJoinAndSelect('post.user', 'user')
      .where('(f.follower_id = :userId OR post.user_id = :userId)', { userId })
      .andWhere('post.isDeleted = false')
      .andWhere('post.parentId IS NULL')
      .orderBy('post.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getMany();

    return this.attachIsLiked(posts, userId);
  }

  private async attachIsLiked(posts: Post[], userId: string): Promise<any[]> {
    if (!posts.length) return [];
    const postIds = posts.map((p) => p.id);
    const liked = await this.postRepo.manager.query(
      `SELECT post_id FROM likes WHERE user_id = $1 AND post_id = ANY($2::uuid[])`,
      [userId, postIds],
    );
    const likedSet = new Set(liked.map((l: any) => l.post_id));
    return posts.map((p) => ({ ...p, isLiked: likedSet.has(p.id) }));
  }

  @Process('distribute-post')
  async distributePost(job: Job<{ postId: string; userId: string }>) {
    const { postId, userId } = job.data;
    const post = await this.postRepo.findOne({ where: { id: postId } });
    if (!post) return;
    const score = post.createdAt.getTime();
    await this.cache.zadd(`feed:${userId}`, score, postId);
    const followers = await this.followRepo.find({
      where: { followingId: userId },
      select: ['followerId'],
    });
    await Promise.all(
      followers.map((f) => this.cache.zadd(`feed:${f.followerId}`, score, postId)),
    );
    await Promise.all(
      followers.map((f) =>
        this.cache.zremrangebyrank(`feed:${f.followerId}`, 0, -(FEED_MAX_SIZE + 1)),
      ),
    );
  }
}
