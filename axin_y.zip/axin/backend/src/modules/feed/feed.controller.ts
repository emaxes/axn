import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { FeedService } from './feed.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { GetUser } from '../../common/decorators/get-user.decorator';

@Controller({ path: 'feed', version: '1' })
export class FeedController {
  constructor(private readonly feedService: FeedService) {}

  // GET /api/v1/feed — Sənin üçün (alqoritm)
  @Get()
  @UseGuards(JwtAuthGuard)
  getForYou(@GetUser('id') userId: string, @Query('page') page = 1) {
    return this.feedService.getForYou(userId, +page);
  }

  // GET /api/v1/feed/following — İzlədiklərin
  @Get('following')
  @UseGuards(JwtAuthGuard)
  getFollowing(@GetUser('id') userId: string, @Query('page') page = 1) {
    return this.feedService.getFollowing(userId, +page);
  }
}
