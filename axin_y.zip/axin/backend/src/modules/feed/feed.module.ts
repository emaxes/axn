import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { Post } from '../posts/post.entity';
import { Follow } from '../users/follow.entity';
import { FeedService } from './feed.service';
import { FeedController } from './feed.controller';
import { CacheService } from './cache.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Post, Follow]),
    BullModule.registerQueue({ name: 'feed' }),
  ],
  controllers: [FeedController],
  providers: [FeedService, CacheService],
  exports: [CacheService],
})
export class FeedModule {}
