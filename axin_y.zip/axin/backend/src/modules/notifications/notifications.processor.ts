import { Process, Processor } from '@nestjs/bull';
import { Job } from 'bull';
import { NotificationsService } from './notifications.service';
import { NotificationType } from './notification.entity';

@Processor('notifications')
export class NotificationsProcessor {
  constructor(private readonly notifService: NotificationsService) {}

  @Process('like')
  async handleLike(job: Job<{ userId: string; fromUserId: string; postId: string }>) {
    const { userId, fromUserId, postId } = job.data;
    await this.notifService.create(userId, fromUserId, NotificationType.LIKE, { postId });
  }

  @Process('reply')
  async handleReply(job: Job<{ userId: string; fromUserId: string; postId: string }>) {
    const { userId, fromUserId, postId } = job.data;
    await this.notifService.create(userId, fromUserId, NotificationType.REPLY, { postId });
  }

  @Process('follow')
  async handleFollow(job: Job<{ userId: string; fromUserId: string }>) {
    const { userId, fromUserId } = job.data;
    await this.notifService.create(userId, fromUserId, NotificationType.FOLLOW);
  }
}
