import { Controller, Get, Post, Param, UseGuards } from '@nestjs/common';
import { NotificationsService } from './notifications.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { GetUser } from '../../common/decorators/get-user.decorator';

@Controller({ path: 'notifications', version: '1' })
export class NotificationsController {
  constructor(private readonly notifService: NotificationsService) {}

  @Get()
  @UseGuards(JwtAuthGuard)
  getAll(@GetUser('id') userId: string) {
    return this.notifService.getMyNotifications(userId);
  }

  @Get('unread')
  @UseGuards(JwtAuthGuard)
  getUnread(@GetUser('id') userId: string) {
    return this.notifService.getUnreadCount(userId);
  }

  @Post('read')
  @UseGuards(JwtAuthGuard)
  markAllRead(@GetUser('id') userId: string) {
    return this.notifService.markAllRead(userId);
  }

  @Post(':id/read')
  @UseGuards(JwtAuthGuard)
  markOneRead(@Param('id') id: string, @GetUser('id') userId: string) {
    return this.notifService.markOneRead(id, userId);
  }
}
