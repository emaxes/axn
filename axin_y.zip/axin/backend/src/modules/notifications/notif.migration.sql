-- Safe migration for notifications type column
-- Step 1: Add column nullable first (safe for existing rows)
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS comment_id UUID;

-- Step 2: Change type column to varchar with default (single step, safe)
-- If column is enum, convert first
DO $$
BEGIN
  -- Check if type column is enum type
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'notifications'
    AND column_name = 'type'
    AND data_type = 'USER-DEFINED'
  ) THEN
    -- Convert enum to varchar safely
    ALTER TABLE notifications ALTER COLUMN type TYPE VARCHAR(30) USING type::text;
  END IF;

  -- Set default on type column
  ALTER TABLE notifications ALTER COLUMN type SET DEFAULT 'unknown';

  -- Backfill any NULL types with 'unknown'
  UPDATE notifications SET type = 'unknown' WHERE type IS NULL OR type = '';

  -- Now safe to add NOT NULL
  ALTER TABLE notifications ALTER COLUMN type SET NOT NULL;

EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'type column migration skipped: %', SQLERRM;
END $$;

-- Step 3: Update any stale type values to valid ones
UPDATE notifications SET type = 'follow'  WHERE type = 'follow_notification';
UPDATE notifications SET type = 'unknown' WHERE type NOT IN
  ('like','follow','follow_request','follow_accept','reply','mention','unknown');

-- Step 4: Verify
SELECT type, COUNT(*) FROM notifications GROUP BY type ORDER BY count DESC;

SELECT 'Migration complete' AS result;
