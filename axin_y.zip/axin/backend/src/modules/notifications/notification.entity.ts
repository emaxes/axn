import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  ManyToOne, JoinColumn, Index,
} from 'typeorm';
import { User } from '../users/user.entity';

export enum NotificationType {
  LIKE           = 'like',
  FOLLOW         = 'follow',
  FOLLOW_REQUEST = 'follow_request',
  FOLLOW_ACCEPT  = 'follow_accept',
  REPLY          = 'reply',
  MENTION        = 'mention',
}

@Entity('notifications')
@Index(['userId', 'isRead', 'createdAt'])
export class Notification {
  @PrimaryGeneratedColumn('uuid') id: string;

  @Index()
  @Column({ name: 'user_id' }) userId: string;

  @Column({ name: 'from_user_id' }) fromUserId: string;

  @Column({ type: 'varchar', length: 30, nullable: true, default: 'unknown' }) type: string;

  @Column({ name: 'post_id',    nullable: true }) postId:    string | null;
  @Column({ name: 'comment_id', nullable: true }) commentId: string | null;

  @Column({ name: 'is_read', default: false }) isRead: boolean;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })   user: User;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'from_user_id' }) fromUser: User;

  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}
