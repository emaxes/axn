import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Notification, NotificationType } from './notification.entity';
import { NotificationsGateway } from './notifications.gateway';
import { User } from '../users/user.entity';

@Injectable()
export class NotificationsService {
  constructor(
    @InjectRepository(Notification) private notifRepo: Repository<Notification>,
    @InjectRepository(User)         private userRepo:  Repository<User>,
    private readonly gateway: NotificationsGateway,
  ) {}

  // ── create — with dedup guard ────────────────────────────
  async create(
    userId: string,
    fromUserId: string,
    type: NotificationType,
    extra?: { postId?: string; commentId?: string },
  ): Promise<Notification | null> {
    if (!userId || !fromUserId || userId === fromUserId) return null;

    // Dedup: prevent same notification within 60 seconds
    const recent = await this.notifRepo
      .createQueryBuilder('n')
      .where('n.userId = :userId', { userId })
      .andWhere('n.fromUserId = :fromUserId', { fromUserId })
      .andWhere('n.type = :type', { type })
      .andWhere(extra?.postId ? 'n.postId = :postId' : '1=1', { postId: extra?.postId })
      .andWhere("n.createdAt > NOW() - INTERVAL '60 seconds'")
      .getOne();

    if (recent) return null; // duplicate — skip

    const notif = this.notifRepo.create({
      userId,
      fromUserId,
      type,
      postId:    extra?.postId    || null,
      commentId: extra?.commentId || null,
    });

    const saved = await this.notifRepo.save(notif);

    // Load fromUser for realtime payload
    const full = await this.notifRepo.findOne({
      where: { id: saved.id },
      relations: ['fromUser'],
    });

    if (full) this.gateway.sendToUser(userId, full);
    return saved;
  }

  // ── createMention — by username ──────────────────────────
  async createMention(username: string, fromUserId: string, postId: string, commentId?: string) {
    const user = await this.userRepo.findOne({ where: { username } });
    if (!user || user.id === fromUserId) return;
    return this.create(user.id, fromUserId, NotificationType.MENTION, { postId, commentId });
  }

  // ── getMyNotifications ───────────────────────────────────
  async getMyNotifications(userId: string, limit = 50) {
    const notifs = await this.notifRepo.find({
      where: { userId },
      relations: ['fromUser'],
      order: { createdAt: 'DESC' },
      take: limit,
    });

    return Promise.all(notifs.map(async n => {
      if (!n.postId) return n;
      try {
        const [post] = await this.notifRepo.manager.query(
          'SELECT id, media_urls AS "mediaUrls", content FROM posts WHERE id = $1 LIMIT 1',
          [n.postId],
        );
        return { ...n, post: post || null };
      } catch { return n; }
    }));
  }

  // ── markAllRead ───────────────────────────────────────────
  async markAllRead(userId: string) {
    await this.notifRepo.update({ userId, isRead: false }, { isRead: true });
    return { success: true };
  }

  // ── markOneRead ───────────────────────────────────────────
  async markOneRead(notifId: string, userId: string) {
    await this.notifRepo.update({ id: notifId, userId }, { isRead: true });
    return { success: true };
  }

  // ── getUnreadCount ────────────────────────────────────────
  async getUnreadCount(userId: string): Promise<{ count: number }> {
    const count = await this.notifRepo.count({ where: { userId, isRead: false } });
    return { count };
  }
}
