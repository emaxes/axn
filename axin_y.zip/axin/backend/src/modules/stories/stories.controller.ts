import { Controller, Get, Post, Delete, Param, Body, UseGuards } from '@nestjs/common';
import { StoriesService } from './stories.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { GetUser } from '../../common/decorators/get-user.decorator';

@Controller({ path: 'stories', version: '1' })
export class StoriesController {
  constructor(private readonly storiesService: StoriesService) {}

  @Get()
  @UseGuards(JwtAuthGuard)
  getFeed(@GetUser('id') userId: string) {
    return this.storiesService.getFeedStories(userId);
  }

  @Post()
  @UseGuards(JwtAuthGuard)
  create(
    @GetUser('id') userId: string,
    @Body() body: { mediaUrl: string; mediaType: string; text?: string },
  ) {
    return this.storiesService.create(userId, body.mediaUrl, body.mediaType, body.text);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  delete(@Param('id') id: string) {
    return { ok: true };
  }
}
