import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, MoreThan } from 'typeorm';
import { Story } from './story.entity';

@Injectable()
export class StoriesService {
  constructor(
    @InjectRepository(Story)
    private readonly storyRepo: Repository<Story>,
  ) {}

  async create(userId: string, mediaUrl: string, mediaType: string, text?: string) {
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 saat
    const story = this.storyRepo.create({ userId, mediaUrl, mediaType, text, expiresAt });
    return this.storyRepo.save(story);
  }

  async getFeedStories(userId: string) {
    // Aktiv story-ləri tap (bitməmiş)
    const stories = await this.storyRepo
      .createQueryBuilder('story')
      .innerJoinAndSelect('story.user', 'user')
      .where('story.expiresAt > :now', { now: new Date() })
      .orderBy('story.createdAt', 'DESC')
      .getMany();

    // İstifadəçiyə görə qruplaşdır
    const grouped = new Map<string, { user: any; stories: Story[]; hasOwn: boolean }>();
    
    for (const story of stories) {
      const uid = story.userId;
      if (!grouped.has(uid)) {
        grouped.set(uid, { user: story.user, stories: [], hasOwn: uid === userId });
      }
      grouped.get(uid)!.stories.push(story);
    }

    // Öz story-ləri əvvəldə göstər
    const result = [...grouped.values()];
    return result.sort((a, b) => (b.hasOwn ? 1 : 0) - (a.hasOwn ? 1 : 0));
  }

  async getMyStories(userId: string) {
    return this.storyRepo.find({
      where: { userId, expiresAt: MoreThan(new Date()) },
      order: { createdAt: 'DESC' },
    });
  }

  async deleteExpired() {
    await this.storyRepo
      .createQueryBuilder()
      .delete()
      .where('expiresAt < :now', { now: new Date() })
      .execute();
  }
}
