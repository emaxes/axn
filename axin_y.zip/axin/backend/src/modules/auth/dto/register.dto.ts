import {
  IsEmail, IsString, MinLength, MaxLength,
  Matches, IsOptional,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class RegisterDto {
  @ApiProperty({ example: 'user@example.com' })
  @IsEmail({}, { message: 'Düzgün email daxil edin' })
  email: string;

  @ApiProperty({ example: 'anar_97' })
  @IsString()
  @MinLength(3, { message: 'Username minimum 3 simvol olmalıdır' })
  @MaxLength(30, { message: 'Username maximum 30 simvol ola bilər' })
  @Matches(/^[a-z0-9_\.]+$/, {
    message: 'Username yalnız kiçik hərf, rəqəm, _ və . ola bilər',
  })
  username: string;

  @ApiProperty({ example: 'Anar Həsənov' })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  displayName?: string;

  @ApiProperty({ example: 'StrongPass123!' })
  @IsString()
  @MinLength(8, { message: 'Şifrə minimum 8 simvol olmalıdır' })
  @MaxLength(72)
  @Matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, {
    message: 'Şifrədə böyük hərf, kiçik hərf və rəqəm olmalıdır',
  })
  password: string;
}
