import {
  Controller, Post, UseGuards, UseInterceptors,
  UploadedFile, BadRequestException,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname, join } from 'path';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { GetUser } from '../../common/decorators/get-user.decorator';
import { v4 as uuidv4 } from 'uuid';
import { mkdirSync } from 'fs';

const UPLOAD_DIR = '/data/data/com.termux/files/home/axin-uploads';
mkdirSync(UPLOAD_DIR, { recursive: true });

@Controller({ path: 'storage', version: '1' })
export class StorageController {
  @Post('upload')
  @UseGuards(JwtAuthGuard)
  @UseInterceptors(FileInterceptor('file', {
    storage: diskStorage({
      destination: UPLOAD_DIR,
      filename: (req, file, cb) => {
        const ext = extname(file.originalname) || (file.mimetype.includes('video') ? '.mp4' : '.jpg');
        cb(null, `${uuidv4()}${ext}`);
      },
    }),
    limits: { fileSize: 100 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
      // Şəkil VƏ video qəbul et
      const isImage = file.mimetype.startsWith('image/');
      const isVideo = file.mimetype.startsWith('video/') || file.mimetype === 'application/octet-stream';
      if (!isImage && !isVideo) {
        return cb(new BadRequestException('Yalnız şəkil və ya video yüklənə bilər'), false);
      }
      cb(null, true);
    },
  }))
  uploadFile(@UploadedFile() file: Express.Multer.File) {
    if (!file) throw new BadRequestException('Fayl seçilməyib');
    const url = `http://localhost:3001/uploads/${file.filename}`;
    return {
      success: true,
      data: { url, filename: file.filename, size: file.size, mimetype: file.mimetype },
    };
  }
}
