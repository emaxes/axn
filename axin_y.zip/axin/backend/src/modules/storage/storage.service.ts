import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { S3Client, PutObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class StorageService {
  private s3: S3Client;
  private bucket: string;
  private publicUrl: string;

  constructor(private readonly config: ConfigService) {
    this.s3 = new S3Client({
      region: 'auto',
      endpoint: config.get<string>('storage.endpoint'),
      credentials: {
        accessKeyId: config.get<string>('storage.accessKeyId'),
        secretAccessKey: config.get<string>('storage.secretAccessKey'),
      },
    });
    this.bucket = config.get<string>('storage.bucketName');
    this.publicUrl = config.get<string>('storage.publicUrl');
  }

  async getUploadUrl(userId: string, fileType: string, folder = 'posts') {
    const ext = fileType.split('/')[1] || 'jpg';
    const key = `${folder}/${userId}/${uuidv4()}.${ext}`;

    const command = new PutObjectCommand({
      Bucket: this.bucket,
      Key: key,
      ContentType: fileType,
    });

    const uploadUrl = await getSignedUrl(this.s3, command, { expiresIn: 300 });
    const publicFileUrl = `${this.publicUrl}/${key}`;

    return { uploadUrl, publicUrl: publicFileUrl, key };
  }

  async deleteFile(key: string) {
    await this.s3.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }
}
