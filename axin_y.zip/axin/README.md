# Axın 🌊
> Azərbaycanın Sosial Şəbəkəsi

## Tez Başlanğıc

```bash
# 1. Repo klonla
git clone https://github.com/siz/axin.git && cd axin

# 2. Environment faylını hazırla
cp .env.example .env
# .env faylını öz dəyərlərinlə doldur!

# 3. JWT secret-ləri yarat
openssl rand -hex 64  # → JWT_SECRET
openssl rand -hex 64  # → JWT_REFRESH_SECRET

# 4. Docker ilə başlat
docker compose up -d

# 5. Logları izlə
docker compose logs -f backend
```

## API Endpointlər

| Endpoint | Metod | Açıqlama |
|----------|-------|----------|
| `/api/v1/auth/register` | POST | Qeydiyyat |
| `/api/v1/auth/login` | POST | Giriş |
| `/api/v1/auth/refresh` | POST | Token yenilə |
| `/api/v1/auth/logout` | POST | Çıxış |
| `/api/v1/auth/me` | GET | Mənim profilim |
| `/api/v1/posts` | POST | Post yaz |
| `/api/v1/posts/:id` | GET | Post oxu |
| `/api/v1/posts/:id` | DELETE | Post sil |
| `/api/v1/feed` | GET | Feed |
| `/api/v1/users/:username` | GET | Profil |
| `/api/v1/users/:username/follow` | POST | Folla et |

## Swagger Dokumentasiya
```
http://localhost:3001/api/docs
```

## Stack
- **Backend:** NestJS + TypeScript
- **Database:** PostgreSQL 16
- **Cache:** Redis 7
- **Storage:** Cloudflare R2
- **Proxy:** Nginx
- **Deploy:** Docker

## Arxitektura
```
User → Cloudflare CDN → Nginx
                          ├── /api/*  → NestJS Backend
                          └── /*      → Next.js Frontend
                                           ↓
                                    PostgreSQL + Redis
                                           ↓
                                    Cloudflare R2
```
